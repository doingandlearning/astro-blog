"""Customer database management system using SQLAlchemy ORM."""

from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, ForeignKey, func
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship
from sqlalchemy.exc import IntegrityError
from datetime import datetime

Base = declarative_base()


class Customer(Base):
    """Customer model."""
    __tablename__ = 'customers'
    
    customer_id = Column(String, primary_key=True)
    name = Column(String, nullable=False)
    email = Column(String, unique=True, nullable=False)
    phone = Column(String)
    company = Column(String)
    created_at = Column(DateTime, default=datetime.now)
    
    # Relationship: one customer has many orders
    orders = relationship("Order", back_populates="customer", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<Customer(customer_id='{self.customer_id}', name='{self.name}')>"


class Order(Base):
    """Order model."""
    __tablename__ = 'orders'
    
    order_id = Column(String, primary_key=True)
    customer_id = Column(String, ForeignKey('customers.customer_id'), nullable=False)
    order_date = Column(DateTime, default=datetime.now)
    total_amount = Column(Float, nullable=False)
    status = Column(String, default='pending')
    
    # Relationships
    customer = relationship("Customer", back_populates="orders")
    items = relationship("OrderItem", back_populates="order", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<Order(order_id='{self.order_id}', customer_id='{self.customer_id}', total={self.total_amount})>"


class OrderItem(Base):
    """Order item model."""
    __tablename__ = 'order_items'
    
    item_id = Column(Integer, primary_key=True, autoincrement=True)
    order_id = Column(String, ForeignKey('orders.order_id'), nullable=False)
    product_id = Column(String, nullable=False)
    product_name = Column(String, nullable=False)
    quantity = Column(Integer, nullable=False)
    unit_price = Column(Float, nullable=False)
    
    # Relationship: order item belongs to one order
    order = relationship("Order", back_populates="items")
    
    def __repr__(self):
        return f"<OrderItem(product='{self.product_name}', quantity={self.quantity})>"


# Create database engine and session factory
engine = create_engine('sqlite:///customers.db', echo=False)
Session = sessionmaker(bind=engine)

# Create all tables
Base.metadata.create_all(engine)
print("Database schema created successfully")


# Task 2: Insert Operations with ORM
def add_customer(customer_id, name, email, phone=None, company=None):
    """
    Add a new customer to the database.
    
    Returns: True if successful, False otherwise
    """
    session = Session()
    try:
        customer = Customer(
            customer_id=customer_id,
            name=name,
            email=email,
            phone=phone,
            company=company
        )
        session.add(customer)
        session.commit()
        return True
    except IntegrityError as e:
        session.rollback()
        print(f"Error: Customer with ID {customer_id} or email {email} already exists")
        return False
    except Exception as e:
        session.rollback()
        print(f"Database error: {e}")
        return False
    finally:
        session.close()


def create_order(order_id, customer_id, items, status="pending"):
    """
    Create a new order with items.
    
    items: list of dicts with 'product_id', 'product_name', 'quantity', 'unit_price'
    Returns: True if successful, False otherwise
    """
    session = Session()
    try:
        # Calculate total amount
        total_amount = sum(item['quantity'] * item['unit_price'] for item in items)
        
        # Create order
        order = Order(
            order_id=order_id,
            customer_id=customer_id,
            total_amount=total_amount,
            status=status
        )
        session.add(order)
        
        # Create order items
        for item_data in items:
            order_item = OrderItem(
                order_id=order_id,
                product_id=item_data['product_id'],
                product_name=item_data['product_name'],
                quantity=item_data['quantity'],
                unit_price=item_data['unit_price']
            )
            session.add(order_item)
        
        session.commit()
        return True
    except Exception as e:
        session.rollback()
        print(f"Database error: {e}")
        return False
    finally:
        session.close()


# Task 3: Query Operations with ORM
def get_customer(customer_id):
    """Get a customer by ID."""
    session = Session()
    try:
        customer = session.query(Customer).filter(Customer.customer_id == customer_id).first()
        if customer:
            return {
                "customer_id": customer.customer_id,
                "name": customer.name,
                "email": customer.email,
                "phone": customer.phone,
                "company": customer.company,
                "created_at": customer.created_at.isoformat() if customer.created_at else None
            }
        return None
    except Exception as e:
        print(f"Database error: {e}")
        return None
    finally:
        session.close()


def get_all_customers():
    """Get all customers."""
    session = Session()
    try:
        customers = session.query(Customer).order_by(Customer.name).all()
        return [
            {
                "customer_id": c.customer_id,
                "name": c.name,
                "email": c.email,
                "phone": c.phone,
                "company": c.company,
                "created_at": c.created_at.isoformat() if c.created_at else None
            }
            for c in customers
        ]
    except Exception as e:
        print(f"Database error: {e}")
        return []
    finally:
        session.close()


def search_customers_by_name(search_term):
    """Search customers by name (case-insensitive partial match)."""
    session = Session()
    try:
        customers = session.query(Customer).filter(
            Customer.name.like(f"%{search_term}%")
        ).order_by(Customer.name).all()
        return [
            {
                "customer_id": c.customer_id,
                "name": c.name,
                "email": c.email,
                "phone": c.phone,
                "company": c.company
            }
            for c in customers
        ]
    except Exception as e:
        print(f"Database error: {e}")
        return []
    finally:
        session.close()


def get_customer_orders(customer_id):
    """Get all orders for a customer."""
    session = Session()
    try:
        orders = session.query(Order).filter(
            Order.customer_id == customer_id
        ).order_by(Order.order_date.desc()).all()
        return [
            {
                "order_id": o.order_id,
                "customer_id": o.customer_id,
                "order_date": o.order_date.isoformat() if o.order_date else None,
                "total_amount": o.total_amount,
                "status": o.status
            }
            for o in orders
        ]
    except Exception as e:
        print(f"Database error: {e}")
        return []
    finally:
        session.close()


def get_order_items(order_id):
    """Get all items for an order."""
    session = Session()
    try:
        items = session.query(OrderItem).filter(
            OrderItem.order_id == order_id
        ).all()
        return [
            {
                "item_id": i.item_id,
                "order_id": i.order_id,
                "product_id": i.product_id,
                "product_name": i.product_name,
                "quantity": i.quantity,
                "unit_price": i.unit_price
            }
            for i in items
        ]
    except Exception as e:
        print(f"Database error: {e}")
        return []
    finally:
        session.close()


# Task 4: Update Operations with ORM
def update_customer(customer_id, **updates):
    """
    Update customer information.
    
    updates: dict of fields to update (name, email, phone, company)
    Returns: True if successful, False otherwise
    """
    session = Session()
    try:
        customer = session.query(Customer).filter(Customer.customer_id == customer_id).first()
        if not customer:
            return False
        
        # Update only provided fields
        valid_fields = ['name', 'email', 'phone', 'company']
        for field, value in updates.items():
            if field in valid_fields:
                setattr(customer, field, value)
        
        session.commit()
        return True
    except IntegrityError as e:
        session.rollback()
        print(f"Error: {e}")
        return False
    except Exception as e:
        session.rollback()
        print(f"Database error: {e}")
        return False
    finally:
        session.close()


def update_order_status(order_id, new_status):
    """Update order status."""
    valid_statuses = ["pending", "confirmed", "processing", "shipped", "delivered", "cancelled"]
    if new_status not in valid_statuses:
        print(f"Invalid status. Must be one of: {valid_statuses}")
        return False
    
    session = Session()
    try:
        order = session.query(Order).filter(Order.order_id == order_id).first()
        if not order:
            return False
        
        order.status = new_status
        session.commit()
        return True
    except Exception as e:
        session.rollback()
        print(f"Database error: {e}")
        return False
    finally:
        session.close()


# Task 5: Delete Operations with ORM
def delete_customer(customer_id):
    """
    Delete a customer and their orders.
    
    Note: Cascade deletes orders and order items automatically
    Returns: True if successful, False otherwise
    """
    session = Session()
    try:
        customer = session.query(Customer).filter(Customer.customer_id == customer_id).first()
        if not customer:
            return False
        
        session.delete(customer)  # Cascade deletes orders and items
        session.commit()
        return True
    except Exception as e:
        session.rollback()
        print(f"Database error: {e}")
        return False
    finally:
        session.close()


def delete_order(order_id):
    """Delete an order and its items."""
    session = Session()
    try:
        order = session.query(Order).filter(Order.order_id == order_id).first()
        if not order:
            return False
        
        session.delete(order)  # Cascade deletes items
        session.commit()
        return True
    except Exception as e:
        session.rollback()
        print(f"Database error: {e}")
        return False
    finally:
        session.close()


# Task 6: Aggregate Queries with ORM
def get_customer_statistics():
    """Get aggregate statistics about customers."""
    session = Session()
    try:
        total_customers = session.query(func.count(Customer.customer_id)).scalar()
        total_orders = session.query(func.count(Order.order_id)).scalar()
        total_revenue = session.query(func.sum(Order.total_amount)).scalar() or 0
        avg_order_value = session.query(func.avg(Order.total_amount)).scalar() or 0
        
        return {
            "total_customers": total_customers,
            "total_orders": total_orders,
            "total_revenue": float(total_revenue),
            "average_order_value": float(avg_order_value)
        }
    except Exception as e:
        print(f"Database error: {e}")
        return None
    finally:
        session.close()


def get_top_customers(limit=10):
    """Get top customers by total spending."""
    session = Session()
    try:
        results = session.query(
            Customer.customer_id,
            Customer.name,
            Customer.email,
            func.count(Order.order_id).label('order_count'),
            func.sum(Order.total_amount).label('total_spent')
        ).outerjoin(Order).group_by(
            Customer.customer_id
        ).order_by(
            func.sum(Order.total_amount).desc()
        ).limit(limit).all()
        
        return [
            {
                "customer_id": r.customer_id,
                "name": r.name,
                "email": r.email,
                "order_count": r.order_count,
                "total_spent": float(r.total_spent or 0)
            }
            for r in results
        ]
    except Exception as e:
        print(f"Database error: {e}")
        return []
    finally:
        session.close()


# Task 7: Working with Relationships
def get_order_details(order_id):
    """Get complete order details with customer and items using relationships."""
    session = Session()
    try:
        order = session.query(Order).filter(Order.order_id == order_id).first()
        if not order:
            return None
        
        return {
            "order": {
                "order_id": order.order_id,
                "customer_id": order.customer_id,
                "order_date": order.order_date.isoformat() if order.order_date else None,
                "total_amount": order.total_amount,
                "status": order.status
            },
            "customer": {
                "customer_id": order.customer.customer_id,
                "name": order.customer.name,
                "email": order.customer.email
            },
            "items": [
                {
                    "item_id": item.item_id,
                    "product_id": item.product_id,
                    "product_name": item.product_name,
                    "quantity": item.quantity,
                    "unit_price": item.unit_price
                }
                for item in order.items
            ]
        }
    except Exception as e:
        print(f"Database error: {e}")
        return None
    finally:
        session.close()


def get_customer_with_orders(customer_id):
    """Get customer with all their orders using relationships."""
    session = Session()
    try:
        customer = session.query(Customer).filter(Customer.customer_id == customer_id).first()
        if not customer:
            return None
        
        return {
            "customer_id": customer.customer_id,
            "name": customer.name,
            "email": customer.email,
            "phone": customer.phone,
            "company": customer.company,
            "orders": [
                {
                    "order_id": order.order_id,
                    "order_date": order.order_date.isoformat() if order.order_date else None,
                    "total_amount": order.total_amount,
                    "status": order.status
                }
                for order in customer.orders
            ]
        }
    except Exception as e:
        print(f"Database error: {e}")
        return None
    finally:
        session.close()


# Task 8: Complete Example Application
def main():
    """Main application demonstrating ORM operations."""
    print("Customer Database System (SQLAlchemy ORM)")
    print("=" * 60)
    
    # Add customers
    print("\n1. Adding customers...")
    add_customer("CUST001", "Alice Johnson", "alice@email.com", "+44 20 1234 5678", "Tech Corp")
    add_customer("CUST002", "Bob Smith", "bob@email.com", "+44 20 2345 6789", "Design Studio")
    add_customer("CUST003", "Carol Williams", "carol@email.com", phone="+44 20 3456 7890")
    
    # Create orders
    print("\n2. Creating orders...")
    order1_items = [
        {"product_id": "PROD001", "product_name": "Wireless Mouse", "quantity": 2, "unit_price": 29.99},
        {"product_id": "PROD002", "product_name": "USB-C Cable", "quantity": 1, "unit_price": 12.99}
    ]
    create_order("ORD001", "CUST001", order1_items, "confirmed")
    
    order2_items = [
        {"product_id": "PROD003", "product_name": "Desk Lamp", "quantity": 1, "unit_price": 45.00}
    ]
    create_order("ORD002", "CUST002", order2_items, "pending")
    
    # Query customers
    print("\n3. Querying customers...")
    customers = get_all_customers()
    print(f"Total customers: {len(customers)}")
    
    # Search customers
    print("\n4. Searching customers...")
    results = search_customers_by_name("Alice")
    for customer in results:
        print(f"  {customer['name']} - {customer['email']}")
    
    # Get customer with orders (using relationships)
    print("\n5. Customer with orders (using relationships)...")
    customer_data = get_customer_with_orders("CUST001")
    if customer_data:
        print(f"Customer: {customer_data['name']}")
        print(f"  Orders: {len(customer_data['orders'])}")
        for order in customer_data['orders']:
            print(f"    - {order['order_id']}: £{order['total_amount']:.2f} ({order['status']})")
    
    # Get order details (using relationships)
    print("\n6. Order details (using relationships)...")
    order_details = get_order_details("ORD001")
    if order_details:
        print(f"Order: {order_details['order']['order_id']}")
        print(f"  Customer: {order_details['customer']['name']} ({order_details['customer']['email']})")
        print(f"  Items: {len(order_details['items'])}")
        for item in order_details['items']:
            print(f"    - {item['product_name']}: {item['quantity']} x £{item['unit_price']:.2f}")
    
    # Get statistics
    print("\n7. Statistics...")
    stats = get_customer_statistics()
    if stats:
        print(f"Total Customers: {stats['total_customers']}")
        print(f"Total Orders: {stats['total_orders']}")
        print(f"Total Revenue: £{stats['total_revenue']:.2f}")
        print(f"Average Order Value: £{stats['average_order_value']:.2f}")
    
    # Get top customers
    print("\n8. Top customers...")
    top_customers = get_top_customers(5)
    for customer in top_customers:
        print(f"  {customer['name']}: £{customer['total_spent']:.2f} ({customer['order_count']} orders)")


if __name__ == "__main__":
    main()
