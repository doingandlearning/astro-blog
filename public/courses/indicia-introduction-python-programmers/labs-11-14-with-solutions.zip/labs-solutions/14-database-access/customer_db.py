"""Customer database using SQLAlchemy ORM."""

from sqlalchemy import create_engine, Column, String, Float, DateTime, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy.exc import IntegrityError
from datetime import datetime

Base = declarative_base()


class Customer(Base):
    """Customer model."""
    __tablename__ = 'customers'
    
    customer_id = Column(String, primary_key=True)
    name = Column(String, nullable=False)
    email = Column(String, unique=True, nullable=False)
    phone = Column(String)
    created_at = Column(DateTime, default=datetime.now)
    
    def __repr__(self):
        return f"<Customer(customer_id='{self.customer_id}', name='{self.name}')>"


class Order(Base):
    """Order model."""
    __tablename__ = 'orders'
    
    order_id = Column(String, primary_key=True)
    customer_id = Column(String, ForeignKey('customers.customer_id'), nullable=False)
    order_date = Column(DateTime, default=datetime.now)
    total_amount = Column(Float, nullable=False)
    status = Column(String, default='pending')
    
    def __repr__(self):
        return f"<Order(order_id='{self.order_id}', customer_id='{self.customer_id}', total={self.total_amount})>"


# Create database engine and session factory
engine = create_engine('sqlite:///customers.db', echo=False)
Session = sessionmaker(bind=engine)

# Create all tables
Base.metadata.create_all(engine)
print("Database created successfully")


# Task 2: Insert Customers
def add_customer(customer_id, name, email, phone=None):
    """
    Add a new customer to the database.
    
    Returns: True if successful, False otherwise
    """
    session = Session()
    try:
        customer = Customer(
            customer_id=customer_id,
            name=name,
            email=email,
            phone=phone
        )
        session.add(customer)
        session.commit()
        print(f"Customer {customer_id} added successfully")
        return True
    except IntegrityError as e:
        session.rollback()
        print(f"Error: Customer with ID {customer_id} or email {email} already exists")
        return False
    except Exception as e:
        session.rollback()
        print(f"Database error: {e}")
        return False
    finally:
        session.close()


# Task 3: Query Customers
def get_customer(customer_id):
    """Get a customer by ID."""
    session = Session()
    try:
        customer = session.query(Customer).filter(Customer.customer_id == customer_id).first()
        return customer
    except Exception as e:
        print(f"Database error: {e}")
        return None
    finally:
        session.close()


def get_all_customers():
    """Get all customers."""
    session = Session()
    try:
        customers = session.query(Customer).order_by(Customer.name).all()
        return customers
    except Exception as e:
        print(f"Database error: {e}")
        return []
    finally:
        session.close()


def search_customers_by_name(search_term):
    """Search customers by name (case-insensitive partial match)."""
    session = Session()
    try:
        customers = session.query(Customer).filter(
            Customer.name.like(f"%{search_term}%")
        ).order_by(Customer.name).all()
        return customers
    except Exception as e:
        print(f"Database error: {e}")
        return []
    finally:
        session.close()


# Task 4: Update Customers
def update_customer(customer_id, name=None, email=None, phone=None):
    """
    Update customer information.
    
    Returns: True if successful, False otherwise
    """
    session = Session()
    try:
        customer = session.query(Customer).filter(Customer.customer_id == customer_id).first()
        if not customer:
            print(f"Customer {customer_id} not found")
            return False
        
        # Update only provided fields
        if name:
            customer.name = name
        if email:
            customer.email = email
        if phone:
            customer.phone = phone
        
        session.commit()
        print(f"Customer {customer_id} updated successfully")
        return True
    except IntegrityError as e:
        session.rollback()
        print(f"Error: {e}")
        return False
    except Exception as e:
        session.rollback()
        print(f"Database error: {e}")
        return False
    finally:
        session.close()


# Task 5: Delete Customers
def delete_customer(customer_id):
    """
    Delete a customer.
    
    Returns: True if successful, False otherwise
    """
    session = Session()
    try:
        customer = session.query(Customer).filter(Customer.customer_id == customer_id).first()
        if not customer:
            print(f"Customer {customer_id} not found")
            return False
        
        session.delete(customer)
        session.commit()
        print(f"Customer {customer_id} deleted successfully")
        return True
    except Exception as e:
        session.rollback()
        print(f"Database error: {e}")
        return False
    finally:
        session.close()


# Task 6: Add Order Model
def add_order(order_id, customer_id, total_amount, status="pending"):
    """Add a new order."""
    session = Session()
    try:
        order = Order(
            order_id=order_id,
            customer_id=customer_id,
            total_amount=total_amount,
            status=status
        )
        session.add(order)
        session.commit()
        print(f"Order {order_id} added successfully")
        return True
    except Exception as e:
        session.rollback()
        print(f"Database error: {e}")
        return False
    finally:
        session.close()


# Task 7: Query Orders
def get_customer_orders(customer_id):
    """Get all orders for a customer."""
    session = Session()
    try:
        orders = session.query(Order).filter(Order.customer_id == customer_id).all()
        return orders
    except Exception as e:
        print(f"Database error: {e}")
        return []
    finally:
        session.close()


def get_order(order_id):
    """Get an order by ID."""
    session = Session()
    try:
        order = session.query(Order).filter(Order.order_id == order_id).first()
        return order
    except Exception as e:
        print(f"Database error: {e}")
        return None
    finally:
        session.close()


def get_order_with_customer(order_id):
    """Get order with customer information."""
    order = get_order(order_id)
    if not order:
        print(f"Order {order_id} not found")
        return
    
    customer = get_customer(order.customer_id)
    if customer:
        print(f"Order: {order.order_id}")
        print(f"  Customer: {customer.name} ({customer.email})")
        print(f"  Amount: £{order.total_amount:.2f}")
        print(f"  Status: {order.status}")


# Task 8: Complete Example Application
def main():
    """Main application demonstrating database operations."""
    print("=" * 60)
    print("Customer Database System")
    print("=" * 60)
    
    # Add customers
    print("\n1. Adding customers...")
    add_customer("CUST001", "Alice Johnson", "alice@email.com", "+44 20 1234 5678")
    add_customer("CUST002", "Bob Smith", "bob@email.com")
    add_customer("CUST003", "Carol Williams", "carol@email.com", "+44 20 3456 7890")
    
    # Get all customers
    print("\n2. All customers:")
    customers = get_all_customers()
    print(f"Total: {len(customers)}")
    for customer in customers:
        print(f"  {customer.customer_id}: {customer.name} - {customer.email}")
    
    # Search customers
    print("\n3. Searching for 'Alice':")
    results = search_customers_by_name("Alice")
    for customer in results:
        print(f"  Found: {customer.name}")
    
    # Update customer
    print("\n4. Updating customer...")
    update_customer("CUST002", phone="+44 20 8888 8888")
    
    # Add orders
    print("\n5. Adding orders...")
    add_order("ORD001", "CUST001", 99.99, "pending")
    add_order("ORD002", "CUST001", 149.50, "confirmed")
    add_order("ORD003", "CUST002", 75.00, "pending")
    
    # Get customer orders
    print("\n6. Orders for CUST001:")
    orders = get_customer_orders("CUST001")
    for order in orders:
        print(f"  {order.order_id}: £{order.total_amount:.2f} ({order.status})")
    
    # Get order with customer
    print("\n7. Order details:")
    get_order_with_customer("ORD001")


if __name__ == "__main__":
    main()
