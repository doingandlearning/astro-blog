"""News API client."""

import requests
import json


# Task 1: Setup and Basic HTTP Requests
def fetch_article(url):
    """
    Fetch data from a URL.
    
    Returns: response data as dict, or None if error
    """
    try:
        response = requests.get(url)
        response.raise_for_status()  # Raises exception for bad status codes
        return response.json()
    except requests.exceptions.RequestException as e:
        print(f"Error fetching data: {e}")
        return None


# Task 2: Working with URL Parameters
def fetch_articles_with_params(base_url, params=None):
    """
    Fetch articles with URL parameters.
    
    params: dict of query parameters
    Returns: list of articles
    """
    try:
        response = requests.get(base_url, params=params)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        print(f"Error: {e}")
        return []


def search_articles(query, limit=10):
    """
    Search for articles using a query.
    
    Using JSONPlaceholder API as example (in real scenario, use NewsAPI or similar)
    """
    base_url = "https://jsonplaceholder.typicode.com/posts"
    
    # Fetch all articles (in real API, you'd use search parameter)
    all_articles = fetch_articles_with_params(base_url)
    
    # Filter by query (simulating search)
    if query:
        filtered = [
            article for article in all_articles
            if query.lower() in article.get('title', '').lower() or
               query.lower() in article.get('body', '').lower()
        ]
        return filtered[:limit]
    
    return all_articles[:limit]


def get_articles_by_user(user_id):
    """Get articles by user ID."""
    base_url = "https://jsonplaceholder.typicode.com/posts"
    params = {"userId": user_id}
    return fetch_articles_with_params(base_url, params)


# Task 3: Using Real Public APIs
def fetch_country_info(country_name):
    """
    Fetch country information from REST Countries API.
    
    This demonstrates working with a real public API.
    """
    url = f"https://restcountries.com/v3.1/name/{country_name}"
    
    try:
        response = requests.get(url)
        response.raise_for_status()
        data = response.json()
        
        if data:
            country = data[0]
            return {
                "name": country.get("name", {}).get("common"),
                "capital": country.get("capital", [None])[0],
                "population": country.get("population"),
                "region": country.get("region"),
                "currencies": list(country.get("currencies", {}).keys()) if country.get("currencies") else []
            }
    except requests.exceptions.RequestException as e:
        print(f"Error fetching country data: {e}")
        return None


def fetch_random_activity():
    """
    Fetch a random activity from BoredAPI.
    
    Demonstrates working with APIs that return different data structures.
    """
    url = "https://www.boredapi.com/api/activity"
    
    try:
        response = requests.get(url)
        response.raise_for_status()
        data = response.json()
        return {
            "activity": data.get("activity"),
            "type": data.get("type"),
            "participants": data.get("participants"),
            "price": data.get("price"),
            "accessibility": data.get("accessibility")
        }
    except requests.exceptions.RequestException as e:
        print(f"Error: {e}")
        return None


# Task 4: Error Handling
def fetch_with_error_handling(url, params=None):
    """
    Fetch data with comprehensive error handling.
    
    Returns: (success: bool, data: dict or None, error_message: str or None)
    """
    try:
        response = requests.get(url, params=params, timeout=10)
        
        # Check status code
        if response.status_code == 200:
            return True, response.json(), None
        elif response.status_code == 404:
            return False, None, "Resource not found"
        elif response.status_code == 429:
            return False, None, "Rate limit exceeded. Please try again later."
        elif response.status_code >= 500:
            return False, None, f"Server error: {response.status_code}"
        else:
            return False, None, f"Unexpected status code: {response.status_code}"
            
    except requests.exceptions.Timeout:
        return False, None, "Request timed out"
    except requests.exceptions.ConnectionError:
        return False, None, "Connection error. Check your internet connection."
    except requests.exceptions.RequestException as e:
        return False, None, f"Request error: {str(e)}"
    except json.JSONDecodeError:
        return False, None, "Invalid JSON response"
    except Exception as e:
        return False, None, f"Unexpected error: {str(e)}"


# Task 5: Building a News Client Class
class NewsClient:
    """Client for fetching news articles."""
    
    def __init__(self, base_url=None):
        """Initialize the news client."""
        self.base_url = base_url or "https://jsonplaceholder.typicode.com"
        self.session = requests.Session()
        # Set default headers
        self.session.headers.update({
            "User-Agent": "NewsClient/1.0",
            "Accept": "application/json"
        })
    
    def get_article(self, article_id):
        """Get a single article by ID."""
        url = f"{self.base_url}/posts/{article_id}"
        success, data, error = fetch_with_error_handling(url)
        
        if success:
            return data
        else:
            print(f"Error: {error}")
            return None
    
    def get_articles(self, user_id=None, limit=10):
        """Get multiple articles, optionally filtered by user."""
        url = f"{self.base_url}/posts"
        params = {}
        
        if user_id:
            params["userId"] = user_id
        
        success, data, error = fetch_with_error_handling(url, params)
        
        if success:
            return data[:limit] if isinstance(data, list) else [data]
        else:
            print(f"Error: {error}")
            return []
    
    def search_articles(self, query, limit=10):
        """Search articles by query."""
        articles = self.get_articles(limit=100)  # Get more to search through
        
        if query:
            filtered = [
                article for article in articles
                if query.lower() in article.get('title', '').lower() or
                   query.lower() in article.get('body', '').lower()
            ]
            return filtered[:limit]
        
        return articles[:limit]
    
    def get_user_articles(self, user_id):
        """Get all articles by a specific user."""
        return self.get_articles(user_id=user_id, limit=100)


# Task 6: Processing API Responses
def process_articles(articles):
    """Process and format article data."""
    processed = []
    
    for article in articles:
        body = article.get("body", "")
        processed.append({
            "id": article.get("id"),
            "title": article.get("title", "No title"),
            "author": f"User {article.get('userId', 'Unknown')}",
            "preview": body[:100] + "..." if len(body) > 100 else body,
            "word_count": len(body.split())
        })
    
    return processed


def display_articles(articles):
    """Display articles in a formatted way."""
    print("=" * 70)
    print("ARTICLES")
    print("=" * 70)
    
    for article in articles:
        print(f"\n[{article['id']}] {article['title']}")
        print(f"Author: {article['author']}")
        print(f"Preview: {article['preview']}")
        print(f"Words: {article['word_count']}")
        print("-" * 70)


def generate_article_summary(articles):
    """Generate summary statistics."""
    if not articles:
        print("No articles to summarize")
        return
    
    total_articles = len(articles)
    total_words = sum(article.get('word_count', 0) for article in articles)
    avg_words = total_words / total_articles if total_articles > 0 else 0
    
    print("\n" + "=" * 70)
    print("ARTICLE SUMMARY")
    print("=" * 70)
    print(f"Total Articles: {total_articles}")
    print(f"Total Words: {total_words:,}")
    print(f"Average Words per Article: {avg_words:.1f}")
    print("=" * 70)


# Task 7: Complete Example Application
def main():
    """Main application demonstrating API client usage."""
    print("News API Client Demo")
    print("=" * 70)
    
    # Create client
    client = NewsClient()
    
    # Get a single article
    print("\n1. Fetching single article:")
    article = client.get_article(1)
    if article:
        print(f"   Title: {article.get('title')}")
    
    # Get articles by user
    print("\n2. Fetching articles by user:")
    user_articles = client.get_user_articles(1)
    print(f"   Found {len(user_articles)} articles")
    
    # Search articles
    print("\n3. Searching articles:")
    search_results = client.search_articles("qui")
    print(f"   Found {len(search_results)} matching articles")
    
    # Process and display
    print("\n4. Processing articles:")
    processed = process_articles(search_results[:5])
    display_articles(processed)
    
    # Generate summary
    generate_article_summary(processed)
    
    # Demonstrate other APIs
    print("\n5. Fetching country information:")
    country_info = fetch_country_info("united kingdom")
    if country_info:
        print(f"   Country: {country_info['name']}")
        print(f"   Capital: {country_info['capital']}")
        print(f"   Population: {country_info['population']:,}")


if __name__ == "__main__":
    main()
