"""Star Wars API client."""

import requests
import json


# Task 1: Setup and Basic HTTP Requests
def fetch_data(url):
    """
    Fetch data from a URL.
    
    Returns: response data as dict, or None if error
    """
    try:
        response = requests.get(url, timeout=10)
        
        # Check status code
        if response.status_code == 200:
            return response.json()
        elif response.status_code == 404:
            print("Resource not found")
            return None
        else:
            print(f"Unexpected status code: {response.status_code}")
            return None
            
    except requests.exceptions.Timeout:
        print("Request timed out")
        return None
    except requests.exceptions.ConnectionError:
        print("Connection error. Check your internet connection.")
        return None
    except requests.exceptions.RequestException as e:
        print(f"Request error: {e}")
        return None
    except json.JSONDecodeError:
        print("Invalid JSON response")
        return None
    except Exception as e:
        print(f"Unexpected error: {str(e)}")
        return None


# Task 2: Fetching Different Resources
def fetch_character(character_id):
    """Fetch a character by ID."""
    url = f"https://swapi.dev/api/people/{character_id}"
    return fetch_data(url)


def fetch_planet(planet_id):
    """Fetch a planet by ID."""
    url = f"https://swapi.dev/api/planets/{planet_id}"
    return fetch_data(url)


def fetch_film(film_id):
    """Fetch a film by ID."""
    url = f"https://swapi.dev/api/films/{film_id}"
    return fetch_data(url)


# Task 3: Working with Lists and Pagination
def fetch_all_people():
    """Fetch all people."""
    url = "https://swapi.dev/api/people/"
    data = fetch_data(url)
    return data.get("results", []) if data else []


def fetch_all_planets():
    """Fetch all planets."""
    url = "https://swapi.dev/api/planets/"
    data = fetch_data(url)
    return data.get("results", []) if data else []


def search_people(name):
    """Search for people by name."""
    url = "https://swapi.dev/api/people/"
    try:
        response = requests.get(url, params={"search": name}, timeout=10)
        response.raise_for_status()
        data = response.json()
        return data.get("results", [])
    except requests.exceptions.RequestException as e:
        print(f"Error: {e}")
        return []


# Task 4: Processing and Displaying Data
def display_character(character):
    """Display character information."""
    if not character:
        print("No character data")
        return
    
    print("=" * 50)
    print(f"Name: {character.get('name')}")
    print(f"Height: {character.get('height')} cm")
    print(f"Mass: {character.get('mass')} kg")
    print(f"Hair Color: {character.get('hair_color')}")
    print(f"Eye Color: {character.get('eye_color')}")
    print(f"Birth Year: {character.get('birth_year')}")
    print("=" * 50)


def display_planet(planet):
    """Display planet information."""
    if not planet:
        print("No planet data")
        return
    
    print("=" * 50)
    print(f"Name: {planet.get('name')}")
    print(f"Climate: {planet.get('climate')}")
    print(f"Terrain: {planet.get('terrain')}")
    print(f"Population: {planet.get('population')}")
    print("=" * 50)


def list_characters(characters, limit=10):
    """List characters in a numbered format."""
    print(f"\nCharacters (showing {min(limit, len(characters))} of {len(characters)}):")
    for i, char in enumerate(characters[:limit], 1):
        name = char.get('name', 'Unknown')
        height = char.get('height', 'Unknown')
        print(f"{i}. {name} (Height: {height} cm)")


# Task 6: Building a SWAPI Client Class
class SWAPIClient:
    """Client for Star Wars API."""
    
    def __init__(self):
        """Initialize the SWAPI client."""
        self.base_url = "https://swapi.dev/api"
    
    def get_character(self, character_id):
        """Get a character by ID."""
        url = f"{self.base_url}/people/{character_id}"
        return fetch_data(url)
    
    def get_planet(self, planet_id):
        """Get a planet by ID."""
        url = f"{self.base_url}/planets/{planet_id}"
        return fetch_data(url)
    
    def search_characters(self, name):
        """Search for characters by name."""
        url = f"{self.base_url}/people/"
        try:
            response = requests.get(url, params={"search": name}, timeout=10)
            response.raise_for_status()
            data = response.json()
            return data.get("results", [])
        except requests.exceptions.RequestException as e:
            print(f"Error: {e}")
            return []
    
    def list_all_characters(self, limit=10):
        """List all characters."""
        url = f"{self.base_url}/people/"
        data = fetch_data(url)
        if data:
            return data.get("results", [])[:limit]
        return []


# Task 7: Complete Example Application
def main():
    """Main application demonstrating SWAPI client usage."""
    print("=" * 70)
    print("Star Wars API Explorer")
    print("=" * 70)
    
    # Create client
    client = SWAPIClient()
    
    # Get and display a character
    print("\n1. Fetching Luke Skywalker:")
    luke = client.get_character(1)
    if luke:
        display_character(luke)
    
    # Search for characters
    print("\n2. Searching for 'skywalker':")
    skywalkers = client.search_characters("skywalker")
    for person in skywalkers:
        print(f"  - {person.get('name')}")
    
    # Get and display a planet
    print("\n3. Fetching Tatooine:")
    tatooine = client.get_planet(1)
    if tatooine:
        display_planet(tatooine)
    
    # List characters
    print("\n4. Listing first 5 characters:")
    characters = client.list_all_characters(limit=5)
    list_characters(characters, limit=5)


if __name__ == "__main__":
    main()
