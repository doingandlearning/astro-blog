# Lab 13 Solutions - SWAPI Client

This directory contains the solution for Lab 13: Building a Star Wars API Client.

## Files

- `swapi_client.py` - Complete SWAPI client implementation
- `requirements.txt` - Python dependencies

## Running the Solution

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Run the client:
```bash
python swapi_client.py
```

## What's Included

The solution implements all 8 tasks:
- ✅ Task 1: Basic HTTP requests with `fetch_data()`
- ✅ Task 2: Fetching characters, planets, and films
- ✅ Task 3: Lists, pagination, and search
- ✅ Task 4: Display functions for characters and planets
- ✅ Task 5: Comprehensive error handling
- ✅ Task 6: SWAPIClient class
- ✅ Task 7: Complete main() function
- ✅ Task 8: requirements.txt

## Testing

You can test individual functions:

```python
from swapi_client import fetch_character, display_character, SWAPIClient

# Test fetching
luke = fetch_character(1)
display_character(luke)

# Test client class
client = SWAPIClient()
vader = client.search_characters("vader")
for person in vader:
    print(person.get('name'))
```
