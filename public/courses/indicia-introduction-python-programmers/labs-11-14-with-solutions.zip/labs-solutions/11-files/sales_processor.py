"""Sales data processing functions."""

import csv
import json
import os


class SalesOrder:
    """Represents a sales order with calculated totals."""
    
    def __init__(self, order_id, customer_name, product, quantity, unit_price):
        """Initialize a sales order."""
        self.order_id = order_id
        self.customer_name = customer_name
        self.product = product
        self.quantity = float(quantity)
        self.unit_price = float(unit_price)
        # Calculated fields (set to None initially)
        self.subtotal = None
        self.discount_rate = None
        self.discount_amount = None
        self.total = None
    
    def calculate_totals(self):
        """Calculate subtotal, discount, and total."""
        self.subtotal = self.quantity * self.unit_price
        self.discount_rate = 0.10 if self.quantity >= 2 else 0.0
        self.discount_amount = self.subtotal * self.discount_rate
        self.total = self.subtotal - self.discount_amount
    
    def __str__(self):
        """Return formatted string representation."""
        if self.total is None:
            return f"Order {self.order_id}: {self.customer_name} - Not calculated"
        return f"Order {self.order_id}: {self.customer_name} - ${self.total:.2f}"
    
    def to_dict(self):
        """Convert SalesOrder to dictionary (useful for CSV/JSON export)."""
        return {
            'order_id': self.order_id,
            'customer_name': self.customer_name,
            'product': self.product,
            'quantity': self.quantity,
            'unit_price': self.unit_price,
            'subtotal': self.subtotal,
            'discount_rate': self.discount_rate,
            'discount_amount': self.discount_amount,
            'total': self.total
        }


# Task 1: Reading CSV Files
def read_sales_csv(filename):
    """Read sales data from CSV file and return list of dictionaries."""
    try:
        with open(filename, 'r') as f:
            reader = csv.DictReader(f)
            orders = []
            for row in reader:
                orders.append(dict(row))
            return orders
    except FileNotFoundError:
        print(f"File {filename} not found.")
        return []


# Task 2: Loading CSV Data into a Class
def load_orders_from_csv(filename):
    """Load orders from CSV file into SalesOrder objects."""
    orders_data = read_sales_csv(filename)
    orders = []
    
    for order_dict in orders_data:
        try:
            order = SalesOrder(
                order_id=order_dict['order_id'],
                customer_name=order_dict['customer_name'],
                product=order_dict['product'],
                quantity=order_dict['quantity'],
                unit_price=order_dict['unit_price']
            )
            order.calculate_totals()
            orders.append(order)
        except (ValueError, KeyError) as e:
            print(f"Warning: Skipping order {order_dict.get('order_id', 'unknown')} - {e}")
    
    return orders


# Task 3: Calculating Statistics from Sales Data
def process_sales_data(orders):
    """Process sales data - orders are already SalesOrder objects with totals calculated."""
    # Orders are already processed (totals calculated in load_orders_from_csv)
    # Just return them, or convert to dictionaries if needed for export
    return orders


def calculate_summary_stats(orders):
    """Calculate summary statistics from SalesOrder objects."""
    if not orders:
        return {
            'total_orders': 0,
            'total_revenue': 0.0,
            'average_order_value': 0.0,
            'total_discounts': 0.0
        }
    
    totals = [order.total for order in orders]
    discounts = [order.discount_amount for order in orders]
    
    return {
        'total_orders': len(orders),
        'total_revenue': sum(totals),
        'average_order_value': sum(totals) / len(totals),
        'total_discounts': sum(discounts)
    }


# Task 4: Writing Processed Data to CSV
def write_sales_csv(orders, filename):
    """Write SalesOrder objects to CSV file."""
    if not orders:
        print("No orders to write.")
        return False
    
    try:
        fieldnames = [
            'order_id', 'customer_name', 'product', 'quantity', 
            'unit_price', 'subtotal', 'discount_rate', 'discount_amount', 'total'
        ]
        
        with open(filename, 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for order in orders:
                # Convert SalesOrder object to dictionary using to_dict() method
                order_dict = order.to_dict()
                writer.writerow(order_dict)
        return True
    except IOError as e:
        print(f"Error writing CSV file: {e}")
        return False


# Task 5: Writing Processed Data to JSON
def write_sales_json(orders, filename):
    """Write SalesOrder objects to JSON file."""
    try:
        # Convert SalesOrder objects to dictionaries for JSON using to_dict() method
        orders_dict = [order.to_dict() for order in orders]
        
        with open(filename, 'w') as f:
            json.dump(orders_dict, f, indent=2)
        return True
    except (IOError, json.JSONEncodeError) as e:
        print(f"Error writing JSON file: {e}")
        return False


def write_summary_json(stats, filename):
    """Write summary statistics to JSON file."""
    try:
        with open(filename, 'w') as f:
            json.dump(stats, f, indent=2)
        return True
    except (IOError, json.JSONEncodeError) as e:
        print(f"Error writing JSON file: {e}")
        return False


# Task 7: Error Handling and File Validation
def validate_csv_file(filename):
    """Validate CSV file exists and is readable."""
    if not os.path.exists(filename):
        return (False, f"File {filename} does not exist")
    
    if not os.access(filename, os.R_OK):
        return (False, f"File {filename} is not readable")
    
    try:
        # Try to read first row to validate CSV format
        with open(filename, 'r') as f:
            reader = csv.DictReader(f)
            try:
                next(reader)  # Try to read first data row
            except StopIteration:
                return (False, f"File {filename} is empty")
        return (True, "File is valid")
    except Exception as e:
        return (False, f"Error reading CSV: {e}")


# Task 6: Complete Data Processing Pipeline
def process_sales_pipeline(input_csv, output_csv, output_json, summary_json):
    """Complete pipeline: read CSV, load into classes, process, write to CSV and JSON."""
    # Validate input file
    valid, message = validate_csv_file(input_csv)
    if not valid:
        print(f"Validation failed: {message}")
        return (False, None)
    
    try:
        # Load CSV into SalesOrder objects
        print(f"Loading orders from {input_csv}...")
        orders = load_orders_from_csv(input_csv)
        if not orders:
            print("No orders found in input file.")
            return (False, None)
        
        # Process data (totals already calculated in load_orders_from_csv)
        print("Processing sales data...")
        processed = process_sales_data(orders)
        if not processed:
            print("No valid orders after processing.")
            return (False, None)
        
        # Calculate statistics
        stats = calculate_summary_stats(processed)
        
        # Check write permissions for output files
        output_dir = os.path.dirname(output_csv) or '.'
        if not os.access(output_dir, os.W_OK):
            print(f"Error: Cannot write to directory {output_dir}")
            return (False, None)
        
        # Write to CSV
        print(f"Writing to {output_csv}...")
        if not write_sales_csv(processed, output_csv):
            return (False, None)
        
        # Write to JSON
        print(f"Writing to {output_json}...")
        if not write_sales_json(processed, output_json):
            return (False, None)
        
        # Write summary
        print(f"Writing summary to {summary_json}...")
        if not write_summary_json(stats, summary_json):
            return (False, None)
        
        print("Pipeline completed successfully!")
        return (True, stats)
    
    except FileNotFoundError as e:
        print(f"File not found: {e}")
        return (False, None)
    except PermissionError as e:
        print(f"Permission denied: {e}")
        return (False, None)
    except IOError as e:
        print(f"I/O error: {e}")
        return (False, None)
    except Exception as e:
        print(f"Unexpected error: {e}")
        return (False, None)


# Main function for testing
if __name__ == "__main__":
    # Create sample CSV file if it doesn't exist
    if not os.path.exists("sales.csv"):
        csv_data = """order_id,customer_name,product,quantity,unit_price
ORD001,Alice,Widget A,2,75.00
ORD002,Bob,Widget B,1,75.50
ORD003,Charlie,Widget C,3,66.67
ORD004,Diana,Widget A,1,75.00
ORD005,Eve,Widget B,2,75.50"""
        
        with open('sales.csv', 'w') as f:
            f.write(csv_data)
        print("Created sales.csv")
    
    # Test complete pipeline
    success, stats = process_sales_pipeline(
        "sales.csv",
        "processed_sales.csv",
        "processed_sales.json",
        "sales_summary.json"
    )
    
    if success:
        print("\nSummary Statistics:")
        print(f"Total Orders: {stats['total_orders']}")
        print(f"Total Revenue: ${stats['total_revenue']:.2f}")
        print(f"Average Order Value: ${stats['average_order_value']:.2f}")
        print(f"Total Discounts Given: ${stats['total_discounts']:.2f}")
    else:
        print("Pipeline failed. Check error messages above.")
