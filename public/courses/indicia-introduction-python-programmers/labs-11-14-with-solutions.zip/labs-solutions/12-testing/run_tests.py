"""Run tests and generate report."""

import pytest

if __name__ == "__main__":
    # Run tests with verbose output
    pytest.main(["-v", "test_order_processor.py"])
    
    # Or run with coverage (if pytest-cov installed)
    # pytest.main(["-v", "--cov=order_processor", "test_order_processor.py"])
