"""Tests for order processing module."""

import pytest
from order_processor import OrderProcessor


# Task 2: Basic Tests
def test_create_order():
    """Test creating a new order."""
    processor = OrderProcessor()
    items = [
        {"product_id": "PROD001", "price": 29.99, "quantity": 2}
    ]
    order_id = processor.create_order("CUST001", items)
    
    assert order_id == "ORD0001"
    assert len(processor.orders) == 1
    assert processor.orders[0]["customer_id"] == "CUST001"
    assert processor.orders[0]["status"] == "pending"


def test_create_order_empty_items():
    """Test that creating order with empty items raises error."""
    processor = OrderProcessor()
    with pytest.raises(ValueError, match="Order must contain at least one item"):
        processor.create_order("CUST001", [])


def test_create_order_no_customer_id():
    """Test that creating order without customer ID raises error."""
    processor = OrderProcessor()
    items = [{"product_id": "PROD001", "price": 29.99, "quantity": 1}]
    with pytest.raises(ValueError, match="Customer ID is required"):
        processor.create_order("", items)


# Task 3: Parameterized Tests
@pytest.mark.parametrize("items,expected_subtotal", [
    ([{"product_id": "PROD001", "price": 10.00, "quantity": 2}], 20.00),
    ([{"product_id": "PROD001", "price": 15.50, "quantity": 3}], 46.50),
    ([
        {"product_id": "PROD001", "price": 10.00, "quantity": 2},
        {"product_id": "PROD002", "price": 5.00, "quantity": 1}
    ], 25.00),
])
def test_calculate_subtotal(items, expected_subtotal):
    """Test subtotal calculation with various inputs."""
    processor = OrderProcessor()
    result = processor.calculate_subtotal(items)
    assert result == pytest.approx(expected_subtotal, abs=0.01)


@pytest.mark.parametrize("subtotal,discount_percent,expected", [
    (100.00, 0, 100.00),
    (100.00, 10, 90.00),
    (100.00, 25, 75.00),
    (100.00, 50, 50.00),
    (100.00, 100, 0.00),
])
def test_apply_discount(subtotal, discount_percent, expected):
    """Test discount application."""
    processor = OrderProcessor()
    result = processor.apply_discount(subtotal, discount_percent)
    assert result == pytest.approx(expected, abs=0.01)


# Task 4: Test Exceptions
def test_calculate_subtotal_empty_items():
    """Test that empty items list raises ValueError."""
    processor = OrderProcessor()
    with pytest.raises(ValueError, match="Items list cannot be empty"):
        processor.calculate_subtotal([])


def test_calculate_subtotal_negative_price():
    """Test that negative price raises ValueError."""
    processor = OrderProcessor()
    items = [{"product_id": "PROD001", "price": -10.00, "quantity": 1}]
    with pytest.raises(ValueError, match="Price and quantity must be non-negative"):
        processor.calculate_subtotal(items)


def test_apply_discount_invalid_percent():
    """Test that invalid discount percent raises ValueError."""
    processor = OrderProcessor()
    with pytest.raises(ValueError, match="Discount must be between 0 and 100"):
        processor.apply_discount(100.00, 150)


def test_calculate_tax_invalid_rate():
    """Test that invalid tax rate raises ValueError."""
    processor = OrderProcessor()
    with pytest.raises(ValueError, match="Tax rate must be between 0 and 1"):
        processor.calculate_tax(100.00, 1.5)


# Task 5: Test Order Finding
def test_find_order():
    """Test finding an order."""
    processor = OrderProcessor()
    items = [
        {"product_id": "PROD001", "price": 29.99, "quantity": 2},
        {"product_id": "PROD002", "price": 12.99, "quantity": 1},
    ]
    order_id = processor.create_order("CUST001", items)
    order = processor.find_order(order_id)
    assert order is not None
    assert order["order_id"] == order_id


def test_find_order_not_found():
    """Test finding non-existent order."""
    processor = OrderProcessor()
    order = processor.find_order("ORD9999")
    assert order is None


# Task 6: Test Order Status Updates
def test_update_order_status():
    """Test updating order status."""
    processor = OrderProcessor()
    items = [{"product_id": "PROD001", "price": 29.99, "quantity": 2}]
    order_id = processor.create_order("CUST001", items)
    
    result = processor.update_order_status(order_id, "confirmed")
    assert result is True
    
    order = processor.find_order(order_id)
    assert order["status"] == "confirmed"


@pytest.mark.parametrize("status", [
    "pending", "confirmed", "processing", "shipped", "delivered", "cancelled"
])
def test_update_order_status_valid_statuses(status):
    """Test all valid status values."""
    processor = OrderProcessor()
    items = [{"product_id": "PROD001", "price": 29.99, "quantity": 2}]
    order_id = processor.create_order("CUST001", items)
    
    processor.update_order_status(order_id, status)
    order = processor.find_order(order_id)
    assert order["status"] == status


def test_update_order_status_invalid():
    """Test updating with invalid status."""
    processor = OrderProcessor()
    items = [{"product_id": "PROD001", "price": 29.99, "quantity": 2}]
    order_id = processor.create_order("CUST001", items)
    
    with pytest.raises(ValueError, match="Invalid status"):
        processor.update_order_status(order_id, "invalid_status")


def test_update_order_status_not_found():
    """Test updating non-existent order."""
    processor = OrderProcessor()
    with pytest.raises(ValueError, match="Order.*not found"):
        processor.update_order_status("ORD9999", "confirmed")


# Task 7: Test Complete Order Calculation
def test_calculate_total_no_discount():
    """Test total calculation without discount."""
    processor = OrderProcessor()
    items = [
        {"product_id": "PROD001", "price": 29.99, "quantity": 2},
        {"product_id": "PROD002", "price": 12.99, "quantity": 1},
    ]
    total = processor.calculate_total(items, discount_percent=0, tax_rate=0.20)
    # Subtotal: (29.99 * 2) + (12.99 * 1) = 72.97
    # Tax: 72.97 * 0.20 = 14.59
    # Total: 72.97 + 14.59 = 87.56
    expected = 87.56
    assert total == pytest.approx(expected, abs=0.01)


def test_calculate_total_with_discount():
    """Test total calculation with discount."""
    processor = OrderProcessor()
    items = [
        {"product_id": "PROD001", "price": 29.99, "quantity": 2},
        {"product_id": "PROD002", "price": 12.99, "quantity": 1},
    ]
    total = processor.calculate_total(items, discount_percent=10, tax_rate=0.20)
    # Subtotal: 72.97
    # Discount: 72.97 * 0.10 = 7.30
    # Discounted: 72.97 - 7.30 = 65.67
    # Tax: 65.67 * 0.20 = 13.13
    # Total: 65.67 + 13.13 = 78.80
    expected = 78.80
    assert total == pytest.approx(expected, abs=0.01)
