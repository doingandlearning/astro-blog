"""Order processing module."""

class OrderProcessor:
    """Processes customer orders."""
    
    def __init__(self):
        self.orders = []
        self.next_order_id = 1
    
    def create_order(self, customer_id, items):
        """
        Create a new order.
        
        items: list of dicts with 'product_id', 'price', 'quantity'
        Returns: order_id
        """
        if not customer_id:
            raise ValueError("Customer ID is required")
        if not items:
            raise ValueError("Order must contain at least one item")
        
        order_id = f"ORD{self.next_order_id:04d}"
        self.next_order_id += 1
        
        order = {
            "order_id": order_id,
            "customer_id": customer_id,
            "items": items,
            "status": "pending"
        }
        self.orders.append(order)
        return order_id
    
    def calculate_subtotal(self, items):
        """Calculate order subtotal."""
        if not items:
            raise ValueError("Items list cannot be empty")
        
        total = 0
        for item in items:
            price = item.get("price", 0)
            quantity = item.get("quantity", 0)
            if price < 0 or quantity < 0:
                raise ValueError("Price and quantity must be non-negative")
            total += price * quantity
        return total
    
    def apply_discount(self, subtotal, discount_percent):
        """Apply percentage discount."""
        if subtotal < 0:
            raise ValueError("Subtotal cannot be negative")
        if discount_percent < 0 or discount_percent > 100:
            raise ValueError("Discount must be between 0 and 100")
        
        discount_amount = subtotal * (discount_percent / 100)
        return subtotal - discount_amount
    
    def calculate_tax(self, subtotal, tax_rate=0.20):
        """Calculate tax on subtotal."""
        if subtotal < 0:
            raise ValueError("Subtotal cannot be negative")
        if tax_rate < 0 or tax_rate > 1:
            raise ValueError("Tax rate must be between 0 and 1")
        
        return subtotal * tax_rate
    
    def calculate_total(self, items, discount_percent=0, tax_rate=0.20):
        """Calculate total order amount."""
        subtotal = self.calculate_subtotal(items)
        discounted = self.apply_discount(subtotal, discount_percent)
        tax = self.calculate_tax(discounted, tax_rate)
        return discounted + tax
    
    def update_order_status(self, order_id, new_status):
        """Update order status."""
        valid_statuses = ["pending", "confirmed", "processing", "shipped", "delivered", "cancelled"]
        if new_status not in valid_statuses:
            raise ValueError(f"Invalid status. Must be one of: {valid_statuses}")
        
        order = self.find_order(order_id)
        if not order:
            raise ValueError(f"Order {order_id} not found")
        
        order["status"] = new_status
        return True
    
    def find_order(self, order_id):
        """Find an order by ID."""
        for order in self.orders:
            if order["order_id"] == order_id:
                return order
        return None
