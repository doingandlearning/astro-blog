"""Test script to verify Python environment setup."""

import sys
import platform

def main():
    print("=" * 50)
    print("Python Environment Test")
    print("=" * 50)
    print(f"Python Version: {sys.version}")
    print(f"Platform: {platform.platform()}")
    print(f"Python Executable: {sys.executable}")
    print(f"Virtual Environment Active: {hasattr(sys, 'real_prefix') or (hasattr(sys, 'base_prefix') and sys.base_prefix != sys.prefix)}")
    print("=" * 50)
    print("✅ Setup complete! You're ready to code.")

if __name__ == "__main__":
    main()
