# Enhanced guessing game with history tracking

import random

# Set up some constants for the game
MIN_VALUE = 1
MAX_VALUE = 10
MAX_NUMBER_OF_GUESSES = 4
GUESS_PROMPT = f'Please guess a number between {MIN_VALUE} and {MAX_VALUE}: '

# Set up variables to be used in the game
game_over = False

while not game_over:
    # Initialize the history of guesses
    history = []
    
    # Generate a random number for this game
    number_to_guess = random.randint(MIN_VALUE, MAX_VALUE)
    
    # Initialize the number of tries the player has made
    count_number_of_tries = 0
    
    # Start the game
    print('Welcome to the number guess game')
    print(f'I\'m thinking of a number between {MIN_VALUE} and {MAX_VALUE}')
    
    # Track whether the number has been guessed
    number_not_guessed = True
    
    while number_not_guessed:
        # Set up a message to user variable
        message_to_user = None
        
        # Get the player's guess
        guess = int(input(GUESS_PROMPT))
        
        # Check for cheat code (-1)
        if guess == -1:
            print(f'The number to guess is {number_to_guess}')
            message_to_user = 'Cheat code used'
            # Store cheat code in history
            guess_record = (guess, message_to_user)
            history.append(guess_record)
            continue  # Skip the rest of this iteration
        
        # Increment the number of attempts
        count_number_of_tries += 1
        
        # Check if they guessed correctly
        if guess == number_to_guess:
            message_to_user = 'Correct Guess'
            number_not_guessed = False
        elif guess + 1 == number_to_guess or guess - 1 == number_to_guess:
            message_to_user = 'Sorry wrong number - you were out by 1'
        elif guess < number_to_guess:
            message_to_user = "Sorry wrong number\nYour guess was lower than the number"
        elif guess > number_to_guess:
            message_to_user = 'Sorry wrong number\nYour guess was higher than the number'
        
        print(message_to_user)
        
        # Add the guess to the history
        guess_record = (guess, message_to_user)
        history.append(guess_record)
        
        # Check if they've exceeded the maximum number of attempts
        if count_number_of_tries == MAX_NUMBER_OF_GUESSES:
            break
    
    # Check to see if they did guess the correct number
    if number_to_guess == guess:
        print('Well done you won!')
        print(f'You took {count_number_of_tries} goes to complete the game')
    else:
        print("Sorry - you lose")
        print(f'The number you needed to guess was {number_to_guess}')
    
    # Present the guess history in a readable format
    print('Your guesses were:')
    for i, item in enumerate(history, 1):
        print(f'  Guess {i}: {item[0]} - {item[1]}')
    
    # Calculate statistics (only if there are guesses)
    if len(history) > 0:
        total = 0
        lowest_value = 9999
        highest_value = -1
        
        for item in history:
            total = total + item[0]
            if lowest_value > item[0]:
                lowest_value = item[0]
            if highest_value < item[0]:
                highest_value = item[0]
        
        print(f'The lowest value entered: {lowest_value}')
        print(f'The highest value entered: {highest_value}')
        print(f'Average value is: {total / len(history)}')
    else:
        print('No guesses were recorded')
    
    # Ask if they want to play again
    input_not_accepted = True
    while input_not_accepted:
        play_again = input("Do you want to play again (y/n) or (yes/no)? ")
        play_again = play_again.lower()
        
        if play_again == 'n' or play_again == 'no':
            game_over = True
            input_not_accepted = False
        elif play_again == 'y' or play_again == 'yes':
            input_not_accepted = False
        else:
            print('Invalid input must be y/n or yes/no')

print('Game Over')
