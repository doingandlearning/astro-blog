"""Order management system."""

from datetime import datetime

class Product:
    """Represents a product in the inventory."""
    
    def __init__(self, product_id, name, price, category, stock_quantity=0):
        """
        Initialize a product.
        
        product_id: unique identifier
        name: product name
        price: unit price
        category: product category
        stock_quantity: available stock
        """
        self.product_id = product_id
        self.name = name
        self.price = price
        self.category = category
        self.stock_quantity = stock_quantity
    
    def __str__(self):
        """Return string representation for display."""
        return f"Product: {self.name} ({self.category}) - £{self.price:.2f}"
    
    def __repr__(self):
        """Return developer representation."""
        return f"Product(product_id='{self.product_id}', name='{self.name}', price={self.price}, category='{self.category}')"
    
    def is_in_stock(self):
        """Check if product is in stock."""
        return self.stock_quantity > 0
    
    def reduce_stock(self, quantity):
        """Reduce stock by quantity."""
        if quantity > self.stock_quantity:
            return False
        self.stock_quantity -= quantity
        return True
    
    def apply_discount(self, discount_percent):
        """Apply a discount percentage."""
        discount_amount = self.price * (discount_percent / 100)
        return self.price - discount_amount


class OrderItem:
    """Represents an item in an order."""
    
    def __init__(self, product, quantity):
        """
        Initialize an order item.
        
        product: Product object
        quantity: quantity ordered
        """
        self.product = product
        self.quantity = quantity
        self.line_total = product.price * quantity
    
    def __str__(self):
        """Return string representation."""
        return f"{self.quantity}x {self.product.name} @ £{self.product.price:.2f} = £{self.line_total:.2f}"
    
    def get_line_total(self):
        """Calculate total for this line item."""
        return self.product.price * self.quantity
    
    def update_quantity(self, new_quantity):
        """Update the quantity."""
        self.quantity = new_quantity
        self.line_total = self.product.price * new_quantity


class Order:
    """Represents a customer order."""
    
    def __init__(self, order_id, customer_name, customer_email):
        """
        Initialize an order.
        
        order_id: unique order identifier
        customer_name: customer's name
        customer_email: customer's email
        """
        self.order_id = order_id
        self.customer_name = customer_name
        self.customer_email = customer_email
        self.items = []
        self.status = "pending"
        self.order_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    def __str__(self):
        """Return string representation."""
        lines = [
            f"Order {self.order_id}",
            f"Customer: {self.customer_name} ({self.customer_email})",
            f"Status: {self.status}",
            f"Date: {self.order_date}",
            "\nItems:"
        ]
        for item in self.items:
            lines.append(f"  {item}")
        lines.append(f"\nTotal: £{self.calculate_total():.2f}")
        return "\n".join(lines)
    
    def add_item(self, product, quantity):
        """Add an item to the order."""
        if not product.is_in_stock() or quantity > product.stock_quantity:
            return False
        
        order_item = OrderItem(product, quantity)
        self.items.append(order_item)
        product.reduce_stock(quantity)
        return True
    
    def remove_item(self, product_id):
        """Remove an item from the order."""
        for i, item in enumerate(self.items):
            if item.product.product_id == product_id:
                # Restore stock
                item.product.stock_quantity += item.quantity
                self.items.pop(i)
                return True
        return False
    
    def calculate_subtotal(self):
        """Calculate order subtotal."""
        return sum(item.get_line_total() for item in self.items)
    
    def calculate_tax(self, tax_rate=0.20):
        """Calculate tax on order."""
        return self.calculate_subtotal() * tax_rate
    
    def calculate_total(self, tax_rate=0.20, shipping=0):
        """Calculate order total."""
        return self.calculate_subtotal() + self.calculate_tax(tax_rate) + shipping
    
    def get_item_count(self):
        """Get total number of items in order."""
        return sum(item.quantity for item in self.items)
    
    def update_status(self, new_status):
        """Update order status."""
        valid_statuses = ["pending", "confirmed", "processing", "shipped", "delivered", "cancelled"]
        if new_status in valid_statuses:
            self.status = new_status
            return True
        return False
    
    def __len__(self):
        """Return number of items in order."""
        return len(self.items)
    
    def __contains__(self, product_id):
        """Check if order contains a product."""
        return any(item.product.product_id == product_id for item in self.items)
    
    def __iter__(self):
        """Make order iterable."""
        return iter(self.items)
    
    def __eq__(self, other):
        """Check if two orders are equal (same ID)."""
        if not isinstance(other, Order):
            return False
        return self.order_id == other.order_id
    
    def __lt__(self, other):
        """Compare orders by total amount."""
        return self.calculate_total() < other.calculate_total()
    
    def __gt__(self, other):
        """Compare orders by total amount."""
        return self.calculate_total() > other.calculate_total()


def create_sample_products():
    """Create sample products for testing."""
    products = [
        Product("PROD001", "Wireless Mouse", 29.99, "Electronics", 50),
        Product("PROD002", "USB-C Cable", 12.99, "Electronics", 100),
        Product("PROD003", "Desk Lamp", 45.00, "Furniture", 25),
        Product("PROD004", "Notebook Set", 18.50, "Stationery", 75),
    ]
    return products

def process_order_example():
    """Demonstrate order processing."""
    # Create products
    products = create_sample_products()
    
    # Create an order
    order = Order("ORD001", "Alice Johnson", "alice@email.com")
    
    # Add items to order
    order.add_item(products[0], 2)  # 2x Wireless Mouse
    order.add_item(products[1], 3)   # 3x USB-C Cable
    order.add_item(products[3], 1)   # 1x Notebook Set
    
    # Display order
    print(order)
    print(f"\nSubtotal: £{order.calculate_subtotal():.2f}")
    print(f"Tax: £{order.calculate_tax():.2f}")
    print(f"Total: £{order.calculate_total():.2f}")
    
    # Update status
    order.update_status("confirmed")
    print(f"\nOrder Status: {order.status}")
    
    return order

def generate_order_report(order):
    """Generate a detailed order report."""
    print("=" * 60)
    print("ORDER REPORT")
    print("=" * 60)
    print(f"Order ID: {order.order_id}")
    print(f"Customer: {order.customer_name} ({order.customer_email})")
    print(f"Date: {order.order_date}")
    print(f"Status: {order.status}")
    print("\nItems:")
    print("-" * 60)
    
    for item in order:
        print(f"  {item}")
    
    print("-" * 60)
    print(f"Subtotal:        £{order.calculate_subtotal():.2f}")
    print(f"Tax (20%):       £{order.calculate_tax():.2f}")
    print(f"Shipping:        £0.00")
    print("-" * 60)
    print(f"TOTAL:           £{order.calculate_total():.2f}")
    print("=" * 60)

# Example usage
if __name__ == "__main__":
    # Create products
    products = create_sample_products()
    
    # Create order
    order = Order("ORD001", "Bob Smith", "bob@email.com")
    
    # Add items
    order.add_item(products[0], 2)
    order.add_item(products[2], 1)
    
    # Process order
    order.update_status("confirmed")
    
    # Generate report
    generate_order_report(order)
    
    # Check order properties
    print(f"\nTotal items: {order.get_item_count()}")
    print(f"Contains PROD001: {'PROD001' in order}")
    print(f"Number of line items: {len(order)}")
