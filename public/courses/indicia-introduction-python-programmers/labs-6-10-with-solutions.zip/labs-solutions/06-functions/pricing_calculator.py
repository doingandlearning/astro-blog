"""Pricing calculation module for e-commerce."""

def calculate_subtotal(items):
    """
    Calculate subtotal from a list of items.
    
    items: list of tuples (product_name, price, quantity)
    Returns: subtotal as float
    """
    total = 0
    for item in items:
        price = item[1]
        quantity = item[2]
        total += price * quantity
    return total

def apply_percentage_discount(price, discount_percent):
    """
    Apply a percentage discount to a price.
    
    price: original price
    discount_percent: discount percentage (e.g., 15 for 15%)
    Returns: discounted price
    """
    discount_amount = price * (discount_percent / 100)
    return price - discount_amount

def apply_fixed_discount(price, discount_amount):
    """
    Apply a fixed discount amount.
    
    price: original price
    discount_amount: fixed discount amount
    Returns: discounted price (minimum 0)
    """
    discounted = price - discount_amount
    if discounted < 0:
        return 0
    return discounted

def calculate_tax(price, tax_rate=0.20):
    """
    Calculate tax on a price.
    
    price: price before tax
    tax_rate: tax rate (default 20% for UK VAT)
    Returns: tax amount
    """
    return price * tax_rate

def calculate_shipping(subtotal, shipping_method="standard", free_shipping_threshold=50.0):
    """
    Calculate shipping cost.
    
    subtotal: order subtotal
    shipping_method: "standard", "express", or "overnight"
    free_shipping_threshold: threshold for free shipping
    Returns: shipping cost
    """
    if subtotal >= free_shipping_threshold:
        return 0
    
    if shipping_method == "standard":
        return 3.99
    elif shipping_method == "express":
        return 7.99
    elif shipping_method == "overnight":
        return 12.99
    else:
        return 3.99  # Default to standard

def calculate_price_breakdown(subtotal, discount_percent=0, tax_rate=0.20, 
                              shipping_method="standard"):
    """
    Calculate complete price breakdown.
    
    Returns: (subtotal, discount, tax, shipping, total) as tuple
    """
    # Apply discount
    discount_amount = subtotal * (discount_percent / 100)
    discounted_price = subtotal - discount_amount
    
    # Calculate tax on discounted price
    tax = calculate_tax(discounted_price, tax_rate)
    
    # Calculate shipping
    shipping = calculate_shipping(subtotal, shipping_method)
    
    # Calculate total
    total = discounted_price + tax + shipping
    
    return (subtotal, discount_amount, tax, shipping, total)

def get_pricing_tiers(quantity):
    """
    Get pricing tier information based on quantity.
    
    Returns: (tier_name, discount_percent, min_quantity) as tuple
    """
    if quantity >= 50:
        return ("bulk", 15, 50)
    elif quantity >= 20:
        return ("wholesale", 10, 20)
    else:
        return ("standard", 0, 1)

def calculate_member_discount(price, is_member=False, membership_level="standard"):
    """
    Calculate member discount based on membership level.
    """
    if not is_member:
        return price
    
    if membership_level == "standard":
        return apply_percentage_discount(price, 5)
    elif membership_level == "premium":
        return apply_percentage_discount(price, 10)
    elif membership_level == "vip":
        return apply_percentage_discount(price, 15)
    else:
        return price

def apply_promotion_code(price, promo_code):
    """
    Apply a promotion code discount.
    """
    if promo_code == "SAVE10":
        discount_amount = price * 0.10
        return (price - discount_amount, discount_amount)
    elif promo_code == "SAVE20":
        discount_amount = price * 0.20
        return (price - discount_amount, discount_amount)
    elif promo_code == "FREESHIP":
        return (price, 0)
    else:
        return (price, 0)

def calculate_bulk_pricing(unit_price, quantity, bulk_threshold=10):
    """
    Calculate price with bulk discounts.
    """
    if quantity >= bulk_threshold:
        discounted_unit_price = apply_percentage_discount(unit_price, 10)
    else:
        discounted_unit_price = unit_price
    
    return discounted_unit_price * quantity

def format_price(price, currency="£"):
    """
    Format a price for display.
    """
    return f"{currency}{price:.2f}"

def display_price_breakdown(subtotal, discount=0, tax=0, shipping=0, total=0):
    """
    Display a formatted price breakdown.
    """
    print("=" * 50)
    print("PRICE BREAKDOWN")
    print("=" * 50)
    print(f"Subtotal:        {format_price(subtotal)}")
    if discount > 0:
        print(f"Discount:        -{format_price(discount)}")
    print(f"Tax:             {format_price(tax)}")
    if shipping > 0:
        print(f"Shipping:        {format_price(shipping)}")
    print("-" * 50)
    print(f"TOTAL:            {format_price(total)}")
    print("=" * 50)

def process_order(items, discount_percent=0, promo_code=None, 
                  is_member=False, membership_level="standard",
                  shipping_method="standard", tax_rate=0.20):
    """
    Process a complete order with all pricing calculations.
    """
    # Calculate subtotal
    subtotal = calculate_subtotal(items)
    
    # Apply member discount
    if is_member:
        subtotal = calculate_member_discount(subtotal, True, membership_level)
    
    # Apply promo code
    if promo_code is not None:
        subtotal, promo_discount = apply_promotion_code(subtotal, promo_code)
    else:
        promo_discount = 0
    
    # Apply percentage discount
    discount_amount = subtotal * (discount_percent / 100)
    discounted_price = subtotal - discount_amount
    
    # Calculate tax
    tax = calculate_tax(discounted_price, tax_rate)
    
    # Calculate shipping
    shipping = calculate_shipping(subtotal, shipping_method)
    
    # Calculate total
    total = discounted_price + tax + shipping
    
    return {
        'subtotal': subtotal,
        'discount': discount_amount + promo_discount,
        'tax': tax,
        'shipping': shipping,
        'total': total
    }

# Example usage
if __name__ == "__main__":
    # Example order items
    items = [
        ("Wireless Mouse", 29.99, 2),
        ("USB-C Cable", 12.99, 3),
        ("Desk Lamp", 45.00, 1),
    ]
    
    # Process order with various options
    order_result = process_order(
        items=items,
        discount_percent=10,
        promo_code="SAVE10",
        is_member=True,
        membership_level="premium",
        shipping_method="express"
    )
    
    # Display breakdown
    display_price_breakdown(
        subtotal=order_result['subtotal'],
        discount=order_result['discount'],
        tax=order_result['tax'],
        shipping=order_result['shipping'],
        total=order_result['total']
    )
