"""News article processing system."""

# Sample article data: (headline, word_count, category, author, views)
articles = [
    ("Breaking: New Policy Announced", 450, "Politics", "John Smith", 12500),
    ("Tech Innovation Changes Industry", 320, "Technology", "Jane Doe", 8900),
    ("Sports Team Wins Championship", 280, "Sports", "Bob Johnson", 15200),
    ("Weather Forecast for Weekend", 150, "Weather", "Alice Brown", 3400),
    ("Economic Trends Analysis", 520, "Business", "John Smith", 6700),
    ("Health Tips for Summer", 240, "Health", "Carol White", 5600),
    ("Local Event Coverage", 180, "Local", "David Green", 2100),
    ("International News Update", 380, "International", "Jane Doe", 9800),
]

# Task 2: Transform Data with List Comprehensions
def get_headlines(articles):
    """Extract just the headlines from articles."""
    return [article[0] for article in articles]

def calculate_reading_time(articles):
    """Calculate reading time for each article."""
    return [(article[0], article[1] / 200) for article in articles]

def format_article_info(articles):
    """Format article info as strings."""
    return [f"{article[0]} ({article[2]}) - {article[4]} views" for article in articles]

def calculate_engagement_score(articles):
    """Calculate engagement score: views per word."""
    return [(article[0], article[4] / article[1] if article[1] > 0 else 0) for article in articles]

# Task 3: Filter Data with List Comprehensions
def filter_by_category(articles, category):
    """Filter articles by category."""
    return [article for article in articles if article[2] == category]

def filter_by_author(articles, author_name):
    """Filter articles by author."""
    return [article for article in articles if article[3] == author_name]

def filter_long_articles(articles, min_words=300):
    """Filter articles with word count above threshold."""
    return [article for article in articles if article[1] >= min_words]

def filter_popular_articles(articles, min_views=5000):
    """Filter articles with views above threshold."""
    return [article for article in articles if article[4] >= min_views]

def filter_by_multiple_criteria(articles, categories, min_views=0):
    """Filter articles matching multiple criteria."""
    return [article for article in articles 
            if article[2] in categories and article[4] >= min_views]

# Task 4: Aggregate Data with Built-in Functions
def calculate_total_views(articles):
    """Calculate total views across all articles."""
    return sum(article[4] for article in articles)

def find_longest_article(articles):
    """Find article with most words."""
    return max(articles, key=lambda article: article[1])

def calculate_average_word_count(articles):
    """Calculate average word count."""
    if not articles:
        return 0
    return sum(article[1] for article in articles) / len(articles)

def get_category_totals(articles):
    """Calculate total views per category."""
    # Group by category first
    categories = {}
    for article in articles:
        category = article[2]
        if category not in categories:
            categories[category] = []
        categories[category].append(article)
    
    # Sum views for each category
    return {
        category: sum(article[4] for article in cat_articles)
        for category, cat_articles in categories.items()
    }

# Task 5: Combine Comprehensions
def get_popular_headlines(articles, min_views=5000):
    """Get headlines of popular articles."""
    return [article[0] for article in articles if article[4] >= min_views]

def get_author_statistics(articles, author_name):
    """Get statistics for a specific author."""
    author_articles = [article for article in articles if article[3] == author_name]
    
    if not author_articles:
        return {
            "author": author_name,
            "article_count": 0,
            "total_views": 0,
            "avg_word_count": 0
        }
    
    total_views = sum(article[4] for article in author_articles)
    avg_words = sum(article[1] for article in author_articles) / len(author_articles)
    
    return {
        "author": author_name,
        "article_count": len(author_articles),
        "total_views": total_views,
        "avg_word_count": avg_words
    }

def get_category_summaries(articles):
    """Get summary statistics per category."""
    # Group by category
    categories = {}
    for article in articles:
        category = article[2]
        if category not in categories:
            categories[category] = []
        categories[category].append(article)
    
    # Calculate statistics for each category
    result = {}
    for category, cat_articles in categories.items():
        total_views = sum(article[4] for article in cat_articles)
        avg_words = sum(article[1] for article in cat_articles) / len(cat_articles)
        result[category] = {
            "count": len(cat_articles),
            "total_views": total_views,
            "avg_words": avg_words
        }
    
    return result

# Task 6: Advanced Processing
def process_articles_pipeline(articles, category=None, min_views=0, transform_func=None):
    """
    Process articles through a pipeline.
    
    Pipeline: filter -> transform -> return
    """
    result = articles
    
    # Filter by category if provided
    if category is not None:
        result = [article for article in result if article[2] == category]
    
    # Filter by min_views
    result = [article for article in result if article[4] >= min_views]
    
    # Apply transform_func if provided
    if transform_func is not None:
        result = [transform_func(article) for article in result]
    
    return result

def rank_articles_by_engagement(articles):
    """Rank articles by engagement score (views per word)."""
    scores = [(article[0], article[4] / article[1] if article[1] > 0 else 0) 
              for article in articles]
    # Sort by score (descending)
    return sorted(scores, key=lambda x: x[1], reverse=True)

def generate_content_report(articles):
    """Generate a comprehensive content report."""
    print("=" * 60)
    print("CONTENT PROCESSING REPORT")
    print("=" * 60)
    
    # Calculate statistics
    total_articles = len(articles)
    total_views = calculate_total_views(articles)
    avg_words = calculate_average_word_count(articles)
    
    print(f"\nOverall Statistics:")
    print(f"  Total Articles: {total_articles}")
    print(f"  Total Views: {total_views:,}")
    print(f"  Average Word Count: {avg_words:.1f}")
    
    # Category breakdown
    print(f"\nBy Category:")
    category_stats = get_category_summaries(articles)
    for category, stats in category_stats.items():
        print(f"  {category}:")
        print(f"    Articles: {stats['count']}")
        print(f"    Total Views: {stats['total_views']:,}")
        print(f"    Avg Words: {stats['avg_words']:.1f}")
    
    # Top articles
    print(f"\nTop 3 Articles by Engagement:")
    top_articles = rank_articles_by_engagement(articles)[:3]
    for i, (headline, score) in enumerate(top_articles, 1):
        print(f"  {i}. {headline} (Score: {score:.2f})")
    
    print("=" * 60)

# Task 7: Generator Expressions (Optional)
def get_headlines_generator(articles):
    """Extract headlines using a generator expression."""
    return (article[0] for article in articles)

# Example usage
if __name__ == "__main__":
    # Transform articles
    headlines = get_headlines(articles)
    reading_times = calculate_reading_time(articles)
    
    # Filter articles
    tech_articles = filter_by_category(articles, "Technology")
    popular = filter_popular_articles(articles, min_views=8000)
    
    # Aggregate data
    total_views = calculate_total_views(articles)
    longest = find_longest_article(articles)
    
    # Combined operations
    jane_stats = get_author_statistics(articles, "Jane Doe")
    
    # Generate report
    generate_content_report(articles)
