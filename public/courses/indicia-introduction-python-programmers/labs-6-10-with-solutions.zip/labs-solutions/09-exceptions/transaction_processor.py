"""Financial transaction processing system with error handling."""

from datetime import datetime

class InvalidTransactionError(Exception):
    """Custom exception for invalid transactions."""
    pass

class InsufficientFundsError(Exception):
    """Custom exception for insufficient funds."""
    pass

class TransactionLimitExceededError(Exception):
    """Custom exception for transaction limits."""
    pass

# Sample account data
accounts = {
    "ACC001": {"balance": 1000.00, "daily_limit": 5000.00, "daily_spent": 0.00},
    "ACC002": {"balance": 2500.00, "daily_limit": 10000.00, "daily_spent": 0.00},
    "ACC003": {"balance": 500.00, "daily_limit": 2000.00, "daily_spent": 0.00},
}

def process_transaction_basic(account_id, amount, description=""):
    """
    Process a transaction with basic error handling.
    
    Returns: (success: bool, message: str)
    """
    try:
        # Get account
        account = accounts.get(account_id)
        if not account:
            raise ValueError(f"Account {account_id} not found")
        
        # Validate amount
        if amount <= 0:
            raise ValueError("Transaction amount must be positive")
        
        # Check balance
        if amount > account["balance"]:
            raise ValueError("Insufficient funds")
        
        # Process transaction
        account["balance"] -= amount
        return True, f"Transaction successful: {description}"
        
    except ValueError as e:
        return False, f"Error: {str(e)}"
    except Exception as e:
        return False, f"Unexpected error: {str(e)}"

def process_transaction_advanced(account_id, amount, description=""):
    """
    Process transaction with multiple exception types.
    """
    try:
        # Get account - raise custom exception if not found
        account = accounts.get(account_id)
        if not account:
            raise InvalidTransactionError(f"Account {account_id} not found")
        
        # Validate amount - raise ValueError for invalid amounts
        if amount <= 0:
            raise ValueError("Transaction amount must be positive")
        if amount > 10000:
            raise TransactionLimitExceededError("Transaction exceeds maximum limit")
        
        # Check balance - raise custom exception
        if amount > account["balance"]:
            raise InsufficientFundsError(
                f"Insufficient funds. Balance: £{account['balance']:.2f}, "
                f"Requested: £{amount:.2f}"
            )
        
        # Check daily limit
        if account["daily_spent"] + amount > account["daily_limit"]:
            raise TransactionLimitExceededError(
                f"Daily limit exceeded. Limit: £{account['daily_limit']:.2f}, "
                f"Already spent: £{account['daily_spent']:.2f}"
            )
        
        # Process transaction
        account["balance"] -= amount
        account["daily_spent"] += amount
        
        return True, f"Transaction successful: {description}"
        
    except InvalidTransactionError as e:
        return False, f"Invalid transaction: {str(e)}"
    except InsufficientFundsError as e:
        return False, f"Insufficient funds: {str(e)}"
    except TransactionLimitExceededError as e:
        return False, f"Limit exceeded: {str(e)}"
    except ValueError as e:
        return False, f"Validation error: {str(e)}"
    except Exception as e:
        return False, f"Unexpected error: {str(e)}"

def process_transaction_with_logging(account_id, amount, description=""):
    """
    Process transaction with logging using else and finally.
    """
    transaction_log = []
    
    try:
        account = accounts.get(account_id)
        if not account:
            raise InvalidTransactionError(f"Account {account_id} not found")
        
        if amount <= 0:
            raise ValueError("Amount must be positive")
        
        if amount > account["balance"]:
            raise InsufficientFundsError("Insufficient funds")
        
        # Process transaction
        old_balance = account["balance"]
        account["balance"] -= amount
        account["daily_spent"] += amount
        
    except (InvalidTransactionError, InsufficientFundsError, ValueError) as e:
        transaction_log.append(f"ERROR: {str(e)}")
        raise  # Re-raise the exception
        
    else:
        # This runs only if no exception occurred
        transaction_log.append(
            f"SUCCESS: Processed £{amount:.2f} from {account_id}. "
            f"Balance: £{old_balance:.2f} -> £{account['balance']:.2f}"
        )
        
    finally:
        # This always runs
        transaction_log.append(f"Transaction attempt completed at {datetime.now()}")
        print("\n".join(transaction_log))

def process_batch_transactions(transactions):
    """
    Process multiple transactions, continuing on errors.
    
    transactions: list of dicts with 'account_id', 'amount', 'description'
    Returns: (successful_count, failed_count, errors)
    """
    successful = 0
    failed = 0
    errors = []
    
    for transaction in transactions:
        try:
            account_id = transaction.get('account_id')
            amount = transaction.get('amount')
            description = transaction.get('description', '')
            
            # Validate required fields
            if not account_id:
                raise ValueError("Missing account_id")
            if amount is None:
                raise ValueError("Missing amount")
            
            # Process transaction
            success, message = process_transaction_advanced(account_id, amount, description)
            
            if success:
                successful += 1
            else:
                failed += 1
                errors.append(f"Transaction failed: {message}")
                
        except Exception as e:
            failed += 1
            errors.append(f"Error processing transaction: {str(e)}")
            continue  # Continue to next transaction
    
    return successful, failed, errors

def validate_transaction_data(account_id, amount, description=""):
    """
    Validate transaction data before processing.
    
    Raises appropriate exceptions for invalid data.
    """
    errors = []
    
    # Validate account_id
    if not account_id:
        errors.append("Account ID is required")
    elif account_id not in accounts:
        raise InvalidTransactionError(f"Account {account_id} not found")
    
    # Validate amount
    if amount is None:
        errors.append("Amount is required")
    elif not isinstance(amount, (int, float)):
        errors.append("Amount must be a number")
    elif amount <= 0:
        errors.append("Amount must be positive")
    elif amount > 10000:
        raise TransactionLimitExceededError("Amount exceeds maximum limit")
    
    # Validate description (optional but if provided, check length)
    if description and len(description) > 200:
        errors.append("Description too long (max 200 characters)")
    
    # Raise exception if any validation errors
    if errors:
        raise ValueError("; ".join(errors))
    
    return True

def robust_process_transaction(account_id, amount, description=""):
    """
    Robust transaction processor with comprehensive error handling.
    """
    try:
        # Validate input
        validate_transaction_data(account_id, amount, description)
        
        # Get account
        account = accounts[account_id]
        
        # Check business rules
        if amount > account["balance"]:
            raise InsufficientFundsError(
                f"Insufficient funds. Available: £{account['balance']:.2f}"
            )
        
        if account["daily_spent"] + amount > account["daily_limit"]:
            raise TransactionLimitExceededError(
                f"Daily limit would be exceeded. "
                f"Remaining: £{account['daily_limit'] - account['daily_spent']:.2f}"
            )
        
        # Process transaction
        old_balance = account["balance"]
        account["balance"] -= amount
        account["daily_spent"] += amount
        
        return {
            "success": True,
            "message": f"Transaction processed: {description}",
            "account_id": account_id,
            "amount": amount,
            "old_balance": old_balance,
            "new_balance": account["balance"]
        }
        
    except InvalidTransactionError as e:
        return {
            "success": False,
            "error_type": "InvalidTransactionError",
            "message": str(e)
        }
    except InsufficientFundsError as e:
        return {
            "success": False,
            "error_type": "InsufficientFundsError",
            "message": str(e)
        }
    except TransactionLimitExceededError as e:
        return {
            "success": False,
            "error_type": "TransactionLimitExceededError",
            "message": str(e)
        }
    except ValueError as e:
        return {
            "success": False,
            "error_type": "ValueError",
            "message": str(e)
        }
    except Exception as e:
        return {
            "success": False,
            "error_type": "UnexpectedError",
            "message": str(e)
        }

# Example usage
if __name__ == "__main__":
    # Test various scenarios
    test_cases = [
        ("ACC001", 100.00, "Purchase"),
        ("ACC999", 50.00, "Invalid account"),
        ("ACC002", 3000.00, "Exceeds balance"),
        ("ACC001", 6000.00, "Exceeds daily limit"),
        ("ACC003", -50.00, "Negative amount"),
    ]
    
    for account_id, amount, desc in test_cases:
        result = robust_process_transaction(account_id, amount, desc)
        if result["success"]:
            print(f"✅ {result['message']}")
        else:
            print(f"❌ {result['error_type']}: {result['message']}")
