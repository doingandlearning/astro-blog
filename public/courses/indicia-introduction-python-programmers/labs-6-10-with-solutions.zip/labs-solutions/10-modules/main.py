"""Main application using the analytics package."""

# Different import styles
import analytics_package
from analytics_package import calculate_mean, generate_summary_report
from analytics_package.statistics import calculate_median
from analytics_package.data_processing import group_by
import analytics_package.reporting as reporting

# Sample sales data
sales_data = [
    {"region": "North", "sales": 1200, "month": "Jan"},
    {"region": "South", "sales": 1500, "month": "Jan"},
    {"region": "North", "sales": 1300, "month": "Feb"},
    {"region": "South", "sales": 1600, "month": "Feb"},
    {"region": "North", "sales": 1400, "month": "Mar"},
    {"region": "South", "sales": 1700, "month": "Mar"},
]

def main():
    """Main application function."""
    print("Analytics Package Demo")
    print("=" * 60)
    
    # Extract sales values
    sales_values = [item["sales"] for item in sales_data]
    
    # Use functions from package
    print(f"\nMean sales: {calculate_mean(sales_values)}")
    print(f"Median sales: {calculate_median(sales_values)}")
    
    # Generate report
    generate_summary_report(sales_values, "Sales Statistics")
    
    # Group by region
    grouped_by_region = group_by(sales_data, lambda x: x["region"])
    reporting.generate_grouped_report(grouped_by_region, "Sales by Region")
    
    # Explore module properties
    print("\nModule Information:")
    print(f"Package version: {analytics_package.__version__}")
    print(f"Package author: {analytics_package.__author__}")

if __name__ == "__main__":
    main()
