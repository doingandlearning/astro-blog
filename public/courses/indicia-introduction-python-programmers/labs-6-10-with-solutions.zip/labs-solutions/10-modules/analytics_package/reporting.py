"""Reporting functions module."""

from . import statistics

def generate_summary_report(data, title="Data Summary"):
    """Generate a summary statistics report."""
    print("=" * 60)
    print(title)
    print("=" * 60)
    print(f"Count: {len(data)}")
    print(f"Mean: {statistics.calculate_mean(data):.2f}")
    print(f"Median: {statistics.calculate_median(data):.2f}")
    print(f"Mode: {statistics.calculate_mode(data)}")
    print(f"Standard Deviation: {statistics.calculate_standard_deviation(data):.2f}")
    print("=" * 60)

def generate_grouped_report(grouped_data, title="Grouped Report"):
    """Generate a report for grouped data."""
    print("=" * 60)
    print(title)
    print("=" * 60)
    for key, items in grouped_data.items():
        print(f"\n{key}:")
        print(f"  Count: {len(items)}")
        if isinstance(items[0], (int, float)):
            from . import statistics
            print(f"  Mean: {statistics.calculate_mean(items):.2f}")
    print("=" * 60)
