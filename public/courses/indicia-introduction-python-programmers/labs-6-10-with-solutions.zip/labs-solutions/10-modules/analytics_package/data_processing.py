"""Data processing functions module."""

def filter_data(data, condition_func):
    """Filter data based on a condition function."""
    return [item for item in data if condition_func(item)]

def group_by(data, key_func):
    """Group data by a key function."""
    groups = {}
    for item in data:
        key = key_func(item)
        if key not in groups:
            groups[key] = []
        groups[key].append(item)
    return groups

def aggregate_data(data, key_func, value_func, agg_func):
    """
    Aggregate data.
    
    key_func: function to extract grouping key
    value_func: function to extract value to aggregate
    agg_func: function to aggregate values (e.g., sum, mean)
    """
    grouped = group_by(data, key_func)
    return {
        key: agg_func([value_func(item) for item in items])
        for key, items in grouped.items()
    }
