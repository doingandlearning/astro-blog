"""Utility functions module."""

def validate_numeric_data(data):
    """Validate that data contains only numbers."""
    if not data:
        raise ValueError("Data cannot be empty")
    for item in data:
        if not isinstance(item, (int, float)):
            raise TypeError(f"Invalid data type: {type(item)}")
    return True

def format_number(number, decimals=2):
    """Format a number for display."""
    return f"{number:.{decimals}f}"

def get_module_info():
    """Get information about this module."""
    import sys
    module = sys.modules[__name__]
    return {
        "name": module.__name__,
        "file": module.__file__,
        "doc": module.__doc__
    }
