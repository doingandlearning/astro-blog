"""Business Analytics Package.

A package for statistical analysis and data reporting.
"""

# Import key functions to make them available at package level
from .statistics import (
    calculate_mean,
    calculate_median,
    calculate_mode,
    calculate_standard_deviation
)

from .data_processing import (
    filter_data,
    group_by,
    aggregate_data
)

from .reporting import (
    generate_summary_report,
    generate_grouped_report
)

from .utils import (
    validate_numeric_data,
    format_number
)

# Package metadata
__version__ = "1.0.0"
__author__ = "Your Name"

# Define what gets imported with "from analytics_package import *"
__all__ = [
    # Statistics
    "calculate_mean",
    "calculate_median",
    "calculate_mode",
    "calculate_standard_deviation",
    # Data processing
    "filter_data",
    "group_by",
    "aggregate_data",
    # Reporting
    "generate_summary_report",
    "generate_grouped_report",
    # Utils
    "validate_numeric_data",
    "format_number",
]
