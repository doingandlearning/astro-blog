"""Test module properties and imports."""

import analytics_package
import analytics_package.statistics as stats
import analytics_package.utils as utils

# Test module properties
print("Statistics Module:")
print(f"  Name: {stats.__name__}")
print(f"  File: {stats.__file__}")
print(f"  Doc: {stats.__doc__}")

# Test dir() function
print("\nFunctions in statistics module:")
print([item for item in dir(stats) if not item.startswith("_")])

# Test utils module info
print("\nUtils Module Info:")
info = utils.get_module_info()
for key, value in info.items():
    print(f"  {key}: {value}")
