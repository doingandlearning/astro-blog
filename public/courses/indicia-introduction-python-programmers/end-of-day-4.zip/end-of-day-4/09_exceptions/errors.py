class EmailAlreadyExists(Exception):
    pass
