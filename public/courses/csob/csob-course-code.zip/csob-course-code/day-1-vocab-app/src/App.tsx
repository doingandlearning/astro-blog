import React, { useState } from 'react';
import { WordCard } from './components/WordCard';
import { Column } from './components/Column';
import { CategoryModal } from './components/CategoryModal';
import { wordsData } from './data/words';
import './App.css';

export interface Word {
  id: string;
  text: string;
  category: string;
}

export interface ColumnData {
  id: string;
  title: string;
  words: Word[];
  color: string;
}

const initialColumns: ColumnData[] = [
  {
    id: 'never-heard',
    title: 'Never Heard Of',
    words: [],
    color: '#ff6b6b'
  },
  {
    id: 'heard-of',
    title: 'Heard Of',
    words: [],
    color: '#4ecdc4'
  },
  {
    id: 'could-explain',
    title: 'Could Explain',
    words: [],
    color: '#45b7d1'
  }
];

function App() {
  const [columns, setColumns] = useState<ColumnData[]>(initialColumns);
  const [availableWords, setAvailableWords] = useState<Word[]>(wordsData);
  const [selectedWord, setSelectedWord] = useState<Word | null>(null);
  const [showModal, setShowModal] = useState(false);

  const handleWordClick = (word: Word) => {
    setSelectedWord(word);
    setShowModal(true);
  };

  const handleCategorySelect = (columnId: string) => {
    if (!selectedWord) return;

    // Find which column the word is currently in
    let sourceColumnId: string | null = null;
    const wordInColumn = columns.find(col =>
      col.words.some(w => w.id === selectedWord.id)
    );
    if (wordInColumn) {
      sourceColumnId = wordInColumn.id;
    }

    // Move word to selected column
    setColumns(prevColumns => {
      const newColumns = prevColumns.map(col => {
        if (col.id === columnId) {
          // Add word to target column (if not already there)
          const wordExists = col.words.some(w => w.id === selectedWord.id);
          if (!wordExists) {
            return {
              ...col,
              words: [...col.words, selectedWord]
            };
          }
        } else if (sourceColumnId && col.id === sourceColumnId) {
          // Remove word from source column
          return {
            ...col,
            words: col.words.filter(w => w.id !== selectedWord.id)
          };
        }
        return col;
      });

      return newColumns;
    });

    // If word was in available words, remove it
    if (!sourceColumnId) {
      setAvailableWords(prev => prev.filter(w => w.id !== selectedWord.id));
    }

    setShowModal(false);
    setSelectedWord(null);
  };

  const handleMoveWord = (wordId: string, fromColumnId: string, toColumnId: string) => {
    const word = columns
      .find(col => col.id === fromColumnId)
      ?.words.find(w => w.id === wordId);

    if (!word) return;

    setColumns(prevColumns => {
      return prevColumns.map(col => {
        if (col.id === toColumnId) {
          // Add word to target column
          return {
            ...col,
            words: [...col.words, word]
          };
        } else if (col.id === fromColumnId) {
          // Remove word from source column
          return {
            ...col,
            words: col.words.filter(w => w.id !== wordId)
          };
        }
        return col;
      });
    });
  };

  const resetWords = () => {
    setColumns(initialColumns);
    setAvailableWords(wordsData);
  };

  const getResults = () => {
    const results = columns.map(col => ({
      category: col.title,
      count: col.words.length,
      words: col.words.map(w => w.text)
    }));
    return results;
  };

  const shareResults = () => {
    const results = getResults();
    const text = results.map(r =>
      `${r.category}: ${r.count} words\n${r.words.join(', ')}`
    ).join('\n\n');

    if (navigator.share) {
      navigator.share({
        title: 'My AI Vocabulary Assessment',
        text: text
      });
    } else {
      navigator.clipboard.writeText(text);
      alert('Results copied to clipboard!');
    }
  };

  return (
    <div className="app">
      <header className="app-header">
        <h1>AI Vocabulary</h1>
        <p>Tap words to categorize them based on your knowledge level</p>
        <p>Remember these words might be used in many contexts, so be sure to consider the AI application in question.</p>
      </header>

      <div className="app-content">
        <div className="words-pool">
          <h2>Available Words</h2>
          <div className="words-grid">
            {availableWords.map(word => (
              <WordCard
                key={word.id}
                word={word}
                onClick={() => handleWordClick(word)}
                clickable
              />
            ))}
          </div>
        </div>

        <div className="columns-container">
          {columns.map(column => (
            <Column
              key={column.id}
              column={column}
              onWordClick={handleWordClick}
              onMoveWord={handleMoveWord}
            />
          ))}
        </div>
      </div>

      {showModal && selectedWord && (
        <CategoryModal
          word={selectedWord}
          columns={columns}
          onSelect={handleCategorySelect}
          onClose={() => {
            setShowModal(false);
            setSelectedWord(null);
          }}
        />
      )}

      <div className="app-actions">
        <button onClick={resetWords} className="reset-btn">
          Reset
        </button>
        <button onClick={shareResults} className="share-btn">
          Share Results
        </button>
      </div>
    </div>
  );
}

export default App;