import React from 'react';
import { Word } from '../App';
import './WordCard.css';

interface WordCardProps {
  word: Word;
  onClick?: () => void;
  clickable?: boolean;
  showMoveButtons?: boolean;
  onMoveTo?: (columnId: string) => void;
  availableColumns?: Array<{ id: string; title: string; color: string }>;
}

export const WordCard: React.FC<WordCardProps> = ({
  word,
  onClick,
  clickable = false,
  showMoveButtons = false,
  onMoveTo,
  availableColumns = []
}) => {
  return (
    <div
      className={`word-card ${clickable ? 'clickable' : ''} ${showMoveButtons ? 'with-move-buttons' : ''}`}
      onClick={clickable ? onClick : undefined}
    >
      <span className="word-text">{word.text}</span>
      <span className="word-category">{word.category}</span>

      {showMoveButtons && onMoveTo && availableColumns.length > 0 && (
        <div className="move-section">
          <div className="move-header">Move to:</div>
          <div className="move-buttons">
            {availableColumns.map(column => (
              <button
                key={column.id}
                className="move-btn"
                style={{ backgroundColor: column.color }}
                onClick={(e) => {
                  e.stopPropagation();
                  onMoveTo(column.id);
                }}
                title={`Move to ${column.title}`}
              >
                {column.title.split(' ')[0]}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
