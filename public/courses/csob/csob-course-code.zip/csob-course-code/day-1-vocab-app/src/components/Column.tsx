import React from 'react';
import { WordCard } from './WordCard';
import { ColumnData } from '../App';
import './Column.css';

interface ColumnProps {
  column: ColumnData;
  onWordClick?: (word: any) => void;
  onMoveWord?: (wordId: string, fromColumnId: string, toColumnId: string) => void;
}

export const Column: React.FC<ColumnProps> = ({ column, onWordClick, onMoveWord }) => {
  const otherColumns = [
    { id: 'never-heard', title: 'Never Heard Of', color: '#ff6b6b' },
    { id: 'heard-of', title: 'Heard Of', color: '#4ecdc4' },
    { id: 'could-explain', title: 'Could Explain', color: '#45b7d1' }
  ].filter(col => col.id !== column.id);

  return (
    <div className="column" style={{ borderTopColor: column.color }}>
      <div className="column-header">
        <h3>{column.title}</h3>
        <span className="word-count">{column.words.length}</span>
      </div>

      <div className="column-content">
        {column.words.length === 0 ? (
          <div className="empty-column">
            <p>Tap words above to categorize them</p>
          </div>
        ) : (
          <div className="words-list">
            {column.words.map(word => (
              <WordCard
                key={word.id}
                word={word}
                onClick={onWordClick ? () => onWordClick(word) : undefined}
                clickable={!!onWordClick}
                showMoveButtons={!!onMoveWord}
                onMoveTo={onMoveWord ? (toColumnId) => onMoveWord(word.id, column.id, toColumnId) : undefined}
                availableColumns={otherColumns}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
