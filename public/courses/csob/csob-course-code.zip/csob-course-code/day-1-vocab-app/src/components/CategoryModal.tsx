import React from 'react';
import { Word, ColumnData } from '../App';
import './CategoryModal.css';

interface CategoryModalProps {
  word: Word;
  columns: ColumnData[];
  onSelect: (columnId: string) => void;
  onClose: () => void;
}

export const CategoryModal: React.FC<CategoryModalProps> = ({ 
  word, 
  columns, 
  onSelect, 
  onClose 
}) => {
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h3>Where would you place this term?</h3>
          <div className="selected-word">
            <strong>{word.text}</strong>
            <span className="word-category">{word.category}</span>
          </div>
        </div>
        
        <div className="category-options">
          {columns.map(column => (
            <button
              key={column.id}
              className="category-btn"
              style={{ 
                backgroundColor: column.color,
                borderColor: column.color
              }}
              onClick={() => onSelect(column.id)}
            >
              <span className="category-title">{column.title}</span>
              <span className="category-count">{column.words.length} words</span>
            </button>
          ))}
        </div>
        
        <div className="modal-actions">
          <button className="cancel-btn" onClick={onClose}>
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};
