import { Word } from '../App';

// CSOB Day 1 terminology hour (Enterprise Agentic Systems: Foundations).
// The same 28 terms as the rating sheet in terminology-session.md.
// To use: in src/App.tsx, change the import of wordsData to come from './data/words.csob'.
export const wordsData: Word[] = [
  // Models
  { id: 'models-1', text: 'Token', category: 'Models' },
  { id: 'models-2', text: 'Context Window', category: 'Models' },
  { id: 'models-3', text: 'Inference', category: 'Models' },
  { id: 'models-4', text: 'Non-deterministic', category: 'Models' },
  { id: 'models-5', text: 'Prompt', category: 'Models' },

  // Agents
  { id: 'agents-1', text: 'Tool Calling', category: 'Agents' },
  { id: 'agents-2', text: 'Workflow', category: 'Agents' },
  { id: 'agents-3', text: 'Copilot', category: 'Agents' },
  { id: 'agents-4', text: 'Agent', category: 'Agents' },
  { id: 'agents-5', text: 'Harness', category: 'Agents' },

  // Knowledge
  { id: 'knowledge-1', text: 'Embedding', category: 'Knowledge' },
  { id: 'knowledge-2', text: 'Vector Store', category: 'Knowledge' },
  { id: 'knowledge-3', text: 'Chunk', category: 'Knowledge' },
  { id: 'knowledge-4', text: 'RAG', category: 'Knowledge' },
  { id: 'knowledge-5', text: 'Grounding', category: 'Knowledge' },
  { id: 'knowledge-6', text: 'Hallucination', category: 'Knowledge' },

  // Plumbing
  { id: 'plumbing-1', text: 'API', category: 'Plumbing' },
  { id: 'plumbing-2', text: 'MCP', category: 'Plumbing' },
  { id: 'plumbing-3', text: 'Skill', category: 'Plumbing' },
  { id: 'plumbing-4', text: 'Gateway', category: 'Plumbing' },
  { id: 'plumbing-5', text: 'Guardrail', category: 'Plumbing' },
  { id: 'plumbing-6', text: 'Trace', category: 'Plumbing' },

  // Risk
  { id: 'risk-1', text: 'Prompt Injection', category: 'Risk' },
  { id: 'risk-2', text: 'Jailbreak', category: 'Risk' },
  { id: 'risk-3', text: 'Data Leakage', category: 'Risk' },
  { id: 'risk-4', text: 'Excessive Agency', category: 'Risk' },
  { id: 'risk-5', text: 'Supply Chain', category: 'Risk' },
  { id: 'risk-6', text: 'Drift', category: 'Risk' },
];
