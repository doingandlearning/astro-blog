import { Word } from '../App';

export const wordsData: Word[] = [
  // AI Basics
  { id: 'ai-basics-1', text: 'Artificial Intelligence (AI)', category: 'AI Basics' },
  { id: 'ai-basics-2', text: 'Machine Learning (ML)', category: 'AI Basics' },
  { id: 'ai-basics-3', text: 'Generative AI (GenAI)', category: 'AI Basics' },
  { id: 'ai-basics-4', text: 'Large Language Model (LLM)', category: 'AI Basics' },
  { id: 'ai-basics-5', text: 'Neural Network', category: 'AI Basics' },

  // Technical Terms
  { id: 'tech-1', text: 'Prompt', category: 'Technical Terms' },
  { id: 'tech-2', text: 'Context Window', category: 'Technical Terms' },
  { id: 'tech-3', text: 'Token', category: 'Technical Terms' },
  { id: 'tech-4', text: 'Fine-tuning', category: 'Technical Terms' },
  { id: 'tech-5', text: 'Embeddings', category: 'Technical Terms' },

  // AI in Practice
  { id: 'practice-1', text: 'Recommendation System', category: 'AI in Practice' },
  { id: 'practice-2', text: 'Natural Language Processing (NLP)', category: 'AI in Practice' },
  { id: 'practice-3', text: 'Agent', category: 'AI in Practice' },
  { id: 'practice-4', text: 'Workflow Automation', category: 'AI in Practice' },
  { id: 'practice-5', text: 'Reinforcement Learning', category: 'AI in Practice' },

  // Model Behaviour
  { id: 'behavior-1', text: 'Hallucination', category: 'Model Behaviour' },
  { id: 'behavior-2', text: 'Bias', category: 'Model Behaviour' },
  { id: 'behavior-3', text: 'Fairness', category: 'Model Behaviour' },
  { id: 'behavior-4', text: 'Explainability', category: 'Model Behaviour' },
  { id: 'behavior-5', text: 'Transparency', category: 'Model Behaviour' },

  // Responsible Use
  { id: 'responsible-1', text: 'Data Privacy', category: 'Responsible Use' },
  { id: 'responsible-2', text: 'Human-in-the-loop', category: 'Responsible Use' },
  { id: 'responsible-3', text: 'Risk Assessment', category: 'Responsible Use' },
  { id: 'responsible-4', text: 'Oversight', category: 'Responsible Use' },
  { id: 'responsible-5', text: 'Guardrails', category: 'Responsible Use' },
];
