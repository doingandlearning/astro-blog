# Day 4 exhibits: show the code, config and tools

Small files for the presenter to open on the projector from an editor, as on Day 3. Nobody in the room is asked to read or write code. The point is that the ideas from the paper activities exist as a few lines of something they recognise. Keep code and slides separate: put the editor on screen, do the exhibit, go back to the deck.

Each exhibit follows the same drill: **ask first (a card or a sticky), then run or open it, then say one sentence.** Nothing here adds time to the day. Every exhibit sits inside a slot that already exists.

All three scripts use only the Python standard library. Run them from this folder with `python3`. They were run while preparing this pack, and the output matches the paper activities.

| # | Exhibit | Where in the day | Time | Ask first | The one sentence |
| --- | --- | --- | --- | --- | --- |
| 1 | `01_budget_guard.py` | 11:20, with slide 11 | 2 min | "How much would a loop between two agents have spent by the morning?" (write a number on a sticky) | The first line is the answer to your sticky. The other three lines are one setting each. An alert tells somebody; a cap stops the work |
| 2 | `02_cost_alert.py` with `cost_ledger.csv` | 11:24, with slide 12 | 2 min | "Which of the four rules will fire on the busy day?" (cards: A, B, C, D, or none) | Cost per day fires on the busy day and wakes someone up for nothing. Cost per case sees the loop. Nothing sees the new feature except a re-test |
| 3 | `03_alert_rule.json` and `03_apply_alert.py` with `six_nights.csv` | 13:23, with slide 16 | 2 min | "Which nights will this rule page?" (E for page, N for nothing, cards up on each) | A rule that can be run gives everyone the same answer. The probes show it can still be wrong: a threshold in the wrong place, and a night that recovered |
| 4 | Day 3 `08_trace_stamp.py` | 13:25, with slide 16 | 1 min | "What would you need to know to tie an incident to what was running?" | Twelve lines stamp every trace with the configuration revision. This is the line that made night 4 a notification and not a mystery |
| 5 | `guardrails.yaml` from `demos/03-guardrails-demo` | 13:47, inside the guardrails demo, step 4 | 2 min | "Does anything in here say what happens to a request it does not list?" | This is configuration. It has a revision, an owner and a test set. Change it and the configuration record changes |

Exhibit 4 is the one from Day 3 (`day-3-reliability/exhibits/08_trace_stamp.py`). Run it from that folder with `uv run --with opentelemetry-sdk 08_trace_stamp.py`. If you do not want to run it, skip it and say the sentence over slide 16.

## What the data is

`cost_ledger.csv` is the ledger on the paper sheet: fourteen days of one fictional bank's agents. `six_nights.csv` is the six-nights sheet. Both are invented. Nothing here is CSOB data or a description of CSOB's systems.

## What is tested and what is not

| File | Status |
| --- | --- |
| 01 | Run while preparing this pack. The first line (no limit, eight hours) prints about EUR 163 and the capped lines stop in about a minute and an hour |
| 02 | Run. Rule A fires on day 6 (the busy day) and on days 10 to 13. Rules B and C fire on days 10 to 13 and not on day 6. Rule D fires on days 4 to 6 |
| 03 | Run. Nights 1 to 6 give nothing, nothing, PAGE, NOTIFY, PAGE, nothing. Probe 7 gives nothing (a miss). Probe 8 pages (a false alarm) |
| guardrails.yaml | Not changed. It belongs to the demo and is tested with it |

## Things to say carefully

- These are illustrations of a pattern, not CSOB's design and not a recommendation of any product.
- If anyone asks whether exhibit 3 means "do it with thresholds": no. It shows what testable means and where that approach fails.
- The incident the ledger echoes (card 3) is self-reported. Do not quote its figures as established.
