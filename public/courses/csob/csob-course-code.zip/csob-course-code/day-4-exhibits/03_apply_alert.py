"""Exhibit 3: apply one written alert rule to the six nights, plus two probes.

Run with:  python3 03_apply_alert.py
"""
import csv
import json
from pathlib import Path

here = Path(__file__).parent
rule = json.load(open(here / "03_alert_rule.json"))
nights = list(csv.DictReader(open(here / "six_nights.csv")))

# Two probes that show where a rule written like this can still be wrong.
probes = [
    {"night": "P7", "duration_min": "70", "retries": "10", "compared_pct": "97", "discrepancies": "8",
     "cost_eur": "0.95", "config_rev": "r42",
     "agent_message": "Run completed. 8 discrepancies flagged for review.",
     "about": "3 per cent of transactions were not compared, and they are the large ones"},
    {"night": "P8", "duration_min": "75", "retries": "22", "compared_pct": "100", "discrepancies": "10",
     "cost_eur": "0.93", "config_rev": "r42",
     "agent_message": "Run completed. 10 discrepancies flagged for review.",
     "about": "22 short retries over the night, then everything was compared"},
]


def to_num(v):
    return float(v) if v.replace(".", "", 1).isdigit() else v


def decide(n, previous_rev):
    pages = []
    for c in rule["page_if_any"]:
        v = float(n[c["measure"]])
        if "at_least" in c and v >= c["at_least"]:
            pages.append(f"{c['measure']} {v:g} is at least {c['at_least']}")
        if "below" in c and v < c["below"]:
            pages.append(f"{c['measure']} {v:g} is below {c['below']}")
        if "equals" in c and v == c["equals"] and float(n["duration_min"]) < c["and_duration_min_below"]:
            pages.append(f"{c['measure']} is {v:g} after a run of only {n['duration_min']} minutes")
    if pages:
        return "PAGE", "; ".join(pages)
    if previous_rev and n["config_rev"] != previous_rev:
        return "NOTIFY", f"configuration revision changed from {previous_rev} to {n['config_rev']}"
    return "nothing", ""


print(f"{'night':6} {'decision':8} why")
prev = None
for n in nights + probes:
    decision, why = decide(n, prev)
    extra = f"  [{n['about']}]" if "about" in n else ""
    print(f"{n['night']:6} {decision:8} {why}{extra}")
    prev = n["config_rev"]

print()
print("Expected on nights 1 to 6: nothing, nothing, PAGE, NOTIFY, PAGE, nothing.")
print("P7: the rule says nothing. It is a threshold, and a threshold can be set in the wrong place.")
print("P8: the rule pages for a night that recovered. Specific is not the same as right.")
print("A rule that can be run gives everyone the same answer. That is what 'specific' means.")
