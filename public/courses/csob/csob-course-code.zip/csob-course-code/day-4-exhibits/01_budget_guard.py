"""Exhibit 1: a loop between two agents, with and without a cap.

Nothing here calls a model. Each pretend call costs the same and takes the same
time, so the only thing that changes between runs is the rule that stops it.
Run with:  python3 01_budget_guard.py
"""

COST_PER_CALL_EUR = 0.0227   # the loop days in the cost ledger work out at about this
SECONDS_PER_CALL = 4         # one clarification, one reply
DEMO_BOUND_HOURS = 8         # "by the morning"


def run(policy):
    calls, cost, seconds = 0, 0.0, 0
    reason = "demo bound: 8 hours"
    while seconds < DEMO_BOUND_HOURS * 3600:
        if policy.get("max_turns") and calls >= policy["max_turns"]:
            reason = "turn cap"
            break
        if policy.get("max_cost_eur") and cost + COST_PER_CALL_EUR > policy["max_cost_eur"]:
            reason = "cost cap per run"
            break
        if policy.get("hourly_budget_eur") and cost + COST_PER_CALL_EUR > policy["hourly_budget_eur"] * (seconds // 3600 + 1):
            # budget for the hour is spent: stop and page, do not wait for the next hour
            reason = "hourly budget"
            break
        calls += 1
        cost += COST_PER_CALL_EUR
        seconds += SECONDS_PER_CALL
    return calls, cost, seconds, reason


def fmt_time(seconds):
    if seconds >= 3600:
        return f"{seconds // 3600}h{(seconds % 3600) // 60:02d}"
    if seconds >= 60:
        return f"{seconds // 60} min"
    return f"{seconds} s"


policies = [
    ("no limit at all", {}),
    ("turn cap: 20", {"max_turns": 20}),
    ("cost cap per run: EUR 0.50", {"max_cost_eur": 0.50}),
    ("hourly budget: EUR 20", {"hourly_budget_eur": 20}),
]

print(f"{'rule':32} {'calls':>7} {'cost EUR':>9} {'time to stop':>13}  stopped by")
for name, policy in policies:
    calls, cost, seconds, reason = run(policy)
    print(f"{name:32} {calls:>7} {cost:>9.2f} {fmt_time(seconds):>13}  {reason}")

print()
print("The first line is 'by the morning'. The rest are one setting each.")
print("An alert tells somebody. A cap stops the work. You want both, and a name against the alert.")
