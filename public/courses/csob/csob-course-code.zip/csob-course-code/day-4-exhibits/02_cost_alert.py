"""Exhibit 2: four ways to alert on the cost ledger, and what each does on the odd days.

Reads cost_ledger.csv (the same fourteen days as the paper activity).
Run with:  python3 02_cost_alert.py
"""
import csv
import statistics
from pathlib import Path

rows = list(csv.DictReader(open(Path(__file__).with_name("cost_ledger.csv"))))
days = []
for r in rows:
    cases, calls, cost = int(r["cases"]), int(r["model_calls"]), float(r["cost_eur"])
    days.append({
        "day": int(r["day"]), "cost": cost,
        "per_case": cost / cases, "calls_per_case": calls / cases, "per_call": cost / calls,
        "note": r["note"],
    })


def trailing_median(i, key, window=7):
    earlier = [d[key] for d in days[max(0, i - window):i]]
    return statistics.median(earlier) if earlier else None


rules = [
    ("A  cost per day above 1.5x the usual", "cost", 1.5, "page"),
    ("B  cost per case above 2x the usual", "per_case", 2.0, "page"),
    ("C  model calls per case above 2x the usual", "calls_per_case", 2.0, "page"),
    ("D  cost per call above 1.2x the usual", "per_call", 1.2, "notify the owner of the configuration record"),
]

print("Day  note" + " " * 40 + "A  B  C  D")
flags = {}
for i, d in enumerate(days):
    marks = []
    for label, key, factor, action in rules:
        base = trailing_median(i, key)
        hit = base is not None and d[key] > factor * base
        marks.append("X" if hit else ".")
    flags[d["day"]] = marks
    print(f"{d['day']:>3}  {d['note']:44}" + "  ".join(marks))

print()
for label, key, factor, action in rules:
    print(f"{label}  ->  {action}")
print()
print("Read the table:")
print("- Day 4 (model alias moved): only D sees it, and keeps seeing it for a few days until the new")
print("  price becomes 'the usual'. It should notify the owner of the configuration record, not stop anything.")
print("- Day 6 (month-end rush): A fires and nothing is wrong. Cost per day is the wrong measure.")
print("- Day 8 (new feature): nothing fires. Only a trend, or a re-test after the release, would show it.")
print("- Day 10 (the loop): B and C fire on the first day. This is still a daily ledger:")
print("  the loop has been running for hours before any of these rules can see it.")
print("- A cap (exhibit 1) acts in minutes. An alert tells a person. You need both.")
