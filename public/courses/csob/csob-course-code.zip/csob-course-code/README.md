# Enterprise Agentic Systems: Foundations (code shown on the course)

- demos/ : the five live demos (hybrid search, prompt injection, guardrails, MCP, a small agent). Each has its own README. The three that call a model need your own API key: copy .env.example to .env and add it.
- day-1-vocab-app/ : the vocabulary sorting app from Day 1 (Vite and React).
- day-3-exhibits/ : retry, configuration diff, output schema, tool policy and trigger exhibits.
- day-4-exhibits/ : budget guard, cost alert and the cost ledger data.
