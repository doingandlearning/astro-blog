# Demo guide: guardrails live (about 25 minutes)

Page: http://127.0.0.1:8091. The room watches and reacts; nobody uses the app. Treat it as testing a control, not a magic trick. Say which model it is (footer) and that the assistant is deliberately naive.

## The one point

A guardrail is a control with an error rate. It can sit in four places. Each catches different things, each misses things, each costs something when wrong.

## Before the room arrives

Follow the README rehearsal checklist. Press Reset: the page shows "Press Baseline to begin".

## Script

**1. Baseline (about 4 min).** Press **Baseline**. Run the three requests. Ask the room what will happen first. Normal question: fine. Document with a hidden instruction: the settlement account appears (tick "Highlight the hidden instruction" to show where it was). Refund of 450: issued, against a limit of 100. Tick "Show what the model actually received" once so sceptics see there is no trick.

**2. Input guardrail (about 4 min).** Press **Input guardrail on**. Run the hidden-instruction document again: blocked, and the model is never called. Say why (a rule, shown on screen). Now **Reworded attack (Czech)**: it gets through. Say plainly: that is a false negative. The rules and classifier only know English.

**3. Output guardrail (about 4 min).** Press **Output guardrail on**. Run the reworded attack: the account number is redacted. Then **Complaint reference**: the customer's own reference is redacted too. That is a false positive; ask what it costs the customer and the call centre.

**4. Action guardrail (about 4 min).** Press **Action guardrail on**. Show the policy (Settings file button): short, readable, default deny, evaluated by code, not by the model. Run **Refund of 450**: denied whatever the model was talked into. Run **Borderline refund of 180**: denied too. A guardrail alone is too blunt for a reasonable request.

**5. Human approval (about 3 min).** Press **Human approval on**. Run the borderline refund: held. Walk through what the approver sees: request, reason, evidence, the rule. Approve or reject. Ask: what if the approver clicks through all day?

**6. Scorecard (about 6 min).** Press **Run scorecard** (about a minute live). Read the table row by row: each layer alone, then all four. Open "Show the labelled test set" so the room sees labels and notes. Move the slider down: more attacks caught, more genuine customers blocked. Open the settings file: this is configuration, with a revision, and belongs in the agent's configuration record. Say it was tuned on this test set, so it illustrates trade-offs and is not a measurement.

## If someone says "you rigged it"

Toggle "Show what the model actually received". Every decision is explainable from the settings file and the prompt. Offer to run it again: the model is real, and the checks are code.

## If it misbehaves on the day

- An attack does not fire at baseline: say so and treat it as a talking point (the model resisted; that is not a control and can change with a version). Then use the recording and keep the banner on screen.
- API or network down: `./run.sh --replay`, or play the capture from `export/`, narrating from `capture-script.txt`.
- Do not claim a recording is live.
