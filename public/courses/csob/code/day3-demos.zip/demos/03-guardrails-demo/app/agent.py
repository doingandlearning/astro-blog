"""The agent: one system prompt, one stub tool, one short loop. The loop does not decide what is
allowed. Every proposed tool call goes through `gate`, which the pipeline supplies."""
import copy

from .tools import REFUND_TOOL

MAX_TURNS = 4


def _text(content) -> str:
    return "".join(b["text"] for b in content if b["type"] == "text")


def run_agent(llm, *, system, user_content, gate, execute) -> dict:
    """gate(name, args) -> {"decision", "rule", "reason", "result"?}; execute(name, args) -> tool result text.
    Returns {"output", "calls" (every request exactly as sent), "tool_events"}."""
    messages = [{"role": "user", "content": user_content}]
    calls, events, output = [], [], ""
    for _ in range(MAX_TURNS):
        calls.append({"system": system, "messages": copy.deepcopy(messages), "tools": [REFUND_TOOL["name"]]})
        resp = llm.complete(system=system, messages=messages, tools=[REFUND_TOOL])
        messages.append({"role": "assistant", "content": resp["content"]})
        output = _text(resp["content"])
        uses = [b for b in resp["content"] if b["type"] == "tool_use"]
        if not uses:
            break
        results = []
        for u in uses:
            g = gate(u["name"], u["input"])
            if g["decision"] == "allow":
                text, is_error = execute(u["name"], u["input"]), False
            else:
                text, is_error = g["result"], True
            events.append({"name": u["name"], "args": u["input"], "decision": g["decision"], "rule": g["rule"],
                           "reason": g["reason"], "ticket": g.get("ticket"), "result": text})
            results.append({"type": "tool_result", "tool_use_id": u["id"], "content": text, "is_error": is_error})
        messages.append({"role": "user", "content": results})
    return {"output": output, "calls": calls, "tool_events": events}
