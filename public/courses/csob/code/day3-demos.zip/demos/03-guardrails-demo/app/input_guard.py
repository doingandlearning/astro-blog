"""Input guardrail: a plain rule list, then a small local classifier, over the user's message
and any pasted content. Pure code, no network.

The classifier is a weighted feature list with a logistic curve, written by hand in
guardrails.yaml. It knows English wording only, which is exactly why a reworded or
non-English attack can pass it. Pasted documents are scored paragraph by paragraph, so a
long legitimate document does not add up to a false alarm."""
import math
import re

from .guardrails import Config, rx


def rule_hits(cfg: Config, text: str) -> list:
    hits = []
    for rule in cfg.input["rules"]:
        m = rx(rule["pattern"]).search(text)
        if m:
            hits.append({"rule": rule["id"], "match": m.group(0).strip()})
    return hits


def classify(cfg: Config, text: str) -> dict:
    c = cfg.input["classifier"]
    logit, matched = float(c["bias"]), []
    for f in c["features"]:
        if rx(f["pattern"], re.IGNORECASE | re.DOTALL).search(text):
            logit += float(f["weight"])
            matched.append(f["id"])
    return {"score": 1.0 / (1.0 + math.exp(-logit)), "features": matched}


def _chunks(document: str) -> list:
    return [p.strip() for p in re.split(r"\n\s*\n", document) if p.strip()]


def _snippet(text: str, n: int = 90) -> str:
    one = " ".join(text.split())
    return one if len(one) <= n else one[: n - 1] + "…"


def check(cfg: Config, message: str, document: str | None = None) -> dict:
    """Returns {"decision": "allow"|"block", "reason", "part", "rule", "score", "threshold", "features", "snippet"}."""
    parts = [("message", t) for t in [message]]
    if document:
        parts += [("pasted document", p) for p in _chunks(document)]
    threshold = cfg.threshold
    top = {"score": -1.0, "features": [], "part": "message", "snippet": ""}
    for part, text in parts:
        hits = rule_hits(cfg, text)
        res = classify(cfg, text)
        if hits:
            h = hits[0]
            return {"decision": "block", "part": part, "rule": h["rule"], "score": round(res["score"], 3),
                    "threshold": threshold, "features": res["features"], "snippet": _snippet(text),
                    "reason": f"Rule '{h['rule']}' matched in the {part}: \"{h['match']}\". Rules block whatever the score."}
        if res["score"] > top["score"]:
            top = {**res, "part": part, "snippet": _snippet(text)}
    score = round(top["score"], 3)
    feats = ", ".join(top["features"]) or "none"
    if top["score"] >= threshold:
        return {"decision": "block", "part": top["part"], "rule": None, "score": score, "threshold": threshold,
                "features": top["features"], "snippet": top["snippet"],
                "reason": f"Classifier score {score:.2f} is at or above the threshold {threshold:.2f} in the {top['part']} (features: {feats})."}
    return {"decision": "allow", "part": top["part"], "rule": None, "score": score, "threshold": threshold,
            "features": top["features"], "snippet": top["snippet"],
            "reason": f"No rule matched. Highest classifier score {score:.2f} is below the threshold {threshold:.2f} (features: {feats})."}
