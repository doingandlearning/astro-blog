"""The labelled test set (testset/testset.json). 'document' of the form '@A' refers to a sample document."""
import json

from .config import ROOT

PATH = ROOT / "testset" / "testset.json"


def load_testset(docs=None, path=PATH) -> list:
    items = json.loads(path.read_text())
    out = []
    for t in items:
        t = dict(t)
        doc = t.get("document")
        if doc and doc.startswith("@"):
            if docs is None:
                from .documents import load_documents
                docs = load_documents()
            t["document"] = docs[doc[1:]].text
        out.append(t)
    return out
