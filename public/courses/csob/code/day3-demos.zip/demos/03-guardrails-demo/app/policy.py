"""Action guardrail and human escalation rule: deterministic code evaluating the policy section of
guardrails.yaml. Nothing here calls a model, and nothing the model says can change the result.

Default deny: a tool that is not listed, or arguments that do not fit, are refused."""
import math

from .guardrails import Config

ALLOW, DENY, ESCALATE = "allow", "deny", "escalate"


def _d(decision, rule, reason):
    return {"decision": decision, "rule": rule, "reason": reason}


def _amount(args):
    a = args.get("amount")
    if isinstance(a, bool) or not isinstance(a, (int, float)) or not math.isfinite(a):
        return None
    return float(a)


def _deterministic(cfg: Config, tool: str, args: dict, human_on: bool) -> dict:
    p = cfg.policy
    if tool not in p["allowed_tools"]:
        return _d(DENY, "tool-not-allowed", f"Tool '{tool}' is not in allowed_tools. Default is {p['default']}.")
    spec = p[tool]
    missing = [k for k in spec["required"] if k not in args]
    extra = [k for k in args if k not in spec["required"]]
    if missing or extra:
        return _d(DENY, "bad-arguments", f"Arguments do not match the policy (missing: {missing or 'none'}, unexpected: {extra or 'none'}).")
    amount = _amount(args)
    if amount is None or amount <= float(spec["amount_min_exclusive"]):
        return _d(DENY, "bad-amount", f"Amount {args.get('amount')!r} is not a number above {spec['amount_min_exclusive']}.")
    if not isinstance(args["customer_ref"], str) or not args["customer_ref"].strip() or not isinstance(args["reason"], str) or not args["reason"].strip():
        return _d(DENY, "bad-arguments", "customer_ref and reason must be non-empty text.")
    limit, band = float(spec["auto_approve_up_to"]), float(spec["approval_band_up_to"])
    if amount <= limit:
        return _d(ALLOW, "within-limit", f"Refund of {amount:.2f} is within the automatic limit of {limit:.2f}.")
    if amount <= band and human_on:
        return _d(ESCALATE, "needs-approval", f"Refund of {amount:.2f} is above the limit of {limit:.2f} and within the approval band (up to {band:.2f}). A person must approve it.")
    if amount <= band:
        return _d(DENY, "over-limit", f"Refund of {amount:.2f} is above the limit of {limit:.2f}. No human approval is switched on, so default deny applies.")
    return _d(DENY, "over-hard-cap", f"Refund of {amount:.2f} is above the approval band of {band:.2f}. Nobody can approve it here.")


def evaluate(cfg: Config, tool: str, args: dict, *, action_on: bool, human_on: bool) -> dict:
    """What happens to a proposed tool call, given which layers are switched on."""
    if action_on:
        return _deterministic(cfg, tool, args, human_on)
    if human_on and tool == "issue_refund":
        # A human layer alone: anything over the limit goes to a person, nothing else is checked.
        amount = _amount(args)
        limit = cfg.refund_limit
        if amount is not None and amount > limit:
            return _d(ESCALATE, "needs-approval", f"Refund of {amount:.2f} is above the limit of {limit:.2f}. A person must approve it.")
    return _d(ALLOW, "no-action-guardrail", "No action guardrail is switched on, so the call goes straight to the tool.")
