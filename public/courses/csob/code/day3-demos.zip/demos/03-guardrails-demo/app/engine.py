"""Runs scenarios and the scorecard, live or from a recording, and tracks script order."""
import copy
import json

from . import scorecard as sc
from .documents import load_documents
from .guardrails import load_config
from .llm import AnthropicLLM
from .pipeline import run_request
from .prompts import SYSTEM_PROMPT
from .scenarios import SCENARIOS, key as skey
from .stepper import LAYERS_AT, STEP_NAMES, OrderError, Stepper
from .testset import load_testset
from .tools import ApprovalQueue, RefundLedger
from .verdict import verdict


class RecordingError(RuntimeError):
    pass


def run_scenario(llm, cfg, docs, step, scenario_id, ledger=None, queue=None) -> dict:
    """One real run of one scenario at one step. This is the only place scenario results are produced."""
    sc_ = SCENARIOS[scenario_id]
    layers = LAYERS_AT[step]
    doc = docs[sc_.doc].text if sc_.doc else None
    r = run_request(llm, cfg, layers, sc_.message, doc, ledger, queue)
    r.update({"key": skey(step, scenario_id), "scenario": scenario_id, "step": step, "doc_id": sc_.doc,
              "kind": sc_.kind, "system_prompt": SYSTEM_PROMPT, "rev": cfg.rev, "replay": False,
              "settings": llm.effective_settings()})
    r["verdict"] = verdict(sc_.kind, r)
    return r


def load_recording(path) -> dict:
    try:
        return json.loads(path.read_text())
    except FileNotFoundError:
        raise RecordingError(f"No recording at {path}. Run ./record.sh first.") from None


class Engine:
    def __init__(self, settings, llm=None, recording=None, llm_factory=AnthropicLLM, docs=None, cfg=None):
        self.settings = settings
        self.docs = docs or load_documents()
        self.base_cfg = cfg or load_config(settings.guardrails_path)
        self.cfg = self.base_cfg
        self.testset = load_testset(self.docs)
        self._llm, self._llm_factory = llm, llm_factory
        self.stepper = Stepper()
        self.traces = None
        self.ledger = RefundLedger()
        self.queue = ApprovalQueue(self.ledger, self.base_cfg.data["human"]["approver_role"])
        self.recording = None
        if settings.mode == "replay":
            self.recording = recording if recording is not None else load_recording(settings.recording_path)
            self.traces = self.recording.get("scorecard_traces")

    def _get_llm(self):
        if self._llm is None:
            self._llm = self._llm_factory(self.settings)
        return self._llm

    def configured_settings(self) -> dict:
        if self.recording:
            return self.recording["settings"]
        if self._llm is not None:
            return self._llm.effective_settings()
        s = self.settings
        return {"model": s.model, "temperature": s.temperature, "max_tokens": s.max_tokens}

    def available(self) -> list:
        if not self.stepper.can_run_scenarios():
            return []
        p = self.stepper.progress
        out = [s.id for s in SCENARIOS.values() if s.first_step <= p]
        if self.recording is not None:
            out = [i for i in out if skey(p, i) in self.recording["results"]]
        return out

    def state(self) -> dict:
        info = None
        if self.recording:
            info = {"recorded_at": self.recording.get("recorded_at"), "model": self.recording["settings"]["model"],
                    "rev": self.recording.get("rev")}
        n = self.stepper.next_step()
        return {"progress": self.stepper.progress, "next_step": n, "layers": list(self.stepper.layers()),
                "available": self.available(), "mode": self.settings.mode, "settings": self.configured_settings(),
                "recording": info, "rev": self.cfg.rev, "file_rev": self.cfg.file_rev,
                "threshold": self.cfg.threshold, "threshold_overridden": self.cfg.override is not None,
                "steps": STEP_NAMES, "system_prompt": SYSTEM_PROMPT,
                "tickets": [dict(t) for t in self.queue.tickets.values()]}

    def reset(self):
        self.stepper.reset()
        self.cfg = self.base_cfg
        self.ledger = RefundLedger()
        self.queue = ApprovalQueue(self.ledger, self.base_cfg.data["human"]["approver_role"])

    def advance(self, step: int):
        self.stepper.advance(step)

    def perform(self, scenario_id: str) -> dict:
        if scenario_id not in SCENARIOS:
            raise ValueError(f"Unknown request {scenario_id!r}")
        if scenario_id not in self.available():
            raise OrderError("That request is not available at this step.")
        step = self.stepper.progress
        if self.recording is not None:
            try:
                result = copy.deepcopy(self.recording["results"][skey(step, scenario_id)])
            except KeyError:
                raise RecordingError(f"The recording has no result for {skey(step, scenario_id)}. Re-record.") from None
            result["replay"] = True
            return result
        return run_scenario(self._get_llm(), self.cfg, self.docs, step, scenario_id, self.ledger, self.queue)

    def resolve_ticket(self, tid: str, approve: bool) -> dict:
        if self.recording is not None:
            raise OrderError("This is a recorded run: approvals are not live. Start without --replay to approve or reject.")
        return dict(self.queue.resolve(tid, approve))

    def scorecard(self, threshold=None, progress_cb=None) -> dict:
        if self.stepper.progress != 6:
            raise OrderError("The scorecard is step 6. Follow the steps in order.")
        if threshold is not None:
            self.cfg = self.base_cfg.with_threshold(threshold)
        if self.traces is None:
            self.traces = sc.collect_traces(self._get_llm(), self.base_cfg, self.testset, self.settings.workers, progress_cb)
        out = sc.evaluate(self.cfg, self.testset, self.traces)
        out["file_rev"] = self.cfg.file_rev
        out["overridden"] = self.cfg.override is not None
        out["replay"] = self.recording is not None
        return out
