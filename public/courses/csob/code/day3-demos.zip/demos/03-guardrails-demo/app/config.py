"""Settings, read from environment variables. No secrets live in the repository."""
import os
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

# The server binds to this address and no other.
HOST = "127.0.0.1"


@dataclass(frozen=True)
class Settings:
    model: str
    mode: str  # "live" or "replay"
    max_tokens: int
    temperature: float
    port: int
    recording_path: Path
    guardrails_path: Path
    workers: int  # parallel model calls for the scorecard and rehearsal


def load_settings(env=None) -> Settings:
    env = os.environ if env is None else env
    mode = env.get("DEMO_MODE", "live")
    if mode not in ("live", "replay"):
        raise ValueError(f"DEMO_MODE must be 'live' or 'replay', got {mode!r}")
    return Settings(
        model=env.get("DEMO_MODEL", "claude-haiku-5-5"),
        mode=mode,
        max_tokens=int(env.get("DEMO_MAX_TOKENS", "600")),
        temperature=float(env.get("DEMO_TEMPERATURE", "0")),
        port=int(env.get("DEMO_PORT", "8091")),
        recording_path=Path(env.get("DEMO_RECORDING", ROOT / "recordings" / "run.json")),
        guardrails_path=Path(env.get("DEMO_GUARDRAILS", ROOT / "guardrails.yaml")),
        workers=int(env.get("DEMO_WORKERS", "4")),
    )
