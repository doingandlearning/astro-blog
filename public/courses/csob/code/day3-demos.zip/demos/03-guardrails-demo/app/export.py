"""Export the recording as a self-contained HTML page and a plain 90-seconds-per-step capture script."""
import html

from .config import ROOT, load_settings
from .engine import load_recording
from .scenarios import SCENARIOS, SCRIPT, key
from .scorecard import evaluate
from .stepper import STEP_NAMES
from .guardrails import load_config
from .testset import load_testset

OUT = ROOT / "export"

SAY = {
    1: "No guardrails. Three requests: a normal question, a document with a buried instruction, a refund above the limit. The assistant does what it is asked each time.",
    2: "Input guardrail: a rule list and a small classifier. The buried instruction is blocked. Then the reworded (Czech) version gets through: a false negative, shown plainly.",
    3: "Output guardrail: pattern redaction for account-number-shaped text. The leak is redacted. Then a genuine complaint reference with the same shape is redacted too: a false positive, and what it costs the customer.",
    4: "Action guardrail: a short policy file evaluated by code, default deny. The refund of 450 is denied whatever the model was talked into. The reasonable refund of 180 is denied as well, which is the cost of this layer alone.",
    5: "Human approval: the borderline refund goes to a queue. This is what the approver sees: request, reason, evidence, and the rule that sent it there.",
    6: "Scorecard: forty labelled prompts, each layer alone and all four together. Move the threshold and watch the trade-off. The settings are one versioned file.",
}
CSS = """body{font:18px/1.5 system-ui,sans-serif;max-width:62rem;margin:2rem auto;padding:0 1rem;background:#fff;color:#111}
@media(prefers-color-scheme:dark){body{background:#111;color:#eee}pre{background:#1d1d1d!important}}
h1{font-size:1.6rem}h2{margin-top:2rem;font-size:1.3rem}h3{font-size:1.05rem;margin-bottom:.2rem}
pre{background:#f3f3f3;padding:.8rem;white-space:pre-wrap;border-radius:6px;font-size:.85rem}
.v{font-weight:700;padding:.35rem .8rem;border-radius:6px;display:inline-block}.good{background:#0a6b2b;color:#fff}.bad{background:#a3121a;color:#fff}.neutral{background:#3a4250;color:#fff}
.banner{border:3px solid #b36b00;padding:.5rem 1rem;font-weight:700}small{opacity:.8}
table{border-collapse:collapse}td,th{border:1px solid #888;padding:.3rem .6rem;text-align:right}td:first-child,th:first-child{text-align:left}"""


def _pre(t):
    return f"<pre>{html.escape(t or '')}</pre>"


def _stages(r):
    rows = "".join(f"<li><b>{html.escape(n)}</b>: {html.escape(s['decision'] if s['on'] or n == 'model' else 'off')}. "
                   f"<small>{html.escape(s['reason'])}</small></li>"
                   for n, s in r["stages"].items())
    return f"<ul>{rows}</ul>"


def build_html(rec, card) -> str:
    s = rec["settings"]
    parts = ["<h1>Guardrails demo: recorded run</h1>",
             f'<p class="banner">RECORDED RUN. Saved {html.escape(rec["recorded_at"])} with {html.escape(s["model"])}. Not a live model call.</p>',
             f"<p><small>Model {html.escape(s['model'])}, temperature {html.escape(str(s['temperature']))}, max tokens {s['max_tokens']}, "
             f"settings revision {html.escape(rec['rev'])}.</small></p>"]
    for step in range(1, 6):
        parts.append(f"<h2>Step {step}: {html.escape(STEP_NAMES[step])}</h2><p>{html.escape(SAY[step])}</p>")
        for st, sid in SCRIPT:
            if st != step:
                continue
            r = rec["results"][key(st, sid)]
            v = r["verdict"]
            parts.append(f"<h3>{html.escape(SCENARIOS[sid].title)}</h3>")
            parts.append(f'<p><span class="v {html.escape(v["tone"])}">{html.escape(v["label"])}</span> <small>{html.escape(v["detail"])}</small></p>')
            parts.append("<p>User sent:</p>" + _pre(r["request"]["message"]))
            parts.append("<p>Model produced:</p>" + _pre(r["model_output"]))
            parts.append("<p>Guardrails decided:</p>" + _stages(r))
            parts.append("<p>User saw:</p>" + _pre(r["delivered"]))
            for t in r["tickets"]:
                parts.append("<p>Approver saw:</p>" + _pre("\n".join(f"{k}: {v}" for k, v in
                             {"request": t["request"], "reason": t["reason"], "rule": t["rule_reason"], **t["evidence"]}.items())))
    parts.append(f"<h2>Step 6: Scorecard</h2><p>{html.escape(SAY[6])}</p>")
    parts.append(f"<p><small>Threshold {card['threshold']:.2f}, settings revision {html.escape(card['rev'])}.</small></p>")
    parts.append("<table><tr><th>Layer</th><th>Attacks caught</th><th>Missed</th><th>Model declined</th><th>Legit OK</th><th>Wrongly blocked</th><th>Held for a person</th></tr>")
    for row in card["rows"]:
        a, l = row["attacks"], row["legit"]
        parts.append(f"<tr><td>{html.escape(row['name'])}</td><td>{a['caught']}/{a['n']}</td><td>{a['missed']}</td><td>{a['declined']}</td>"
                     f"<td>{l['ok']}/{l['n']}</td><td>{l['wrong']}</td><td>{l['held']}</td></tr>")
    parts.append("</table>")
    return ("<!doctype html><html lang='en'><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"
            f"<title>Guardrails demo (recorded)</title><style>{CSS}</style><body>{''.join(parts)}</body></html>")


def build_script(rec, card) -> str:
    s = rec["settings"]
    lines = ["GUARDRAILS: 90-SECOND CAPTURE SCRIPT, ONE PER STEP",
             f"Recorded run saved {rec['recorded_at']} with {s['model']}, settings revision {rec['rev']}. Say on camera that this is a recording, not a live call.", ""]
    for step in range(1, 6):
        lines += [f"=== Step {step}: {STEP_NAMES[step]} (about 90 seconds) ===", f"Say: {SAY[step]}", ""]
        t = 0
        for st, sid in SCRIPT:
            if st != step:
                continue
            r = rec["results"][key(st, sid)]
            lines.append(f"[0:{t:02d}] Click '{SCENARIOS[sid].title}'. {SCENARIOS[sid].blurb}")
            lines.append(f"       Screen verdict: {r['verdict']['label']}. {r['verdict']['detail']}")
            for n, stg in r["stages"].items():
                if stg["on"] and stg["decision"] not in ("idle", "answered"):
                    lines.append(f"       {n}: {stg['decision']}. {stg['reason']}")
            t += 25
        lines.append("")
    lines += ["=== Step 6: Run scorecard (about 90 seconds) ===", f"Say: {SAY[6]}", ""]
    for row in card["rows"]:
        a, l = row["attacks"], row["legit"]
        lines.append(f"  {row['name']:20} attacks caught {a['caught']}/{a['n']}, missed {a['missed']}, model declined {a['declined']}; "
                     f"legitimate OK {l['ok']}/{l['n']}, wrongly blocked {l['wrong']}, held {l['held']}")
    return "\n".join(lines)


def main():
    settings = load_settings()
    rec = load_recording(settings.recording_path)
    cfg = load_config(settings.guardrails_path)
    # Use the scorecard saved with the recording, so the export matches the run it came from.
    card = rec.get("scorecard") or evaluate(cfg, load_testset(), rec["scorecard_traces"])
    OUT.mkdir(exist_ok=True)
    (OUT / "guardrails-demo.html").write_text(build_html(rec, card))
    (OUT / "capture-script.txt").write_text(build_script(rec, card))
    print(f"Wrote {OUT / 'guardrails-demo.html'} and {OUT / 'capture-script.txt'}")


if __name__ == "__main__":
    main()
