"""Run the six steps live once and save the real outputs, including the scorecard traces, for replay.

Nothing is edited. If the run is not representative (an attack did not fire, say), nothing is
saved: re-run until it is, or use --force to save it anyway."""
import argparse
import json
import sys
from datetime import datetime, timezone

from .config import load_settings
from .engine import Engine
from .scenarios import EXPECTED, SCRIPT, key
from .llm import AnthropicLLM


def record(engine) -> dict:
    results = {}
    for step in range(1, 6):
        engine.advance(step)
        for s, sid in SCRIPT:
            if s == step:
                r = engine.perform(sid)
                results[r["key"]] = r
                print(f"{r['key']:16} {r['verdict']['label']}", flush=True)
    engine.advance(6)
    print("Running the scorecard (one model call per test prompt)...", flush=True)
    card = engine.scorecard()
    return {"recorded_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "settings": engine._get_llm().effective_settings(), "rev": engine.base_cfg.rev,
            "results": results, "scorecard_traces": engine.traces, "scorecard": card}


def mismatches(rec) -> list:
    return [(k, want, rec["results"][k]["verdict"]["code"]) for k, want in EXPECTED.items()
            if rec["results"][k]["verdict"]["code"] != want]


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--force", action="store_true", help="save even if the run is not representative")
    args = ap.parse_args(argv)
    settings = load_settings()
    engine = Engine(settings, llm=AnthropicLLM(settings))
    rec = record(engine)
    bad = mismatches(rec)
    for k, want, got in bad:
        print(f"NOT REPRESENTATIVE: {k} expected '{want}', got '{got}'")
    if bad and not args.force:
        print("Not saved. Check ./rehearse.sh for the typical rates, then record again (or --force).")
        sys.exit(1)
    settings.recording_path.parent.mkdir(parents=True, exist_ok=True)
    settings.recording_path.write_text(json.dumps(rec, indent=2, ensure_ascii=False))
    print(f"Saved {settings.recording_path}")


if __name__ == "__main__":
    main()
