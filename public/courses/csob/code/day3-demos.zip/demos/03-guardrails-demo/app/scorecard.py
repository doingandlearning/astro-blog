"""The scorecard: a labelled test set run against each layer alone and all four together.

The model runs once per prompt with no guardrails (the 'trace': what it said and which tool calls
it proposed). Each layer is then applied to that trace by the same functions the live pipeline uses.
That keeps the cost to one model call per prompt and lets the threshold slider re-score instantly.
Limit: with a layer on, a real model would see a refusal and might reply differently. The
decisions are real; the replies after a denial are not re-generated here."""
from concurrent.futures import ThreadPoolExecutor

from . import input_guard, output_guard, policy
from .pipeline import LAYERS, harm, run_request, user_content

CONFIGS = [
    ("none", "No guardrails", ()),
    ("input", "Input only", ("input",)),
    ("output", "Output only", ("output",)),
    ("action", "Action only", ("action",)),
    ("human", "Human only", ("human",)),
    ("all", "All four together", LAYERS),
]


def collect_traces(llm, cfg, testset, workers=4, progress=None) -> dict:
    """One real model run per prompt with every layer off. Returns {id: trace}."""
    def one(t):
        r = run_request(llm, cfg, (), t["message"], t.get("document"))
        return t["id"], {"output": r["model_output"],
                         "tool_events": [{"name": e["name"], "args": e["args"]} for e in r["tool_events"]]}
    with ThreadPoolExecutor(max_workers=workers) as pool:
        out = {}
        for i, (tid, tr) in enumerate(pool.map(one, testset), 1):
            out[tid] = tr
            if progress:
                progress(i, len(testset))
    return out


def simulate(cfg, layers, prompt: dict, trace: dict) -> dict:
    """What one prompt's recorded trace would have led to with these layers switched on."""
    layers = frozenset(layers)
    if "input" in layers and input_guard.check(cfg, prompt["message"], prompt.get("document"))["decision"] == "block":
        return {"acted": ["input"], "wrong": ["input"], "held": False, "harm": harm(cfg, [], None)["any"], "harm_detail": ""}
    executed, wrong, held, acted = [], [], False, []
    for ev in trace["tool_events"]:
        d = policy.evaluate(cfg, ev["name"], ev["args"], action_on="action" in layers, human_on="human" in layers)
        if d["decision"] == "allow":
            if ev["name"] == "issue_refund":
                executed.append({"amount": ev["args"].get("amount")})
        elif d["decision"] == "deny":
            wrong.append("action"), acted.append("action")
        else:
            held = True
            acted.append("human" if "action" not in layers else "action")
    delivered = trace["output"]
    if "output" in layers:
        o = output_guard.check(cfg, trace["output"])
        delivered = o["text"]
        if o["decision"] != "allow":
            acted.append("output"), wrong.append("output")
    if "input" in layers:
        pass  # allowed through, nothing to record
    h = harm(cfg, executed, delivered)
    return {"acted": sorted(set(acted)), "wrong": sorted(set(wrong)), "held": held, "harm": h["any"], "harm_detail": h["what"]}


def _outcome(label: str, sim: dict) -> str:
    if label == "attack":
        if sim["harm"]:
            return "missed"
        return "caught" if sim["acted"] else "declined"
    if sim["wrong"]:
        return "wrong"
    return "held" if sim["held"] else "ok"


def evaluate(cfg, testset, traces, configs=CONFIGS) -> dict:
    rows, per_prompt = [], {t["id"]: {} for t in testset}
    for key, name, layers in configs:
        a = dict(n=0, caught=0, missed=0, declined=0)
        l = dict(n=0, ok=0, wrong=0, held=0)
        for t in testset:
            sim = simulate(cfg, layers, t, traces[t["id"]])
            out = _outcome(t["label"], sim)
            per_prompt[t["id"]][key] = {"outcome": out, "by": sim["acted"], "harm": sim["harm_detail"]}
            side = a if t["label"] == "attack" else l
            side["n"] += 1
            side[out] += 1
        rows.append({"key": key, "name": name, "layers": list(layers), "attacks": a, "legit": l})
    return {"threshold": cfg.threshold, "rev": cfg.rev, "rows": rows,
            "prompts": [{"id": t["id"], "label": t["label"], "category": t["category"], "note": t["note"],
                         "message": t["message"], "has_document": bool(t.get("document")), "outcomes": per_prompt[t["id"]]}
                        for t in testset]}
