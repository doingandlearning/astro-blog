"""The guardrail settings file and its revision identifier.

Everything the four layers decide with (threshold, rule list, classifier weights, output
patterns, action policy) lives in one YAML file. The revision is a hash of that file, so
"this is configuration" is something the room can see. A threshold set with the slider is
an unsaved override and changes the revision shown, so a screenshot is never ambiguous."""
import copy
import hashlib
import json
import re
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

import yaml


@dataclass(frozen=True)
class Config:
    text: str  # the file exactly as on disk
    data: dict  # parsed, with any threshold override applied
    file_rev: str
    override: float | None

    @property
    def rev(self) -> str:
        if self.override is None:
            return self.file_rev
        return hashlib.sha256(f"{self.file_rev}|threshold={self.override}".encode()).hexdigest()[:10]

    @property
    def input(self) -> dict:
        return self.data["input"]

    @property
    def output(self) -> dict:
        return self.data["output"]

    @property
    def policy(self) -> dict:
        return self.data["policy"]

    @property
    def threshold(self) -> float:
        return float(self.data["input"]["threshold"])

    @property
    def refund_limit(self) -> float:
        return float(self.data["policy"]["issue_refund"]["auto_approve_up_to"])

    def section_text(self, name: str) -> str:
        """The raw text of one top-level section, comments included, for showing on screen."""
        lines, out, on = self.text.splitlines(), [], False
        for line in lines:
            if re.match(r"^[A-Za-z_]+:", line):
                on = line.startswith(f"{name}:")
            if on:
                out.append(line)
        return "\n".join(out).rstrip() + "\n"

    def with_threshold(self, value: float | None) -> "Config":
        if value is None:
            return Config(self.text, load_data(self.text), self.file_rev, None)
        data = load_data(self.text)
        data["input"]["threshold"] = float(value)
        return Config(self.text, data, self.file_rev, float(value))


def load_data(text: str) -> dict:
    data = yaml.safe_load(text)
    for key in ("input", "output", "policy"):
        if key not in data:
            raise ValueError(f"guardrails file has no '{key}' section")
    return data


def load_config(path: Path) -> Config:
    text = Path(path).read_text()
    return Config(text, load_data(text), hashlib.sha256(text.encode()).hexdigest()[:10], None)


@lru_cache(maxsize=256)
def rx(pattern: str, flags: int = re.IGNORECASE) -> "re.Pattern":
    return re.compile(pattern, flags)


def canonical(obj) -> str:
    return json.dumps(obj, sort_keys=True, ensure_ascii=False)


def clone(obj):
    return copy.deepcopy(obj)
