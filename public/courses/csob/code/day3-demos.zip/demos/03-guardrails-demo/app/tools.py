"""The agent's only tool is a stub. It records a refund in memory and does nothing else:
no network, file or shell access. Everything here is fictional (Example Bank)."""
import itertools

REFUND_TOOL = {
    "name": "issue_refund",
    "description": "Issue a refund to a customer. Records the refund and returns a confirmation.",
    "input_schema": {
        "type": "object",
        "properties": {
            "customer_ref": {"type": "string", "description": "The customer's reference, for example EB-C-20417"},
            "amount": {"type": "number", "description": "Refund amount in euro"},
            "reason": {"type": "string", "description": "Why the refund is being issued"},
        },
        "required": ["customer_ref", "amount", "reason"],
    },
}

# Fake records the approver is shown. A reference that is not here is itself evidence.
CUSTOMERS = {
    "EB-C-20417": {"name": "Alex Sample", "since": "2019", "note": "Everyday account, no complaints on file"},
    "EB-C-20532": {"name": "Dana Example", "since": "2022", "note": "Everyday Plus account"},
    "EB-C-20688": {"name": "Robin Placeholder", "since": "2015", "note": "Everyday account, one earlier complaint (resolved)"},
    "EB-C-20791": {"name": "Sam Testperson", "since": "2024", "note": "Basic account, opened this year"},
    "EB-C-20844": {"name": "Jana Vzorová", "since": "2020", "note": "Everyday account"},
    "EB-C-20915": {"name": "Peter Vzorový", "since": "2018", "note": "Everyday Plus account"},
}
TRANSACTIONS = {
    "EB-C-20417": ("EB-T-77120", 450.00, "Card payment charged twice at a fictional merchant"),
    "EB-C-20532": ("EB-T-77243", 180.00, "Annual card fee charged after the card was cancelled"),
    "EB-C-20688": ("EB-T-77351", 85.00, "Duplicate standing order"),
    "EB-C-20791": ("EB-T-77466", 60.00, "Fee charged on a Basic account"),
    "EB-C-20844": ("EB-T-77502", 220.00, "Card payment charged twice at a fictional merchant"),
    "EB-C-20915": ("EB-T-77618", 40.00, "Duplicate card fee"),
}


class RefundLedger:
    """In-memory record of refunds the stub tool has 'issued'."""

    def __init__(self):
        self.entries = []

    def issue(self, args: dict, note: str = "") -> str:
        self.entries.append({"customer_ref": args.get("customer_ref"), "amount": args.get("amount"),
                             "reason": args.get("reason"), "note": note})
        return f"Refund of {args.get('amount')} recorded for {args.get('customer_ref')} (stub; no money moves)."


def evidence_for(args: dict, user_message: str) -> dict:
    """What an approver would see besides the request itself. Looked up from the fake records."""
    ref = args.get("customer_ref")
    cust, tx = CUSTOMERS.get(ref), TRANSACTIONS.get(ref)
    return {
        "customer_record": (f"{cust['name']}, customer since {cust['since']}. {cust['note']}." if cust
                            else f"No customer with reference {ref!r} in the records. Treat as unverified."),
        "original_transaction": (f"{tx[0]}: {tx[1]:.2f}, {tx[2]}." if tx else "No matching transaction on file."),
        "earlier_refunds": "None in the last 12 months." if cust else "Not available.",
        "customer_message": " ".join(user_message.split())[:300],
    }


class ApprovalQueue:
    """The human layer's queue. A ticket is what the approver sees."""

    def __init__(self, ledger: RefundLedger, approver_role: str):
        self._ledger, self.approver_role = ledger, approver_role
        self._ids = itertools.count(1)
        self.tickets = {}

    def submit(self, args: dict, decision: dict, user_message: str, model_reason: str) -> dict:
        tid = f"T-{next(self._ids):03d}"
        t = {"id": tid, "status": "pending", "approver": self.approver_role, "tool": "issue_refund",
             "request": {"customer_ref": args.get("customer_ref"), "amount": args.get("amount")},
             "reason": model_reason, "evidence": evidence_for(args, user_message),
             "rule": decision["rule"], "rule_reason": decision["reason"], "args": dict(args)}
        self.tickets[tid] = t
        return t

    def resolve(self, tid: str, approve: bool) -> dict:
        t = self.tickets.get(tid)
        if t is None:
            raise KeyError(tid)
        if t["status"] != "pending":
            raise ValueError(f"Ticket {tid} is already {t['status']}.")
        t["status"] = "approved" if approve else "rejected"
        if approve:
            self._ledger.issue(t["args"], note=f"approved by {self.approver_role} ({tid})")
        return t
