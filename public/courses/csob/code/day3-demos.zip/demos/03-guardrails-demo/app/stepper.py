"""Enforces the script order on the server, so the page cannot jump ahead.

Progress 0 is the start screen. Step n switches on the n-th stage of the script; it can only be
pressed when step n-1 has been. Step 1 is the baseline (no guardrails), step 6 is the scorecard."""

STEP_NAMES = {1: "Baseline", 2: "Input guardrail on", 3: "Output guardrail on",
              4: "Action guardrail on", 5: "Human approval on", 6: "Run scorecard"}
LAST = 6
# Layers switched on once a step has been taken. Step 6 runs the scorecard with all four.
LAYERS_AT = {0: (), 1: (), 2: ("input",), 3: ("input", "output"), 4: ("input", "output", "action"),
             5: ("input", "output", "action", "human"), 6: ("input", "output", "action", "human")}


class OrderError(Exception):
    pass


class Stepper:
    def __init__(self):
        self.progress = 0

    def next_step(self):
        return self.progress + 1 if self.progress < LAST else None

    def advance(self, step: int):
        if step not in STEP_NAMES:
            raise ValueError(f"There is no step {step!r}.")
        if step != self.progress + 1:
            want = STEP_NAMES.get(self.progress + 1)
            raise OrderError(f"'{STEP_NAMES[step]}' is not available yet. Next is '{want}'." if want else "Already at the last step. Press Reset to start again.")
        self.progress = step

    def can_run_scenarios(self) -> bool:
        return 1 <= self.progress <= 5

    def layers(self) -> tuple:
        return LAYERS_AT[self.progress]

    def reset(self):
        self.progress = 0
