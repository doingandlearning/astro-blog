"""The only module that talks to the network. Replay mode never constructs this."""
import os

from .config import Settings


class LLMError(RuntimeError):
    pass


def _block(b) -> dict:
    if b.type == "text":
        return {"type": "text", "text": b.text}
    if b.type == "tool_use":
        return {"type": "tool_use", "id": b.id, "name": b.name, "input": b.input}
    if b.type == "thinking":
        # Must go back to the API unchanged on the next turn of a tool loop, or it returns a 400.
        return {"type": "thinking", "thinking": b.thinking, "signature": b.signature}
    if b.type == "redacted_thinking":
        return {"type": "redacted_thinking", "data": b.data}
    return {"type": b.type}


class AnthropicLLM:
    def __init__(self, settings: Settings):
        self._s = settings
        self._temperature = settings.temperature
        self._client = None

    def effective_settings(self) -> dict:
        return {"model": self._s.model, "temperature": self._temperature, "max_tokens": self._s.max_tokens}

    def _get_client(self):
        if self._client is None:
            if not os.environ.get("ANTHROPIC_API_KEY"):
                raise LLMError("ANTHROPIC_API_KEY is not set. Set it, or start with ./run.sh --replay.")
            import anthropic
            self._client = anthropic.Anthropic(max_retries=2, timeout=60)
        return self._client

    def _create(self, kwargs):
        import anthropic
        try:
            return self._get_client().messages.create(**kwargs)
        except anthropic.BadRequestError:
            raise
        except anthropic.APIError as e:
            raise LLMError(f"Model API error: {e}") from e

    def complete(self, *, system, messages, tools) -> dict:
        import anthropic
        kwargs = {"model": self._s.model, "max_tokens": self._s.max_tokens, "system": system, "messages": messages}
        if tools:
            kwargs["tools"] = tools
        if self._temperature is not None:
            # Newer SDKs have no temperature parameter on create(), so send it in the request body.
            kwargs["extra_body"] = {"temperature": self._temperature}
        try:
            resp = self._create(kwargs)
        except anthropic.BadRequestError as e:
            # Some models do not accept a temperature. Drop it and say so in the footer.
            if "extra_body" in kwargs and "temperature" in str(e).lower():
                self._temperature = None
                kwargs.pop("extra_body")
                try:
                    resp = self._create(kwargs)
                except anthropic.APIError as e2:
                    raise LLMError(f"Model API error: {e2}") from e2
            else:
                raise LLMError(f"Model API error: {e}") from e
        return {"content": [_block(b) for b in resp.content], "stop_reason": resp.stop_reason}
