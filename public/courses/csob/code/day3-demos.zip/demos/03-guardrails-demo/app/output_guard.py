"""Output guardrail: an output schema (length, no links off the allowed hosts), then pattern
redaction of anything shaped like an account number. Pure code, no network.

The pattern knows shapes, not meaning. A customer's own complaint reference can have the same
shape as an account number, and then it is redacted too. That false positive is the point."""
import re

from .guardrails import Config, rx

BLOCKED_TEXT = "[This reply was blocked by the output guardrail.]"
URL = re.compile(r"https?://([^/\s\"'<>)]+)", re.IGNORECASE)


def schema_problems(cfg: Config, text: str) -> list:
    s, problems = cfg.output["schema"], []
    if not isinstance(text, str):
        return ["output is not plain text"]
    if len(text) > int(s["max_chars"]):
        problems.append(f"longer than {s['max_chars']} characters ({len(text)})")
    allowed = tuple(h.lower() for h in s.get("allowed_url_hosts", []))
    for m in URL.finditer(text):
        host = m.group(1).lower().split(":")[0]
        if not any(host == a or host.endswith("." + a) for a in allowed):
            problems.append(f"link to a host that is not allowed ({host})")
    return problems


def check(cfg: Config, text: str) -> dict:
    """Returns {"decision": "allow"|"redact"|"block", "text": what is delivered, "reason", "findings"}."""
    problems = schema_problems(cfg, text)
    if problems:
        return {"decision": "block", "text": BLOCKED_TEXT, "findings": [], "problems": problems,
                "reason": "Output schema failed: " + "; ".join(problems) + "."}
    findings, out = [], text
    for p in cfg.output["redact_patterns"]:
        def sub(m, p=p):
            findings.append({"pattern": p["id"], "match": m.group(0)})
            return p["replacement"]
        out = rx(p["pattern"], 0).sub(sub, out)
    if findings:
        names = ", ".join(sorted({f["pattern"] for f in findings}))
        shown = ", ".join(f'"{f["match"]}"' for f in findings)
        return {"decision": "redact", "text": out, "findings": findings, "problems": [],
                "reason": f"Pattern '{names}' matched {shown}. The match was replaced before the user saw it."}
    return {"decision": "allow", "text": text, "findings": [], "problems": [],
            "reason": "Schema satisfied and no account-number-shaped text found."}
