"use strict";
const $ = (s) => document.querySelector(s);

const STAGE_LABEL = { input: "Input guardrail", model: "Model", output: "Output guardrail", action: "Action guardrail", human: "Human approval" };
const STEP_HELP = {
  1: "Baseline: no guardrails. Run the three requests and watch what the assistant does when asked.",
  2: "The input guardrail is on: a rule list and a small classifier check the message and any pasted content.",
  3: "The output guardrail is on: pattern redaction for account-number-shaped text, plus an output schema.",
  4: "The action guardrail is on: a short policy, evaluated by code outside the model, sits in front of the refund tool.",
  5: "Human approval is on: a refund above the limit but inside the approval band waits for a person.",
  6: "Scorecard: 40 labelled prompts, each layer alone and all four together.",
};

let catalog = null, state = null, last = null, scorecard = null, busy = "", errorText = "", hint = "", settingsOpen = false;
let timer = null;

async function api(path, opts) {
  const r = await fetch(path, opts);
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.detail || r.statusText);
  return data;
}
const post = (path, body) => api(path, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body || {}) });

// Build elements with text only, never HTML from data.
function el(tag, attrs, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (k === "class") e.className = v; else if (k === "text") e.textContent = v; else e.setAttribute(k, v);
  }
  for (const k of kids) if (k != null) e.append(k);
  return e;
}

function markedFragment(text, spans) {
  const f = document.createDocumentFragment();
  let pos = 0;
  for (const [s, e] of spans) {
    if (s > pos) f.append(text.slice(pos, s));
    f.append(el("mark", { text: text.slice(s, e) }));
    pos = e;
  }
  f.append(text.slice(pos));
  return f;
}

function setVerdict(tone, label, detail) {
  $("#verdict").className = `verdict ${tone}`;
  $("#verdict-label").textContent = label;
  $("#verdict-detail").textContent = detail || "";
}

function renderStepper() {
  const ol = $("#stepper");
  ol.replaceChildren();
  const labels = state.steps;
  for (const n of Object.keys(labels).map(Number)) {
    const b = el("button", { "data-step": n }, el("span", { class: "num", text: String(n) }), labels[n]);
    b.disabled = !!busy || state.next_step !== n;
    b.addEventListener("click", () => takeStep(n));
    ol.append(el("li", { class: state.progress >= n ? "done" : "" }, b));
  }
}

function renderRequests() {
  const box = $("#requests");
  box.replaceChildren();
  for (const s of catalog.scenarios) {
    const b = el("button", { text: s.title });
    b.disabled = !!busy || !state.available.includes(s.id);
    b.addEventListener("click", () => runRequest(s.id));
    b.addEventListener("mouseenter", () => { $("#blurb").textContent = s.blurb; });
    b.addEventListener("focus", () => { $("#blurb").textContent = s.blurb; });
    box.append(b);
  }
  $("#blurb").textContent = hint;
}

function nodeEl(label, stage, status, text) {
  return el("div", { class: `node ${status}`, "data-stage": stage }, el("b", { text: label }), el("span", { text }));
}

function stageStatus(name) {
  const on = name === "model" || state.layers.includes(name);
  if (!on) return ["off", "off"];
  if (!last) return ["ready", name === "model" ? "" : "on"];
  const s = last.stages[name];
  if (!s || !s.on && name !== "model") return ["off", "off"];
  return [s.decision, s.decision === "answered" ? "" : s.decision];
}

function renderFlow() {
  const rows = {
    a: [["User message", null], ["Input guardrail", "input"], ["Model", "model"], ["Output guardrail", "output"], ["User sees", null]],
    b: [["Model proposes a tool call", null], ["Action guardrail", "action"], ["Human approval", "human"], ["issue_refund (stub)", null]],
  };
  for (const [r, nodes] of Object.entries(rows)) {
    const row = document.querySelector(`.flow-row[data-row=${r}]`);
    row.replaceChildren();
    nodes.forEach(([label, stage], i) => {
      if (i) row.append(el("span", { class: "arrow", text: "→" }));
      if (stage) { const [st, text] = stageStatus(stage); row.append(nodeEl(label, stage, st, text)); }
      else row.append(nodeEl(label, "", "endpoint", ""));
    });
  }
}

function renderPanels() {
  const sent = $("#p-sent"), note = $("#doc-note");
  sent.replaceChildren();
  note.hidden = true;
  if (!last) {
    sent.textContent = "Nothing sent yet.";
    $("#p-output").textContent = ""; $("#p-tools").replaceChildren(); $("#p-delivered").textContent = ""; $("#p-stages").replaceChildren();
    return;
  }
  const hl = $("#show-hidden").checked;
  sent.append(`[customer message]\n${last.request.message}`);
  if (last.request.document) {
    const d = last.doc_id ? catalog.documents[last.doc_id] : null;
    sent.append("\n\n[pasted document]\n");
    sent.append(d && hl ? markedFragment(d.text, d.spans) : last.request.document);
    if (d && hl && d.spans.length) { note.hidden = false; note.textContent = d.note; }
  }
  $("#p-output").textContent = last.model_output === null ? "The model was never called: the input guardrail stopped the request first." : last.model_output;

  const tools = $("#p-tools");
  tools.replaceChildren();
  if (!last.tool_events.length) tools.append(el("li", { text: last.model_output === null ? "None." : "None proposed." }));
  for (const e of last.tool_events) {
    const a = e.args, outcome = { allow: "ALLOWED and recorded by the stub", deny: `DENIED (${e.rule})`, escalate: `HELD for approval (${e.ticket})` }[e.decision];
    tools.append(el("li", { class: e.decision, text: `issue_refund(${a.customer_ref}, ${a.amount}, "${a.reason}")  →  ${outcome}` }));
  }
  $("#p-delivered").textContent = last.delivered;

  const list = $("#p-stages");
  list.replaceChildren();
  for (const name of ["input", "model", "output", "action", "human"]) {
    const s = last.stages[name];
    const on = name === "model" || s.on;
    list.append(el("li", { class: on ? s.decision : "off" },
      el("span", { class: "badge", text: on ? s.decision : "off" }), el("b", { text: STAGE_LABEL[name] + ": " }), on ? s.reason : "Switched off."));
  }
}

function renderApprover() {
  const box = $("#approver-cards");
  box.replaceChildren();
  const tickets = last ? last.tickets : [];
  $("#approver").hidden = !tickets.length;
  for (const t0 of tickets) {
    const t = (state.tickets || []).find((x) => x.id === t0.id) || t0;
    const ev = t.evidence;
    const dl = el("dl", {});
    const row = (k, v) => { dl.append(el("dt", { text: k }), el("dd", { text: v })); };
    row("Request", `Refund ${Number(t.request.amount).toFixed(2)} to ${t.request.customer_ref}`);
    row("Reason given", t.reason);
    row("Customer record", ev.customer_record);
    row("Original transaction", ev.original_transaction);
    row("Earlier refunds", ev.earlier_refunds);
    row("Customer's message", ev.customer_message);
    row("Why it is here", `Rule '${t.rule}': ${t.rule_reason}`);
    const actions = el("div", { class: "actions" }, el("span", { class: "status", text: `${t.id}: ${t.status}` }));
    if (t.status === "pending" && state.mode === "live") {
      for (const [label, ok] of [["Approve", true], ["Reject", false]]) {
        const b = el("button", { text: label });
        b.addEventListener("click", () => resolve(t.id, ok));
        actions.append(b);
      }
    } else if (state.mode === "replay") actions.append(el("span", { class: "hint", text: "Recorded run: approvals are not live." }));
    box.append(el("div", { class: "card" }, el("b", { text: `Approval queue, for the ${t.approver}` }), dl, actions));
  }
}

function td(text, cls) { return el("td", { class: cls || "", text: String(text) }); }

function renderScorecard() {
  const sec = $("#scorecard");
  sec.hidden = !(state.progress === 6);
  if (sec.hidden) return;
  const tbl = $("#score-table");
  tbl.replaceChildren();
  if (!scorecard) { tbl.append(el("tr", {}, el("td", { text: busy === "scorecard" ? "Running 40 prompts against the model. This takes about a minute…" : "No scorecard yet." }))); return; }
  const head = ["Layer", "Attacks caught", "Attacks missed", "Model declined by itself", "Legitimate handled", "Legitimate wrongly blocked", "Legitimate held for a person"];
  tbl.append(el("tr", {}, ...head.map((h) => el("th", { text: h }))));
  for (const r of scorecard.rows) {
    const a = r.attacks, l = r.legit;
    const tr = el("tr", { class: r.key === "all" ? "combined" : "" }, td(r.name),
      td(`${a.caught} / ${a.n}`, "good"), td(a.missed, a.missed ? "bad" : ""), td(a.declined),
      td(`${l.ok} / ${l.n}`, "good"), td(l.wrong, l.wrong ? "bad" : ""), td(l.held, l.held ? "info" : ""));
    tbl.append(tr);
  }
  $("#threshold-out").textContent = scorecard.threshold.toFixed(2);
  $("#threshold").value = scorecard.threshold;
  $("#score-note").textContent = `Settings revision ${scorecard.rev}${scorecard.overridden ? " (threshold moved with the slider, not saved to the file)" : ""}. ` +
    (scorecard.replay ? "Recorded model replies; the layers are scored live. " : "One model run per prompt with no guardrails; each layer is then applied to what the model said and proposed. ") +
    "'Held' assumes the approver decides correctly; a rubber-stamping approver is its own error rate.";
  const tt = $("#testset-table");
  tt.replaceChildren(el("tr", {}, ...["ID", "Label", "Category", "Note", "Input only", "All four"].map((h) => el("th", { text: h }))));
  for (const p of scorecard.prompts) {
    const o = (k) => { const x = p.outcomes[k]; return x.outcome + (x.by.length ? ` (${x.by.join(", ")})` : ""); };
    tt.append(el("tr", {}, td(p.id), td(p.label, p.label === "attack" ? "bad" : "good"), td(p.category), td(p.note), td(o("input")), td(o("all"))));
  }
}

async function renderSettings() {
  $("#settings").hidden = !settingsOpen;
  if (!settingsOpen) return;
  const c = await api("/api/config");
  $("#settings-rev").textContent = `revision ${c.rev}` + (c.overridden ? `  (file ${c.file_rev}; threshold overridden to ${c.threshold.toFixed(2)}, unsaved)` : `  (threshold ${c.threshold.toFixed(2)})`);
  $("#p-policy").textContent = c.policy;
  $("#p-file").textContent = c.text;
}

function renderChrome() {
  const banner = $("#banner");
  if (state.mode === "replay") {
    const r = state.recording || {};
    banner.hidden = false;
    banner.textContent = `RECORDED RUN: outputs saved ${r.recorded_at || ""} with ${r.model || "unknown model"}. Not a live model call.`;
  } else banner.hidden = true;
  const s = (last && !last.replay ? last.settings : state.settings) || {};
  const temp = s.temperature === null || s.temperature === undefined ? "provider default (model rejected temperature)" : s.temperature;
  $("#footer").textContent = `mode ${state.mode} | model ${s.model} | temperature ${temp} | max_tokens ${s.max_tokens} | settings revision ${state.rev} | input threshold ${state.threshold.toFixed(2)}`;

  if (busy === "scorecard") setVerdict("neutral", "Running the scorecard…", "40 prompts, one model call each. About a minute.");
  else if (busy) setVerdict("neutral", "Running…", "Calling the model. This can take several seconds.");
  else if (errorText) setVerdict("bad", "Could not do that", errorText);
  else if (last) { const v = last.verdict; setVerdict(v.tone, `${v.tone === "good" ? "✔" : v.tone === "bad" ? "✖" : "•"} ${v.label}`, v.detail); }
  else if (state.progress === 0) setVerdict("neutral", "Press “Baseline” to begin", "");
  else setVerdict("neutral", state.steps[state.progress], STEP_HELP[state.progress]);

  const rec = $("#show-received").checked && last && last.calls.length;
  $("#received").hidden = !rec;
  if (rec) $("#p-received").textContent = formatCalls(last);
}

function formatCalls(r) {
  const lines = [`Settings revision ${r.rev}. Layers on: ${r.layers.join(", ") || "none"}.`, ""];
  r.calls.forEach((c, i) => {
    lines.push(`=== Request ${i + 1} of ${r.calls.length} ===`, "[system]", c.system, "", `[tools] ${c.tools.join(", ")}`, "");
    for (const m of c.messages) {
      if (typeof m.content === "string") { lines.push(`[${m.role}]`, m.content, ""); continue; }
      for (const b of m.content) {
        if (b.type === "text") lines.push(`[${m.role}]`, b.text, "");
        else if (b.type === "tool_use") lines.push(`[${m.role} calls tool] ${b.name}(${JSON.stringify(b.input)})`, "");
        else if (b.type === "tool_result") lines.push("[tool result, exactly as returned to the model]", b.content, "");
      }
    }
  });
  if (!r.calls.length) lines.push("No request was made to the model: the input guardrail stopped this one first.");
  return lines.join("\n");
}

async function render() {
  renderStepper(); renderRequests(); renderFlow(); renderPanels(); renderApprover(); renderScorecard(); renderChrome();
  await renderSettings().catch(() => {});
}

async function takeStep(n) {
  if (busy) return;
  errorText = ""; last = null; hint = "";
  try {
    state = await post("/api/step", { step: n });
    if (n === 6) { busy = "scorecard"; await render(); await loadScorecard(null); }
  } catch (e) { errorText = e.message; try { state = await api("/api/state"); } catch (_) { /* keep */ } }
  busy = "";
  await render();
}

async function loadScorecard(threshold) {
  try {
    const res = await post("/api/scorecard", { threshold });
    scorecard = res.scorecard; state = res.state; errorText = "";
  } catch (e) { errorText = e.message; }
}

async function runRequest(id) {
  if (busy) return;
  busy = "run"; errorText = ""; await render();
  try {
    const res = await post("/api/run", { scenario: id });
    last = res.result; state = res.state;
    hint = catalog.scenarios.find((s) => s.id === id).blurb;
  } catch (e) { errorText = e.message; try { state = await api("/api/state"); } catch (_) { /* keep */ } }
  busy = "";
  await render();
}

async function resolve(tid, approve) {
  try { await post(`/api/ticket/${tid}`, { approve }); state = await api("/api/state"); errorText = ""; }
  catch (e) { errorText = e.message; }
  await render();
}

async function reset() {
  state = await api("/api/reset", { method: "POST" });
  last = null; scorecard = null; errorText = ""; busy = ""; hint = "";
  await render();
}

function setTheme(t) {
  document.documentElement.dataset.theme = t;
  try { localStorage.setItem("theme", t); } catch (_) { /* storage may be blocked */ }
}

async function init() {
  try { const t = localStorage.getItem("theme"); if (t) document.documentElement.dataset.theme = t; } catch (_) { /* ignore */ }
  $("#reset").addEventListener("click", reset);
  $("#show-received").addEventListener("change", render);
  $("#show-hidden").addEventListener("change", render);
  $("#settings-btn").addEventListener("click", () => { settingsOpen = !settingsOpen; render(); });
  $("#theme").addEventListener("click", () => {
    const dark = getComputedStyle(document.documentElement).getPropertyValue("--bg").trim() === "#0e1116";
    setTheme(dark ? "light" : "dark");
  });
  $("#threshold").addEventListener("input", (e) => {
    $("#threshold-out").textContent = Number(e.target.value).toFixed(2);
    clearTimeout(timer);
    timer = setTimeout(async () => { await loadScorecard(Number(e.target.value)); await render(); }, 200);
  });
  catalog = await api("/api/catalog");
  state = await api("/api/state");
  // testset rows are shown from the scorecard payload; the catalog copy is for the trainer's reference
  await render();
}

init().catch((e) => { document.body.textContent = `Failed to load: ${e.message}`; });
