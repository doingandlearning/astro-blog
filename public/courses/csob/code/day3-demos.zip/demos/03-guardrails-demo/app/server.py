"""FastAPI app. Serves one static page and a small JSON API. Binds to 127.0.0.1 only."""
import os
import sys
import threading
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from .config import HOST, load_settings
from .engine import Engine, RecordingError
from .llm import LLMError
from .scenarios import SCENARIOS
from .stepper import OrderError

STATIC = Path(__file__).parent / "static"


class StepRequest(BaseModel):
    step: int


class RunRequest(BaseModel):
    scenario: str


class TicketRequest(BaseModel):
    approve: bool


class ScoreRequest(BaseModel):
    threshold: float | None = None


def create_app(settings, llm=None, recording=None, llm_factory=None, cfg=None) -> FastAPI:
    kwargs = {"llm_factory": llm_factory} if llm_factory else {}
    engine = Engine(settings, llm=llm, recording=recording, cfg=cfg, **kwargs)
    lock = threading.Lock()  # one trainer, one run at a time
    app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)

    def guarded(fn):
        try:
            return fn()
        except OrderError as e:
            raise HTTPException(409, str(e))
        except (ValueError, KeyError) as e:
            raise HTTPException(422, str(e))
        except RecordingError as e:
            raise HTTPException(404, str(e))
        except LLMError as e:
            raise HTTPException(502, str(e))

    @app.get("/")
    def index():
        return FileResponse(STATIC / "index.html")

    @app.get("/api/catalog")
    def catalog():
        return {"scenarios": [vars(s) for s in SCENARIOS.values()],
                "documents": {d.id: {"title": d.title, "text": d.text, "spans": d.spans, "note": d.note}
                              for d in engine.docs.values()},
                "testset": [{k: v for k, v in t.items() if k != "document"} | {"has_document": bool(t.get("document"))}
                            for t in engine.testset]}

    @app.get("/api/state")
    def state():
        return engine.state()

    @app.get("/api/config")
    def config():
        c = engine.cfg
        return {"text": c.text, "policy": c.section_text("policy"), "rev": c.rev, "file_rev": c.file_rev,
                "threshold": c.threshold, "overridden": c.override is not None}

    @app.post("/api/step")
    def step(req: StepRequest):
        with lock:
            guarded(lambda: engine.advance(req.step))
            return engine.state()

    @app.post("/api/run")
    def run(req: RunRequest):
        with lock:
            result = guarded(lambda: engine.perform(req.scenario))
            return {"result": result, "state": engine.state()}

    @app.post("/api/scorecard")
    def scorecard(req: ScoreRequest):
        with lock:
            return {"scorecard": guarded(lambda: engine.scorecard(req.threshold)), "state": engine.state()}

    @app.post("/api/ticket/{tid}")
    def ticket(tid: str, req: TicketRequest):
        with lock:
            return {"ticket": guarded(lambda: engine.resolve_ticket(tid, req.approve)), "refunds": engine.ledger.entries}

    @app.post("/api/reset")
    def reset():
        with lock:
            engine.reset()
            return engine.state()

    app.mount("/static", StaticFiles(directory=STATIC), name="static")
    return app


def main():
    import uvicorn
    settings = load_settings()
    if settings.mode == "live" and not os.environ.get("ANTHROPIC_API_KEY"):
        sys.exit("ANTHROPIC_API_KEY is not set. Set it, or start with ./run.sh --replay to serve the recording.")
    try:
        app = create_app(settings)
    except RecordingError as e:
        sys.exit(str(e))
    print(f"Guardrails demo ({settings.mode}) on http://{HOST}:{settings.port}")
    uvicorn.run(app, host=HOST, port=settings.port, log_level="warning")


if __name__ == "__main__":
    main()
