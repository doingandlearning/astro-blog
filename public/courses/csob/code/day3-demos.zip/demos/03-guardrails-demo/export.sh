#!/usr/bin/env bash
# Turn recordings/run.json into export/guardrails-demo.html and export/capture-script.txt.
set -euo pipefail
cd "$(dirname "$0")"
exec uv run python -m app.export "$@"
