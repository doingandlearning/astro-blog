import socket

import pytest
from fastapi.testclient import TestClient

from app import server
from app.config import HOST
from app.engine import Engine, RecordingError
from app.server import create_app


def test_binds_to_loopback_ip_not_localhost(monkeypatch, settings):
    assert HOST == "127.0.0.1"
    seen = {}
    import uvicorn
    monkeypatch.setattr(uvicorn, "run", lambda app, host, port, **kw: seen.update(host=host, port=port))
    monkeypatch.setenv("ANTHROPIC_API_KEY", "x")
    server.main()
    assert seen["host"] == "127.0.0.1"


def test_live_start_without_a_key_explains(monkeypatch):
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    monkeypatch.delenv("DEMO_MODE", raising=False)
    with pytest.raises(SystemExit) as e:
        server.main()
    assert "ANTHROPIC_API_KEY" in str(e.value)


def test_live_flow_over_http(fake, settings):
    c = TestClient(create_app(settings, llm=fake))
    assert c.get("/api/state").json()["progress"] == 0
    assert c.post("/api/run", json={"scenario": "normal"}).status_code == 409
    assert c.post("/api/step", json={"step": 2}).status_code == 409
    assert c.post("/api/step", json={"step": 1}).json()["progress"] == 1
    r = c.post("/api/run", json={"scenario": "refund450"}).json()
    assert r["result"]["verdict"]["label"] == "Attack got through"
    assert c.post("/api/run", json={"scenario": "nope"}).status_code == 422
    assert c.post("/api/scorecard", json={}).status_code == 409
    assert c.post("/api/reset").json()["progress"] == 0


def test_full_script_over_http_and_approval(fake, settings):
    c = TestClient(create_app(settings, llm=fake))
    for n in range(1, 6):
        c.post("/api/step", json={"step": n})
    r = c.post("/api/run", json={"scenario": "borderline"}).json()["result"]
    tid = r["tickets"][0]["id"]
    out = c.post(f"/api/ticket/{tid}", json={"approve": True}).json()
    assert out["ticket"]["status"] == "approved" and out["refunds"][0]["amount"] == 180
    assert c.post(f"/api/ticket/{tid}", json={"approve": True}).status_code == 422
    c.post("/api/step", json={"step": 6})
    card = c.post("/api/scorecard", json={"threshold": 0.3}).json()
    assert card["scorecard"]["threshold"] == 0.3 and card["state"]["threshold_overridden"]
    assert [r["key"] for r in card["scorecard"]["rows"]] == ["none", "input", "output", "action", "human", "all"]
    cfg = c.get("/api/config").json()
    assert cfg["rev"] != cfg["file_rev"] and "default: deny" in cfg["policy"]


def test_catalog_has_labels_and_notes_for_the_trainer(fake, settings):
    cat = TestClient(create_app(settings, llm=fake)).get("/api/catalog").json()
    assert len(cat["testset"]) == 40 and all(t["label"] and t["note"] for t in cat["testset"])
    assert all("document" not in t for t in cat["testset"])


def test_replay_never_touches_the_network_or_the_model(monkeypatch, replay_settings, fake_recording):
    def boom(*a, **k):
        raise AssertionError("network used in replay mode")
    monkeypatch.setattr(socket.socket, "connect", boom)

    def factory(_):
        raise AssertionError("model client constructed in replay mode")
    c = TestClient(create_app(replay_settings, recording=fake_recording, llm_factory=factory))
    st = c.get("/api/state").json()
    assert st["mode"] == "replay" and st["recording"]["model"] == "fake-model"
    for n in range(1, 6):
        c.post("/api/step", json={"step": n})
        for sid in c.get("/api/state").json()["available"]:
            res = c.post("/api/run", json={"scenario": sid}).json()["result"]
            assert res["replay"] is True
    c.post("/api/step", json={"step": 6})
    assert c.post("/api/scorecard", json={"threshold": 0.2}).status_code == 200
    tid = None
    assert c.post("/api/ticket/T-001", json={"approve": True}).status_code == 409


def test_replay_only_offers_what_was_recorded(replay_settings, fake_recording):
    e = Engine(replay_settings, recording=fake_recording)
    e.advance(1)
    assert e.available() == ["normal", "injected", "refund450"]
    e.advance(2)
    assert e.available() == ["injected", "reworded"]


def test_replay_without_a_recording_says_what_to_do(tmp_path):
    from app.config import load_settings
    s = load_settings({"DEMO_MODE": "replay", "DEMO_RECORDING": str(tmp_path / "none.json")})
    with pytest.raises(RecordingError) as e:
        Engine(s)
    assert "record.sh" in str(e.value)
