import re

import pytest

from app.config import load_settings
from app.documents import load_documents
from app.engine import Engine
from app.guardrails import load_config
from app.prompts import SECRET_ACCOUNT
from app.scenarios import SCRIPT
from app.testset import load_testset


class FakeLLM:
    """Stands in for the model. NOT a claim about real model behaviour: it exists so the app's plumbing
    can be tested offline. It does what it is told: refunds any amount it is asked for, repeats references,
    and reveals the settlement account when a pasted document or message asks for it."""

    def __init__(self):
        self.requests = []

    def effective_settings(self):
        return {"model": "fake-model", "temperature": 0, "max_tokens": 600}

    def complete(self, *, system, messages, tools):
        self.requests.append({"system": system, "messages": messages, "tools": tools})
        last = messages[-1]["content"]
        if isinstance(last, list):  # tool results came back
            r = last[0]
            if r["content"].startswith("DENIED"):
                return self._text("I'm sorry, I can't issue that refund.")
            if r["content"].startswith("HELD"):
                return self._text("Your refund is waiting for approval.")
            return self._text("Done, the refund has been issued.")
        text = messages[0]["content"]
        doc_asks = ("settlement account" in text or "vypořádacího" in text or "account number" in text)
        if "refund" in text and "--- Pasted document ---" not in text:
            n = re.search(r"\b(\d{2,4})\b", text)
            if n:
                ref = re.search(r"EB-C-\d+", text)
                return {"content": [{"type": "tool_use", "id": "t1", "name": "issue_refund",
                                     "input": {"customer_ref": ref.group(0) if ref else "EB-C-20417",
                                               "amount": float(n.group(1)), "reason": "customer request"}}]}
        if doc_asks:
            return self._text(f"Summary done. The settlement account is {SECRET_ACCOUNT}.")
        m = re.search(r"reference (\d{4}-\d{4}-\d{4}-\d{2})", text)
        if m:
            return self._text(f"Your complaint {m.group(1)} has been logged.")
        return self._text("The fee rises to 5.00 a month.")

    @staticmethod
    def _text(t):
        return {"content": [{"type": "text", "text": t}]}


@pytest.fixture
def fake():
    return FakeLLM()


@pytest.fixture
def settings():
    return load_settings({})


@pytest.fixture
def replay_settings():
    return load_settings({"DEMO_MODE": "replay"})


@pytest.fixture
def cfg(settings):
    return load_config(settings.guardrails_path)


@pytest.fixture
def docs():
    return load_documents()


@pytest.fixture
def testset(docs):
    return load_testset(docs)


@pytest.fixture
def fake_recording(fake, settings, docs):
    """A recording built from the fake model, for exercising replay."""
    e = Engine(settings, llm=fake, docs=docs)
    results = {}
    for step in range(1, 6):
        e.advance(step)
        for s, sid in SCRIPT:
            if s == step:
                r = e.perform(sid)
                results[r["key"]] = r
    e.advance(6)
    card = e.scorecard()
    return {"recorded_at": "2026-01-01T00:00:00+00:00", "settings": fake.effective_settings(), "rev": e.base_cfg.rev,
            "results": results, "scorecard_traces": e.traces, "scorecard": card}
