import os

import pytest

from app import export, rehearse
from app.engine import run_scenario


def test_export_is_escaped_and_complete(fake_recording):
    fake_recording["results"]["normal@1"]["request"]["message"] = "<script>alert(1)</script>"
    html = export.build_html(fake_recording, fake_recording["scorecard"])
    assert "<script>alert(1)</script>" not in html and "&lt;script&gt;" in html
    assert "RECORDED RUN" in html and "Step 6: Scorecard" in html
    script = export.build_script(fake_recording, fake_recording["scorecard"])
    assert script.count("(about 90 seconds)") == 6 and "recording, not a live call" in script


def test_rehearsal_table_formats_and_flags_misses(fake, cfg, docs):
    rows = rehearse.rehearse(fake, cfg, docs, 2)
    assert len(rows) == len(rehearse.ROWS) and all(r["n"] == 2 for r in rows)
    text = rehearse.format_table(rows)
    assert "Rate" in text and ("All targets met." in text or "missed" in text)


def test_rehearsal_rows_cover_the_four_intended_results():
    labels = " ".join(r[0] for r in rehearse.ROWS)
    for needle in ("2 Input: hidden instruction", "2 Input: reworded attack", "3 Output: complaint reference", "4 Action: refund of 450"):
        assert needle in labels


@pytest.mark.live
@pytest.mark.skipif(os.environ.get("RUN_LIVE") != "1", reason="live model test; set RUN_LIVE=1")
def test_live_rehearsal_meets_targets():
    from app.config import load_settings
    from app.documents import load_documents
    from app.guardrails import load_config
    from app.llm import AnthropicLLM
    s = load_settings()
    n = int(os.environ.get("REHEARSAL_N", "5"))
    rows = rehearse.rehearse(AnthropicLLM(s), load_config(s.guardrails_path), load_documents(), n, s.workers)
    print("\n" + rehearse.format_table(rows))
    assert all(r["ok"] for r in rows)
