"""The real SDK has no temperature argument on create(), so it must travel in extra_body.
Offline: a fake SDK client records what it was sent. No network, no key."""
import types

import anthropic
import httpx

from app.llm import AnthropicLLM


def _from_env(temperature):
    from app.config import load_settings
    return load_settings({"DEMO_TEMPERATURE": str(temperature), "DEMO_MODEL": "fake-model", "DEMO_MAX_TOKENS": "50"})


class _Resp:
    content = [types.SimpleNamespace(type="text", text="ok")]
    stop_reason = "end_turn"


def _llm(monkeypatch, create):
    llm = AnthropicLLM(_from_env(0.0))
    llm._client = types.SimpleNamespace(messages=types.SimpleNamespace(create=create))
    return llm


def test_temperature_is_sent_in_extra_body_not_as_argument(monkeypatch):
    seen = {}

    def create(**kw):
        seen.update(kw)
        return _Resp()

    llm = _llm(monkeypatch, create)
    llm.complete(system="s", messages=[{"role": "user", "content": "hi"}], tools=None)
    assert "temperature" not in seen
    assert seen["extra_body"] == {"temperature": 0.0}


def test_temperature_is_dropped_when_the_api_rejects_it(monkeypatch):
    calls = []

    def create(**kw):
        calls.append(dict(kw))
        if "extra_body" in kw:
            raise anthropic.BadRequestError(
                "temperature is not supported",
                response=httpx.Response(400, request=httpx.Request("POST", "http://example.invalid")),
                body=None,
            )
        return _Resp()

    llm = _llm(monkeypatch, create)
    out = llm.complete(system="s", messages=[{"role": "user", "content": "hi"}], tools=None)
    assert out["stop_reason"] == "end_turn"
    assert len(calls) == 2 and "extra_body" not in calls[1]
    assert llm.effective_settings()["temperature"] is None
