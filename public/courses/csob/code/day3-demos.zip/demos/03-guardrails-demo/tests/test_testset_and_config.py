import json

from app.config import ROOT
from app.guardrails import load_config


def test_testset_shape(testset):
    assert len(testset) == 40
    assert len({t["id"] for t in testset}) == 40
    assert sum(t["label"] == "attack" for t in testset) == 20 == sum(t["label"] == "legit" for t in testset)
    for t in testset:
        assert t["message"].strip() and t["note"].strip() and t["category"]
        if t["label"] == "attack":
            assert t["harm"] in ("leak", "refund")
        else:
            assert "harm" not in t


def test_testset_covers_the_required_kinds(testset):
    cats = {t["category"] for t in testset}
    assert {"injection", "jailbreak", "extraction", "over-limit refund", "Czech or Slovak", "account-like reference"} <= cats
    assert any(t.get("document") for t in testset)


def test_attack_refunds_are_all_over_the_limit(testset):
    import re
    for t in testset:
        if t.get("harm") == "refund":
            nums = [int(n) for n in re.findall(r"\b(\d{3,4})\b", t["message"] + " " + (t.get("document") or "")) if int(n) not in range(20000, 99999)]
            assert any(n > 100 for n in nums), t["id"]


def test_the_testset_is_fictional_only(testset):
    blob = json.dumps(testset).lower()
    for word in ("csob", "kbc", "http://", "https://"):
        assert word not in blob


def test_revision_is_stable_and_changes_with_the_file_or_threshold(tmp_path, settings):
    a = load_config(settings.guardrails_path)
    assert a.rev == load_config(settings.guardrails_path).rev and len(a.rev) == 10
    assert a.with_threshold(0.3).rev != a.rev
    assert a.with_threshold(0.3).rev == a.with_threshold(0.3).rev
    assert a.with_threshold(None).rev == a.rev
    edited = tmp_path / "g.yaml"
    edited.write_text(a.text.replace("threshold: 0.50", "threshold: 0.40"))
    assert load_config(edited).rev != a.rev


def test_the_policy_section_can_be_shown_on_screen(cfg):
    p = cfg.section_text("policy")
    assert p.startswith("policy:") and "default: deny" in p and "allowed_tools" in p and "input:" not in p
    assert len(p.splitlines()) < 20  # short enough to read from the back of a room


def test_no_secrets_in_the_repository():
    needle = "sk-" + "ant-"  # built at runtime so this file does not match itself
    for path in ROOT.rglob("*"):
        if path.is_file() and ".venv" not in path.parts and path.suffix in (".py", ".yaml", ".json", ".md", ".sh", ".js", ".html"):
            assert needle not in path.read_text(errors="ignore"), path
