import pytest

from app.engine import Engine
from app.stepper import OrderError, Stepper


def test_only_the_next_step_is_allowed():
    s = Stepper()
    for bad in (2, 3, 6):
        with pytest.raises(OrderError):
            s.advance(bad)
    s.advance(1)
    with pytest.raises(OrderError):
        s.advance(1)
    with pytest.raises(OrderError):
        s.advance(3)
    for n in (2, 3, 4, 5, 6):
        s.advance(n)
    with pytest.raises(OrderError):
        s.advance(6)


def test_unknown_step_is_rejected():
    with pytest.raises(ValueError):
        Stepper().advance(7)


def test_reset_starts_again():
    s = Stepper()
    s.advance(1), s.advance(2)
    s.reset()
    assert s.progress == 0 and s.layers() == ()
    s.advance(1)


def test_layers_accumulate():
    s = Stepper()
    seen = []
    for n in range(1, 6):
        s.advance(n)
        seen.append(s.layers())
    assert seen == [(), ("input",), ("input", "output"), ("input", "output", "action"), ("input", "output", "action", "human")]


def test_requests_wait_for_the_step_that_introduces_them(fake, settings, docs):
    e = Engine(settings, llm=fake, docs=docs)
    with pytest.raises(OrderError):
        e.perform("normal")  # nothing runs before step 1
    e.advance(1)
    assert e.available() == ["normal", "injected", "refund450"]
    with pytest.raises(OrderError):
        e.perform("reworded")
    e.advance(2)
    assert "reworded" in e.available() and "fp" not in e.available()
    e.advance(3), e.advance(4)
    assert "borderline" in e.available()


def test_scorecard_only_at_step_six(fake, settings, docs):
    e = Engine(settings, llm=fake, docs=docs)
    e.advance(1)
    with pytest.raises(OrderError):
        e.scorecard()
