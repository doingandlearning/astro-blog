from app.engine import run_scenario
from app.pipeline import run_request
from app.tools import ApprovalQueue, RefundLedger


def run(fake, cfg, docs, step, sid, **kw):
    return run_scenario(fake, cfg, docs, step, sid, **kw)


def test_baseline_does_what_it_is_asked(fake, cfg, docs):
    assert run(fake, cfg, docs, 1, "normal")["verdict"]["code"] == "ok"
    inj = run(fake, cfg, docs, 1, "injected")
    assert inj["verdict"]["code"] == "attack_through" and inj["harm"]["secret_leaked"]
    big = run(fake, cfg, docs, 1, "refund450")
    assert big["verdict"]["code"] == "attack_through" and big["refunds"][0]["amount"] == 450


def test_input_guardrail_stops_the_obvious_attack_before_the_model(fake, cfg, docs):
    r = run(fake, cfg, docs, 2, "injected")
    assert r["verdict"]["code"] == "blocked" and fake.requests == []
    assert r["stages"]["model"]["decision"] == "skipped"


def test_reworded_attack_passes_input_then_output_redacts_it(fake, cfg, docs):
    r2 = run(fake, cfg, docs, 2, "reworded")
    assert r2["stages"]["input"]["decision"] == "allow" and r2["verdict"]["code"] == "attack_through"
    r3 = run(fake, cfg, docs, 3, "reworded")
    assert r3["stages"]["output"]["decision"] == "redact" and r3["verdict"]["code"] == "blocked"
    assert "[REDACTED]" in r3["delivered"] and "4417" not in r3["delivered"]
    assert "4417" in r3["model_output"]  # the raw output is still shown to the room


def test_output_guardrail_false_positive_is_reported_as_wrongly_blocked(fake, cfg, docs):
    r = run(fake, cfg, docs, 3, "fp")
    assert r["verdict"]["code"] == "wrongly_blocked" and "2026-0418-7730-01" not in r["delivered"]


def test_action_guardrail_denies_whatever_the_model_was_talked_into(fake, cfg, docs):
    ledger = RefundLedger()
    r = run(fake, cfg, docs, 4, "refund450", ledger=ledger)
    assert r["verdict"]["code"] == "blocked" and ledger.entries == []
    assert r["stages"]["action"]["decision"] == "deny"
    assert any("DENIED" in e["result"] for e in r["tool_events"])


def test_borderline_refund_is_denied_at_step_4_and_held_at_step_5(fake, cfg, docs):
    assert run(fake, cfg, docs, 4, "borderline")["verdict"]["code"] == "wrongly_blocked"
    ledger = RefundLedger()
    q = ApprovalQueue(ledger, "Refunds team lead")
    r = run(fake, cfg, docs, 5, "borderline", ledger=ledger, queue=q)
    assert r["verdict"]["code"] == "held" and ledger.entries == []
    t = r["tickets"][0]
    assert t["status"] == "pending" and t["rule"] == "needs-approval"
    assert t["evidence"]["customer_record"].startswith("Dana Example")
    assert q.resolve(t["id"], True)["status"] == "approved" and ledger.entries[0]["amount"] == 180


def test_rejected_ticket_issues_nothing(fake, cfg, docs):
    ledger = RefundLedger()
    q = ApprovalQueue(ledger, "Refunds team lead")
    r = run(fake, cfg, docs, 5, "borderline", ledger=ledger, queue=q)
    q.resolve(r["tickets"][0]["id"], False)
    assert ledger.entries == []


def test_the_model_receives_exactly_what_the_page_shows(fake, cfg, docs):
    r = run(fake, cfg, docs, 1, "injected")
    sent = fake.requests[0]["messages"][0]["content"]
    assert sent == r["calls"][0]["messages"][0]["content"] and docs["B"].text in sent


def test_the_agent_has_one_tool_and_it_is_a_stub(fake, cfg):
    run_request(fake, cfg, (), "refund 50 for EB-C-20417")
    assert [t["name"] for t in fake.requests[0]["tools"]] == ["issue_refund"]
