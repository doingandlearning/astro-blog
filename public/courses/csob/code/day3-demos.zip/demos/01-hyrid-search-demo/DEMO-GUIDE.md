# Demo guide: hybrid search live (about 15 minutes)

Page: http://127.0.0.1:8080 (stack must be up: see README). Projector in either theme; the "Light / dark" button is top right. The audience watches, predicts and discusses; nobody uses the app.

## The one point

Vector (semantic) search finds text about the right topic. It is weak at exact identifiers. Ask for clause 4.2.1 and it returns plausible clauses about overpayments, but not 4.2.1. Hybrid search (keyword plus vector, fused) puts 4.2.1 first.

## Before the room arrives

1. `docker compose up -d`, then `./test.sh` (takes about 90 seconds; passes = the demo story holds).
2. Open the page. Run one throwaway search (first query after a cold start is slow while the model loads), then press **Reset**.
3. The first preset, "Target: clause 4.2.1", is loaded in the box when the page opens.

## Script (the four steps)

**1. Predict (about 3 min). Run nothing.**
Read the query on screen: *"What does policy clause 4.2.1 say about overpayments?"* Tell the room: Example Bank has about 80 policy clauses, many of them near-duplicates about overpayments with different limits (4.2.1 says 10%, 4.2.7 says 20%, 4.1.2 says 5%, an interest-only rule says 12%). Ask: which search will find exactly clause 4.2.1, vector-only or hybrid? Take a show of hands.

**2. Run vector-only (about 3 min). Click "Run vector-only".**
Expected result: top five are 3.5.3, 6.5.1, 4.3.2, 4.5.1, 4.2.5. All are about overpayments or allowances and read well. None is 4.2.1. Points to make:
- The query's "4.2.1" is highlighted in yellow, but the vector engine cannot use it. It compares meaning, and a clause number carries almost none.
- Scores are all close (0.66 to 0.64). Nothing on screen says "wrong". Ask: would a junior reading this spot it?
- Read 3.5.3 aloud: it mentions "policy clause" in general, which is why it matches the phrase "policy clause".

**3. Run hybrid (about 3 min). Click "Run hybrid".**
Expected result: 4.2.1 is first, followed by 4.2.6, 6.5.1, 3.5.1, 4.2.5. Under each result the grey line shows where it sat in each list. For 4.2.1: **keyword #1, vector #7**.
- Explain the caption: each list gives a clause 1 / (60 + rank), and the two scores are added. 4.2.1 is first in the keyword list because the exact token "4.2.1" is rare, and fairly high in the vector list, so it wins the sum.
- Now click **Reveal correct clause**. The green tick marks the exact reference match. (This is deliberately a separate button so the prediction step is not spoiled.)
- Note the vector rank 7 is not a failure of the model: it is the correct clause, just beaten by vaguer ones.

**4. The question (about 5 min).**
Ask the room: *whose job is it to catch the vector-only gap before go-live?* Prompts: the team that built the assistant? The business owner who knows people quote clause numbers? Security or model risk, who sign off? What test would have caught it (a set of known-answer queries that include identifiers, like `./test.sh` does)? Who owns that test after launch?

## If someone says "you rigged it"

Nothing is hard-coded or reordered. Open `app/search.py`: vector mode is one SQL query (`ORDER BY embedding <=> query`), hybrid is `reciprocal_rank_fusion` of that list and a BM25 list (`app/bm25.py`, about 60 lines). The corpus is in `app/corpus/` and the room can read it. It is fair to say the corpus was written with near-duplicate clauses on purpose, because real policy sets are full of them.

## Other presets (use as time allows)

| Preset | Vector-only | Hybrid | Use it to show |
| --- | --- | --- | --- |
| Control: missed payments | 5.1.1 first, then 5.3.1 | 5.1.1 first, then 5.3.1 | Vector search is not broken. A plain-English question works fine. |
| Control: complaint records | 7.2.1 first | 7.1.2, 7.3.2, 7.1.1, then 7.2.1 | Honest caveat: hybrid is not always better. Keyword matches on "records" and "complaints" pull in neighbours, and the best answer drops to fourth. |
| Control: extra payments | 4.2.7, then 4.2.1 | 4.2.7, then 4.2.1 | Same topic, no reference given: both modes return the right family of clauses, with 4.2.1 second. Vector search is good at meaning; a plain question cannot pick between near-duplicates, so this also shows why people quote clause numbers. |
| Target: product code | 2.1.4 first | 2.1.4 first | A candid result: **bge-m3 handles a product code like MTG-STD-03 well**, so this one does not fail. Use it to say identifier weakness depends on the embedding model and the identifier, so test yours rather than assume. 2.1.4 says MTG-STD-03 has no early repayment charge, the opposite of the other products. |

Exact ranks can shift slightly if the model or corpus changes. `./test.sh` fails loudly if the target story breaks.

## Why this model and what the miss looks like

`bge-m3` is the embedding model already used elsewhere in this course, runs on a laptop with no internet, and is pinned in `docker-compose.yml`. On the target query clause 4.2.1 comes 7th by vector similarity (0.629 against 0.662 for the top result), behind clauses that mention "policy clause" and "overpayment allowance" in general terms. The scores sit in a narrow band, which is why nothing looks wrong on screen.

## Things to watch for

- **Hybrid is not magic.** It won here partly because 4.2.1 is also reasonably high in the vector list. Its margin is small (0.0313 against 0.0305). If asked, say so: fusion rewards agreement between lists.
- **Keyword search has no stemming here.** "overpayments" does not match "overpayment". That is a real limit of keyword search, and it is why the wording of near-duplicate clauses matters.
- **Do not press Enter in the search box** to run a search; there is no Enter shortcut, so the trainer decides which button runs.
- **Fallback:** if the app will not start, show screenshots of the two panels taken at rehearsal (no static export is built).
