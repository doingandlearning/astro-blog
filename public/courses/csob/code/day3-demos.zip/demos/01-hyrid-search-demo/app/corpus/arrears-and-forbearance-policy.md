---
title: Arrears and Forbearance Policy
doc_id: ARR-POL-05
---

## 5.1 Early arrears

5.1.1 A customer who misses one mortgage payment is contacted by phone or message within 3 working days.

5.1.2 A letter is sent after the first missed payment explaining the arrears and how to get help.

5.1.3 The customer must be asked about their circumstances, and the answers recorded, before any arrangement is agreed.

## 5.2 Forbearance options

5.2.1 A payment holiday of up to 3 months may be offered once in any 24-month period where the customer has a short-term loss of income.

5.2.2 The term of the mortgage may be extended to reduce the monthly payment, subject to a maximum age at the end of the term of 75.

5.2.3 A repayment mortgage may be switched to interest-only for up to 12 months while the customer's income recovers.

5.2.4 Arrears may be added to the balance (capitalised) only with the customer's agreement, and only after other options have been considered.

## 5.3 Escalation

5.3.1 A customer who has missed three payments is referred to the Collections team.

5.3.2 Repossession proceedings may be started only as a last resort and not before 6 months of arrears, unless the customer has not engaged with the bank.

5.3.3 Where a customer shows signs of vulnerability, the case is reviewed by a Specialist Support Adviser before any escalation.

## 5.4 Payments while in arrears

5.4.1 A customer in arrears may not make overpayments until the arrears have been cleared.

5.4.2 Payments received from a customer in arrears are applied to the arrears first, then to the current month's payment.
