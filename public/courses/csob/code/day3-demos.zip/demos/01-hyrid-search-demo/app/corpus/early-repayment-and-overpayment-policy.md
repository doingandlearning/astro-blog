---
title: Early Repayment and Overpayment Policy
doc_id: ERP-POL-04
---

## 4.1 General principles

4.1.1 A customer may repay all or part of their mortgage before the end of the term, subject to this policy and to the terms of their product.

4.1.2 Overpayments on a fixed-rate mortgage during the fixed-rate period are limited to 5% of the original loan amount in any 12-month period. Amounts above that limit are treated as early repayment and the early repayment charge in the product terms applies.

4.1.3 Lump-sum overpayments are applied on the day cleared funds are received. Payments made by cheque are applied on the day the cheque clears.

## 4.2 Variable-rate and tracker mortgages

4.2.1 Overpayments under this policy: a customer on a variable-rate or tracker mortgage may overpay by up to 10% of the outstanding balance in each anniversary year. The overpayment allowance applies without charge and overpayments reduce the capital balance.

4.2.2 Where a payment would take the customer above the annual allowance, the excess is returned unless Mortgage Operations approves it as a partial early repayment.

4.2.3 After an overpayment the customer may choose to reduce the monthly payment or to shorten the term. Where the customer does not choose, the term is shortened.

4.2.4 An unused allowance does not carry forward into the next anniversary year.

4.2.5 Regular monthly overpayments must be set up by direct debit using the overpayment mandate, and may be stopped or changed by the customer at any time.

4.2.6 Overpayments on a mortgage with a payment holiday in force are not accepted until the holiday has ended.

4.2.7 A customer on a discounted variable-rate mortgage may make overpayments of up to 20% of the outstanding balance in each anniversary year without charge during the discount period. After the discount period ends, clause 4.2.1 Overpayments under this policy: a customer on a variable-rate or tracker mortgage may overpay by up to 10% of the outstanding balance in each anniversary year. The overpayment allowance applies without charge and overpayments reduce the capital balance.

## 4.3 Early repayment charges

4.3.1 An early repayment charge applies only where the product terms say so. The charge is a percentage of the amount repaid early.

4.3.2 Where a charge applies, it is calculated on the amount repaid in excess of the annual overpayment allowance, not on the full balance.

4.3.3 No early repayment charge is taken where the mortgage is repaid because of the death of a borrower.

4.3.4 A customer who asks for a statement of the early repayment charge payable must receive it within 5 working days.

## 4.4 Redemption

4.4.1 A redemption statement is valid for 28 days and shows the interest accrued to the redemption date.

4.4.2 Interest is charged daily on the outstanding balance up to the day before the redemption payment is received.

4.4.3 Title deeds and the discharge of the charge are released within 7 working days of full redemption.

## 4.5 Record keeping

4.5.1 Every overpayment is logged in the servicing system with a reason code and the allowance used so far in the anniversary year.
