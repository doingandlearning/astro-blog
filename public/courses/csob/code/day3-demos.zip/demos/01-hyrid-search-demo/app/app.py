import json
from pathlib import Path

from flask import Flask, jsonify, request, send_from_directory

from search import SearchEngine, connect, ensure_seeded

FRONTEND_DIR = Path(__file__).parent.parent / "frontend"
PRESETS = json.loads((Path(__file__).parent / "presets.json").read_text())

app = Flask(__name__)

conn = connect()
ensure_seeded(conn)
engine = SearchEngine(conn)


@app.route("/")
def index():
    return send_from_directory(FRONTEND_DIR, "index.html")


@app.route("/api/presets")
def presets():
    return jsonify(PRESETS)


@app.route("/api/search", methods=["POST"])
def search():
    body = request.get_json(force=True) or {}
    query = (body.get("query") or "").strip()
    mode = body.get("mode")
    if not query:
        return jsonify({"error": "query is required"}), 400
    if mode not in ("vector", "hybrid"):
        return jsonify({"error": "mode must be 'vector' or 'hybrid'"}), 400
    return jsonify({
        "query": query,
        "mode": mode,
        "results": engine.search(query, mode, top_k=5, expect=body.get("expect")),
    })


@app.route("/api/health")
def health():
    return jsonify({"status": "ok", "chunks": len(engine.chunks)})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
