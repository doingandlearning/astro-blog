---
title: Complaints Handling Procedure
doc_id: CMP-PRC-06
---

## 6.1 Receiving a complaint

6.1.1 Any expression of dissatisfaction about a mortgage is treated as a complaint, whether it arrives by phone, letter, branch or social media.

6.1.2 Every complaint is acknowledged in writing within 2 working days.

## 6.2 Investigation and response

6.2.1 The complaint handler must not have been involved in the matter complained about.

6.2.2 A final response is sent within 8 weeks of receipt. Where this is not possible, the customer is told why and when to expect it.

6.2.3 The final response must say how the customer can refer the complaint to the independent ombudsman service if they are unhappy.

## 6.3 Escalation

6.3.1 A customer who is unhappy with the first response may ask for review by the Complaints Review Manager.

6.3.2 The Complaints Review Manager's decision is final within the bank.

## 6.4 Redress

6.4.1 Where a complaint is upheld, the customer is put back in the position they would have been in without the error.

6.4.2 Compensation for distress or inconvenience is agreed with the Complaints Review Manager and paid within 10 working days of acceptance.

## 6.5 Complaints about overpayments and charges

6.5.1 A complaint that an overpayment was refused, or that an early repayment charge was wrongly applied, is a priority complaint. The handler must record which policy clause or product term was cited to the customer.

6.5.2 Where the customer was given the wrong overpayment allowance, the handler must check the allowance in the product terms before the final response is sent.
