---
title: Mortgage Product Terms
doc_id: MPT-TRM-02
---

## 2.1 MTG-STD-03 Standard Variable Rate Mortgage

2.1.1 MTG-STD-03 is a repayment mortgage charged at the bank's standard variable rate, currently 7.49%. The rate may go up or down.

2.1.2 The minimum loan for MTG-STD-03 is 50,000 and the term is 5 to 35 years.

2.1.3 The customer may overpay any amount, at any time, on MTG-STD-03.

2.1.4 MTG-STD-03 can be repaid early, in full or in part, on any day without extra cost. Interest is charged daily up to the day before repayment.

2.1.5 An arrangement fee of 495 applies to MTG-STD-03 and may be added to the loan.

## 2.2 MTG-FIX-05 Five-Year Fixed Rate Mortgage

2.2.1 MTG-FIX-05 is a repayment mortgage with a fixed rate of 4.89% for 5 years, then the standard variable rate.

2.2.2 MTG-FIX-05 carries an early repayment charge of 5% of the amount repaid in year 1, 4% in year 2, 3% in year 3, 2% in year 4 and 1% in year 5.

2.2.3 During the fixed-rate period the customer may overpay up to 10% of the outstanding balance each year on MTG-FIX-05 without an early repayment charge.

2.2.4 MTG-FIX-05 is portable to a new property, subject to a new affordability assessment.

## 2.3 MTG-BTL-02 Buy-to-Let Two-Year Fixed Rate Mortgage

2.3.1 MTG-BTL-02 is an interest-only or repayment buy-to-let mortgage with a fixed rate of 5.39% for 2 years.

2.3.2 MTG-BTL-02 carries an early repayment charge of 3% of the amount repaid in year 1 and 2% in year 2.

2.3.3 During the fixed-rate period the customer may overpay up to 10% of the outstanding balance each year on MTG-BTL-02 without an early repayment charge. The allowance in clause 4.2.1 of the Early Repayment and Overpayment Policy does not apply to this product.

2.3.4 Rental income must cover 125% of the interest payment, stress tested at 5.5%.

## 2.4 MTG-FTB-01 First-Time Buyer Mortgage

2.4.1 MTG-FTB-01 is a repayment mortgage for first-time buyers with a discounted variable rate of 1.00% below the standard variable rate for 3 years.

2.4.2 MTG-FTB-01 carries an early repayment charge of 2% of the amount repaid during the discount period.

2.4.3 During the discount period the customer may overpay up to 20% of the outstanding balance each year on MTG-FTB-01 without an early repayment charge.

2.4.4 The maximum loan to value for MTG-FTB-01 is 95%, with a guarantor or family deposit for loans above 90%.
