"""BM25 keyword search and reciprocal rank fusion, written out in full so the
room can read them. No stemming, no synonyms: a token either matches or it
doesn't, which is exactly why exact references like "4.2.1" work here.
"""

import math
import re
from collections import Counter

# Keeps clause references ("4.2.1") and product codes ("mtg-std-03") whole.
TOKEN_RE = re.compile(r"[a-z0-9]+(?:[-.][a-z0-9]+)*")

STOPWORDS = {
    "a", "an", "and", "are", "as", "at", "be", "by", "does", "for", "from", "how", "in", "is",
    "it", "of", "on", "or", "say", "that", "the", "to", "what", "when", "which", "with", "about",
}

K1, B = 1.5, 0.75
RRF_K = 60
LIST_DEPTH = 20


def tokenize(text: str) -> list[str]:
    return [t for t in TOKEN_RE.findall(text.lower()) if t not in STOPWORDS]


class BM25:
    def __init__(self, texts: list[str]):
        self.docs = [Counter(tokenize(t)) for t in texts]
        self.lengths = [sum(d.values()) for d in self.docs]
        self.avg_len = sum(self.lengths) / len(self.docs)
        df = Counter(token for d in self.docs for token in d)
        n = len(self.docs)
        self.idf = {t: math.log(1 + (n - f + 0.5) / (f + 0.5)) for t, f in df.items()}

    def search(self, query: str, depth: int = LIST_DEPTH) -> list[tuple[int, float]]:
        """Returns (doc index, score) best first; documents matching nothing are left out."""
        terms = tokenize(query)
        scored = []
        for i, doc in enumerate(self.docs):
            score = 0.0
            for term in terms:
                tf = doc.get(term, 0)
                if tf:
                    norm = tf + K1 * (1 - B + B * self.lengths[i] / self.avg_len)
                    score += self.idf[term] * tf * (K1 + 1) / norm
            if score > 0:
                scored.append((i, score))
        scored.sort(key=lambda pair: -pair[1])
        return scored[:depth]


def reciprocal_rank_fusion(*ranked_lists: list[int], k: int = RRF_K) -> list[tuple[int, float]]:
    """Each list is doc ids best first. A doc scores sum(1 / (k + rank)) over
    the lists it appears in, so appearing high in both lists beats appearing
    first in only one."""
    scores: dict[int, float] = {}
    for ranked in ranked_lists:
        for rank, doc_id in enumerate(ranked, start=1):
            scores[doc_id] = scores.get(doc_id, 0.0) + 1.0 / (k + rank)
    return sorted(scores.items(), key=lambda pair: -pair[1])
