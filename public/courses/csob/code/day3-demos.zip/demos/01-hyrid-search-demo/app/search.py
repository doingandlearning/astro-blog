"""Vector-only and hybrid search over the clause table."""

import json
import os
from pathlib import Path

import psycopg
from pgvector.psycopg import register_vector

from bm25 import BM25, LIST_DEPTH, reciprocal_rank_fusion, tokenize
from ollama_client import embed

DATABASE_URL = os.environ.get("DATABASE_URL", "postgresql://postgres:postgres@localhost:5050/pgvector")
DATA_FILE = Path(__file__).parent / "data" / "chunks.json"
SCHEMA_FILE = Path(__file__).parent.parent / "postgres" / "schema.sql"
COLUMNS = "id, doc_id, doc_title, section, ref, text, codes"


def connect():
    conn = psycopg.connect(DATABASE_URL)
    register_vector(conn)
    return conn


def ensure_seeded(conn) -> int:
    """Loads data/chunks.json into the chunks table unless it is already there."""
    data = json.loads(DATA_FILE.read_text())
    cur = conn.cursor()
    cur.execute(SCHEMA_FILE.read_text())  # idempotent; also covers a volume created before this schema
    cur.execute("SELECT value FROM corpus_meta WHERE key = 'hash'")
    row = cur.fetchone()
    if row and row[0] == data["hash"]:
        cur.execute("SELECT count(*) FROM chunks")
        return cur.fetchone()[0]
    cur.execute("TRUNCATE chunks RESTART IDENTITY")
    for c in data["chunks"]:
        cur.execute(
            """INSERT INTO chunks (doc_id, doc_title, section, ref, text, codes, index_text, embedding)
               VALUES (%s, %s, %s, %s, %s, %s, %s, %s)""",
            (c["doc_id"], c["doc_title"], c["section"], c["ref"], c["text"], c["codes"],
             c["index_text"], c["embedding"]),
        )
    cur.execute(
        "INSERT INTO corpus_meta VALUES ('hash', %s) ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value",
        (data["hash"],),
    )
    conn.commit()
    return len(data["chunks"])


class SearchEngine:
    def __init__(self, conn):
        cur = conn.cursor()
        cur.execute(f"SELECT {COLUMNS}, index_text FROM chunks ORDER BY id")
        rows = cur.fetchall()
        self.chunks = [
            dict(zip(["id", "doc_id", "doc_title", "section", "ref", "text", "codes"], r[:7])) for r in rows
        ]
        self.by_id = {c["id"]: c for c in self.chunks}
        self.bm25 = BM25([r[7] for r in rows])
        self.conn = conn

    def vector_list(self, query: str, depth: int = LIST_DEPTH) -> list[tuple[int, float]]:
        """(chunk id, cosine similarity) best first, straight from pgvector."""
        cur = self.conn.cursor()
        cur.execute(
            """SELECT id, 1 - (embedding <=> %s::vector) AS similarity
               FROM chunks ORDER BY embedding <=> %s::vector LIMIT %s""",
            (embed(query), embed(query), depth),
        )
        return cur.fetchall()

    def keyword_list(self, query: str, depth: int = LIST_DEPTH) -> list[tuple[int, float]]:
        return [(self.chunks[i]["id"], score) for i, score in self.bm25.search(query, depth)]

    def search(self, query: str, mode: str, top_k: int = 5, expect: str | None = None) -> list[dict]:
        vec = self.vector_list(query)
        vec_rank = {cid: r for r, (cid, _) in enumerate(vec, start=1)}
        vec_sim = dict(vec)

        if mode == "vector":
            ordered = [(cid, sim) for cid, sim in vec]
            kw_rank = {}
        elif mode == "hybrid":
            kw = self.keyword_list(query)
            kw_rank = {cid: r for r, (cid, _) in enumerate(kw, start=1)}
            ordered = reciprocal_rank_fusion([c for c, _ in kw], [c for c, _ in vec])
        else:
            raise ValueError(f"unknown mode {mode!r}")

        tokens = set(tokenize(query))
        results = []
        for rank, (cid, score) in enumerate(ordered[:top_k], start=1):
            chunk = self.by_id[cid]
            results.append({
                **chunk,
                "rank": rank,
                "score": round(score, 4),
                "vector_rank": vec_rank.get(cid),
                "keyword_rank": kw_rank.get(cid),
                "vector_similarity": round(vec_sim[cid], 3) if cid in vec_sim else None,
                "exact": chunk["ref"] == expect if expect else chunk["ref"] in tokens,
            })
        return results
