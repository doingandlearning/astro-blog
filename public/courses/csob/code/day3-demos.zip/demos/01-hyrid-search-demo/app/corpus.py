"""Parses the Markdown policy documents in corpus/ into clause-level chunks.

Each document has a small front-matter block (title, doc_id), `## 4.2 Heading`
section lines, and one clause per paragraph starting with its reference
("4.2.1 ..."). One clause is one chunk.
"""

import re
from pathlib import Path

CORPUS_DIR = Path(__file__).parent / "corpus"

CLAUSE_RE = re.compile(r"^(\d+\.\d+\.\d+)\s+(.*)$")
SECTION_RE = re.compile(r"^##\s+(\d+\.\d+)\s+(.*)$")
PRODUCT_CODE_RE = re.compile(r"\bMTG-[A-Z]+-\d+\b")


def parse_document(path: Path) -> list[dict]:
    text = path.read_text(encoding="utf-8")
    _, front, body = text.split("---", 2)
    meta = dict(line.split(":", 1) for line in front.strip().splitlines())
    title, doc_id = meta["title"].strip(), meta["doc_id"].strip()

    chunks, section, current = [], "", None
    for line in body.splitlines():
        line = line.strip()
        section_match = SECTION_RE.match(line)
        clause_match = CLAUSE_RE.match(line)
        if section_match:
            section = f"{section_match.group(1)} {section_match.group(2)}"
        elif clause_match:
            current = {
                "doc_id": doc_id,
                "doc_title": title,
                "section": section,
                "ref": clause_match.group(1),
                "text": clause_match.group(2),
            }
            chunks.append(current)
        elif line and current:  # continuation of a multi-line clause
            current["text"] += " " + line

    for chunk in chunks:
        chunk["codes"] = sorted(set(PRODUCT_CODE_RE.findall(chunk["section"] + " " + chunk["text"])))
        # What gets embedded and keyword-indexed: the same text a reader sees.
        chunk["index_text"] = f"{title} - {chunk['section']}\nClause {chunk['ref']}: {chunk['text']}"
    return chunks


def load_corpus() -> list[dict]:
    chunks = []
    for path in sorted(CORPUS_DIR.glob("*.md")):
        chunks.extend(parse_document(path))
    return chunks
