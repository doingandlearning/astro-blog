"""Builds app/data/chunks.json: parses the corpus and embeds every clause with
the local bge-m3 model. Run it whenever the corpus or the model changes:

    docker compose exec app python ingest.py

The result is committed, so a fresh checkout needs no embedding step.
"""

import hashlib
import json
from pathlib import Path

from corpus import load_corpus
from ollama_client import EMBEDDING_MODEL, embed

DATA_FILE = Path(__file__).parent / "data" / "chunks.json"


def corpus_hash(chunks: list[dict]) -> str:
    joined = "\n".join(c["index_text"] for c in chunks) + EMBEDDING_MODEL
    return hashlib.sha256(joined.encode()).hexdigest()[:16]


if __name__ == "__main__":
    chunks = load_corpus()
    for i, chunk in enumerate(chunks, start=1):
        chunk["embedding"] = embed(chunk["index_text"])
        print(f"embedded {i}/{len(chunks)}  {chunk['ref']}", flush=True)
    DATA_FILE.parent.mkdir(exist_ok=True)
    DATA_FILE.write_text(
        json.dumps({"model": EMBEDDING_MODEL, "hash": corpus_hash(chunks), "chunks": chunks})
    )
    print(f"wrote {DATA_FILE}")
