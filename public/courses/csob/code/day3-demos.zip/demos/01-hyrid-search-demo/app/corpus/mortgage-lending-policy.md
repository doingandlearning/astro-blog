---
title: Mortgage Lending Policy
doc_id: MLP-POL-01
---

## 3.1 Affordability

3.1.1 The maximum loan is 4.5 times the applicant's gross annual income for a single applicant and 4.0 times combined income for joint applicants.

3.1.2 Every application is stress tested at the product rate plus 3 percentage points. The applicant must remain able to meet the payment under the stress test.

3.1.3 Self-employed applicants must provide evidence of income for the last two complete tax years.

3.1.4 Existing credit commitments are deducted from income before the income multiple is applied.

## 3.2 Loan to value

3.2.1 The maximum loan to value is 95% for residential purchase, subject to the product terms.

3.2.2 The maximum loan to value for buy-to-let is 75%.

3.2.3 Valuations must be carried out by a panel valuer. A valuation is valid for 6 months.

## 3.3 Interest-only lending

3.3.1 Interest-only lending is available only where the applicant has a credible repayment strategy, evidenced at application.

3.3.2 The maximum loan to value for interest-only lending is 50%.

3.3.3 Repayment strategies are reviewed with the customer every 5 years.

## 3.4 Exceptions

3.4.1 Any exception to this policy requires written sign-off from Credit Risk before the offer is issued.

3.4.2 Exceptions are reported to the Credit Committee each quarter.

## 3.5 Repayment strategies

3.5.1 Where an interest-only repayment strategy relies on extra capital payments from the customer, the allowance in clause 4.2.1 must be checked before the strategy is accepted.

3.5.2 On an interest-only mortgage, overpayments of up to 12% of the outstanding balance in each anniversary year are permitted without charge where they are recorded as part of the agreed repayment strategy.

3.5.3 A lender must not describe an overpayment allowance to a customer without confirming which policy clause or product term it comes from.
