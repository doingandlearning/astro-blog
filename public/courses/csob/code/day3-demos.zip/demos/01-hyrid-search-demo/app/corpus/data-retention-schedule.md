---
title: Data Retention Schedule
doc_id: DRS-SCH-07
---

## 7.1 Mortgage account records

7.1.1 Mortgage account records are kept for 6 years after the mortgage has been redeemed.

7.1.2 Application records for declined applications are kept for 12 months.

7.1.3 Recordings of calls about a mortgage are kept for 6 years.

## 7.2 Complaint records

7.2.1 Complaint files are kept for 6 years from the date of the final response.

7.2.2 Complaint files that involve a vulnerable customer are reviewed before deletion.

## 7.3 Payment records

7.3.1 Records of overpayments and of early repayment charge calculations are kept for 6 years after redemption, so that the allowance used can be shown if the customer disputes it.

7.3.2 Records of payments received while an account is in arrears are kept for 6 years after the arrears are cleared.

## 7.4 Deletion

7.4.1 Records past their retention period are deleted by a monthly job and the deletion is logged.

7.4.2 A legal hold suspends deletion for the records it covers until Legal lifts it.

7.4.3 A customer's request for access to their data must be answered within one month.
