"""Demo acceptance tests. They run against the live stack (docker compose up -d)
and the real bge-m3 model, because the point is to fail loudly if a model or
corpus change breaks the demo's story. Run: ./test.sh
"""

import json
import socket
import ipaddress
import sys
from pathlib import Path

import pytest

APP_DIR = Path(__file__).parent.parent / "app"
sys.path.insert(0, str(APP_DIR))

from search import SearchEngine, connect, ensure_seeded  # noqa: E402

PRESETS = {p["label"]: p for p in json.loads((APP_DIR / "presets.json").read_text())}
TARGET = PRESETS["Target: clause 4.2.1"]
PRODUCT = PRESETS["Target: product code"]
CONTROLS = [p for p in PRESETS.values() if p["kind"] == "control"]


@pytest.fixture(scope="module")
def engine():
    conn = connect()
    ensure_seeded(conn)
    return SearchEngine(conn)


def refs(results):
    return [r["ref"] for r in results]


def test_target_query_vector_only_misses_the_exact_clause(engine):
    results = engine.search(TARGET["query"], "vector", top_k=3)
    assert TARGET["expect"] not in refs(results), (
        f"vector-only found {TARGET['expect']} in its top 3 ({refs(results)}); the demo's story is broken. "
        "Change the corpus, not the retrieval code."
    )


def test_target_query_hybrid_puts_the_exact_clause_first(engine):
    results = engine.search(TARGET["query"], "hybrid", top_k=5)
    assert results[0]["ref"] == TARGET["expect"], f"hybrid top 5 was {refs(results)}"
    assert results[0]["exact"]


def test_vector_only_results_are_the_wrong_clause_about_the_right_topic(engine):
    # Plausible but wrong: same topic, so a reader could be fooled.
    results = engine.search(TARGET["query"], "vector", top_k=3)
    assert all("overpay" in r["text"].lower() or "allowance" in r["text"].lower() for r in results)


def test_product_code_query_hybrid_finds_the_product_clause(engine):
    results = engine.search(PRODUCT["query"], "hybrid", top_k=3)
    assert results[0]["ref"] == PRODUCT["expect"], f"hybrid top 3 was {refs(results)}"


@pytest.mark.parametrize("preset", CONTROLS, ids=lambda p: p["label"])
@pytest.mark.parametrize("mode", ["vector", "hybrid"])
def test_control_queries_work_in_both_modes(engine, preset, mode):
    results = engine.search(preset["query"], mode, top_k=5)
    assert preset["expect"] in refs(results), f"{mode} top 5 was {refs(results)}"


def test_search_makes_no_outbound_connections(engine, monkeypatch):
    """Everything the search path touches (Postgres, Ollama) must be on this machine."""
    real_connect = socket.socket.connect

    def guarded(self, address):
        if self.family in (socket.AF_INET, socket.AF_INET6):
            host = address[0]
            assert ipaddress.ip_address(host).is_loopback, f"outbound connection to {host}"
        return real_connect(self, address)

    monkeypatch.setattr(socket.socket, "connect", guarded)
    for mode in ("vector", "hybrid"):
        engine.search("a query nobody has embedded before 9f3", mode)
