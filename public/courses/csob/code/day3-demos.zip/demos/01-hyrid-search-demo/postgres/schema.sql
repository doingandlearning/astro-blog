CREATE EXTENSION IF NOT EXISTS vector;

-- One row per clause. Loaded from app/data/chunks.json at app start-up, so the
-- database is already populated (with real bge-m3 embeddings) before the
-- first search; nothing is embedded at demo time except the query itself.
CREATE TABLE IF NOT EXISTS chunks (
    id SERIAL PRIMARY KEY,
    doc_id TEXT NOT NULL,
    doc_title TEXT NOT NULL,
    section TEXT NOT NULL,
    ref TEXT NOT NULL,
    text TEXT NOT NULL,
    codes TEXT[] NOT NULL DEFAULT '{}',
    index_text TEXT NOT NULL,
    -- bge-m3 produces 1024-dimensional embeddings
    embedding VECTOR(1024) NOT NULL
);

CREATE TABLE IF NOT EXISTS corpus_meta (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

-- No ANN index on purpose: ~80 rows, an exact scan is correct and instant,
-- and an approximate index would add its own recall errors to a demo that is
-- about retrieval errors.
