# Hybrid search demo (Day 1)

A local app that runs the same query two ways, side by side: **vector-only** and **hybrid** (BM25 keyword + vector, merged by reciprocal rank fusion). Built to the brief in `../01-hybrid-search-demo-brief.md`. The trainer's script is in [DEMO-GUIDE.md](DEMO-GUIDE.md).

Nothing is hard-coded. The corpus is 83 clauses from six fictional "Example Bank" policy documents (`app/corpus/`), embedded with `bge-m3` and stored in Postgres/pgvector. The vector-only miss happens because of how the embeddings really behave on this corpus.

## Stack

| Part | What | Notes |
| --- | --- | --- |
| Vector store | Postgres + pgvector | Pre-populated at start-up from `app/data/chunks.json` |
| Embeddings | `bge-m3` via Ollama (local) | Model name is pinned in `docker-compose.yml`; the demo result depends on it |
| Keyword search | BM25, `app/bm25.py` (about 60 lines, no stemming) | Keeps `4.2.1` and `MTG-STD-03` as single tokens |
| Fusion | Reciprocal rank fusion, k = 60, top 20 of each list | Same file |
| App | Flask, serves the API and the page | One URL, no build step |

No API keys, no accounts, no telemetry. At run time the only network traffic is between containers on this machine.

## Start

```
docker compose up -d --build
docker exec rag-poc-ollama ollama pull bge-m3     # first time only (1.2 GB); needs internet once
```

Open http://127.0.0.1:8080. Everything is bound to 127.0.0.1.

On start-up the app creates the table and loads the pre-computed clause embeddings, so the database is already populated. Only the query is embedded live.

## Test

```
./test.sh
```

Runs against the live stack and the real model. It checks that:

- for the target query the vector-only top three does **not** contain clause 4.2.1 and hybrid puts it first;
- the product-code query's hybrid top result is the right clause;
- the three control queries return the right clause in the top five in both modes;
- the search path makes no connection to anything but loopback.

If a model or corpus change breaks the story, this fails with the ranks it found.

## Changing the corpus or model

Edit `app/corpus/*.md` (one clause per paragraph, starting with its reference), then re-embed and restart:

```
docker compose exec app python ingest.py
docker compose restart app
./test.sh
```

If the real model finds the right clause on the target query, change the **corpus wording**, never the retrieval code. The ranks 4.2.1 holds today are in the guide.

## Rehearsal checklist (morning of the session, not the night before)

1. `docker compose up -d`, wait for `curl -s http://127.0.0.1:8080/api/health` to return `"status":"ok","chunks":83`.
2. `./test.sh` passes.
3. Turn Wi-Fi off. Reload the page and run the four-step script once. It must work with no network.
4. Check type size and both themes on the projector.
5. Close other heavy apps: the first query after a cold start takes a couple of seconds while Ollama loads the model. Run one throwaway search before the room arrives.

## Stop

```
docker compose down        # keeps the data and the pulled model
docker compose down -v     # also wipes the pulled model: you will need to pull it again
```

## Fallback if the app will not run on the day

There is no static export. Take screenshots of the two panels for the target query during rehearsal and keep them on a slide.

## Known simplifications

- 83 clauses is tiny. On a real corpus of thousands of near-duplicate clauses the vector miss would be more frequent, not less.
- BM25 has no stemming, so "overpayments" does not match "overpayment". That is deliberate (exact matching is the point) and is also a real weakness of keyword search.
- Not included from the brief's optional list: the security-trimming toggle and the static export.
