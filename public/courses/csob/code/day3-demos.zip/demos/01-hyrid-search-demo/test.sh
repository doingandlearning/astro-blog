#!/bin/sh
# Runs the demo acceptance tests against the running stack.
cd "$(dirname "$0")" && uv run --quiet --python 3.12 --with pytest --with requests --with 'psycopg[binary]==3.2.1' --with pgvector==0.3.6 pytest -q tests "$@"
