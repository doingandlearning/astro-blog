#!/usr/bin/env bash
# Start the demo on http://127.0.0.1:8090. Use --replay to serve the saved recording.
set -euo pipefail
cd "$(dirname "$0")"
# Load ANTHROPIC_API_KEY and any DEMO_* settings from .env if the file exists (never commit it)
if [[ -f .env ]]; then set -a; source .env; set +a; fi
if [[ "${1:-}" == "--replay" ]]; then export DEMO_MODE=replay; fi
exec uv run python -m app.server
