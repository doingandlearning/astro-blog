#!/usr/bin/env bash
# Run every step N times (default 20) against the real model and print trigger rates.
set -euo pipefail
cd "$(dirname "$0")"
# Load ANTHROPIC_API_KEY and any DEMO_* settings from .env if the file exists (never commit it)
if [[ -f .env ]]; then set -a; source .env; set +a; fi
exec uv run python -m app.rehearse "$@"
