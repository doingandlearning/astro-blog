"""FastAPI app. Serves one static page and a small JSON API. Binds to 127.0.0.1 only."""
import os
import sys
import threading
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from .config import HOST, load_settings
from .engine import Engine, RecordingError
from .llm import LLMError
from .prompts import FAKE_DETAILS
from .stepper import OrderError

STATIC = Path(__file__).parent / "static"


class RunRequest(BaseModel):
    action: str
    doc: str | None = None


def create_app(settings, llm=None, recording=None, llm_factory=None) -> FastAPI:
    kwargs = {"llm_factory": llm_factory} if llm_factory else {}
    engine = Engine(settings, llm=llm, recording=recording, **kwargs)
    lock = threading.Lock()  # one trainer, one run at a time
    app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)

    @app.get("/")
    def index():
        return FileResponse(STATIC / "index.html")

    @app.get("/api/documents")
    def documents():
        return {d.id: {"title": d.title, "text": d.text, "spans": d.spans, "note": d.note}
                for d in engine.docs.values()}

    @app.get("/api/state")
    def state():
        from .prompts import BASE_SYSTEM
        return {**engine.state(), "base_system": BASE_SYSTEM, "fake_details": FAKE_DETAILS}

    @app.post("/api/run")
    def run(req: RunRequest):
        with lock:
            try:
                result = engine.perform(req.action, req.doc)
            except OrderError as e:
                raise HTTPException(409, str(e))
            except ValueError as e:
                raise HTTPException(422, str(e))
            except RecordingError as e:
                raise HTTPException(404, str(e))
            except LLMError as e:
                raise HTTPException(502, str(e))
            return {"result": result, "state": engine.state()}

    @app.post("/api/reset")
    def reset():
        with lock:
            engine.reset()
            return engine.state()

    app.mount("/static", StaticFiles(directory=STATIC), name="static")
    return app


def main():
    import uvicorn
    settings = load_settings()
    if settings.mode == "live" and not os.environ.get("ANTHROPIC_API_KEY"):
        sys.exit("ANTHROPIC_API_KEY is not set. Set it, or start with ./run.sh --replay to serve the recording.")
    try:
        app = create_app(settings)
    except RecordingError as e:
        sys.exit(str(e))
    print(f"Prompt injection demo ({settings.mode}) on http://{HOST}:{settings.port}")
    uvicorn.run(app, host=HOST, port=settings.port, log_level="warning")


if __name__ == "__main__":
    main()
