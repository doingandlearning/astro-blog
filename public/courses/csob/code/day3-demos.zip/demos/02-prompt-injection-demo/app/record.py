"""Run the demo steps live once and save the real outputs for replay.

Nothing is edited. If the run is not representative (the attack did not fire, say),
nothing is saved: re-run until it is, or use --force to save it anyway."""
import argparse
import json
import sys
from datetime import datetime, timezone

from .config import load_settings
from .documents import load_documents
from .engine import EXPECTED, run_action
from .llm import AnthropicLLM

STEPS = [("normal", "A"), ("attack", "B"), ("schema", "B"), ("schema", "C"),
         ("hardened", "B"), ("hardened", "C"), ("extract", None)]


def record(llm, settings, docs) -> dict:
    results = {}
    for action, doc in STEPS:
        r = run_action(llm, settings, docs, action, doc)
        results[r["key"]] = r
    return {"recorded_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "settings": llm.effective_settings(), "results": results}


def mismatches(recording) -> list:
    return [(k, want, recording["results"][k]["verdict"]["code"]) for k, want in EXPECTED.items()
            if recording["results"][k]["verdict"]["code"] != want]


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--force", action="store_true", help="save even if the run is not representative")
    args = ap.parse_args(argv)
    settings = load_settings()
    docs = load_documents()
    rec = record(AnthropicLLM(settings), settings, docs)
    for key, r in rec["results"].items():
        print(f"{key:12} {r['verdict']['label']}")
    bad = mismatches(rec)
    for key, want, got in bad:
        print(f"NOT REPRESENTATIVE: {key} expected '{want}', got '{got}'")
    if bad and not args.force:
        print("Not saved. Check ./rehearse.sh for the typical rates, then record again (or --force).")
        sys.exit(1)
    settings.recording_path.parent.mkdir(parents=True, exist_ok=True)
    settings.recording_path.write_text(json.dumps(rec, indent=2))
    print(f"Saved {settings.recording_path}")


if __name__ == "__main__":
    main()
