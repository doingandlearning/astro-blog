"""The agent: one system prompt, one stub tool, one short loop. Nothing else.

The tool returns the text of the document the trainer selected. The agent has no
network, file or shell access."""
import copy

from .prompts import READ_DOCUMENT_TOOL

MAX_TURNS = 4


def _text(content) -> str:
    return "".join(b["text"] for b in content if b["type"] == "text")


def run_agent(llm, *, system, task, document_text=None, delivery="tool") -> dict:
    """Returns {"output": str, "calls": [request payloads exactly as sent]}."""
    if document_text is None:
        messages, tools = [{"role": "user", "content": task}], []
    elif delivery == "inline":
        # Document pasted straight after the task, no delimiters.
        messages, tools = [{"role": "user", "content": f"{task}\n\n{document_text}"}], []
    else:
        messages, tools = [{"role": "user", "content": task}], [READ_DOCUMENT_TOOL]

    calls, output = [], ""
    for turn in range(MAX_TURNS):
        calls.append({"system": system, "messages": copy.deepcopy(messages), "tools": copy.deepcopy(tools)})
        resp = llm.complete(system=system, messages=messages, tools=tools, force_tool=bool(tools) and turn == 0)
        messages.append({"role": "assistant", "content": resp["content"]})
        output = _text(resp["content"])
        uses = [b for b in resp["content"] if b["type"] == "tool_use"]
        if not uses:
            break
        results = [{"type": "tool_result", "tool_use_id": u["id"], "content": document_text} for u in uses]
        messages.append({"role": "user", "content": results})
    return {"output": output, "calls": calls}
