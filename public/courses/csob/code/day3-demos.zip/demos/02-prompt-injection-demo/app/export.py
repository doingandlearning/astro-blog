"""Export the recording as a self-contained HTML page and a plain 90-second capture script."""
import html
import json

from .config import ROOT, load_settings
from .engine import load_recording

OUT = ROOT / "export"

# (result key, heading, what to say)
SEQUENCE = [
    ("normal:A", "1. Normal run", "Clean document. Ask the room what they expect, then run it. Three plain bullets."),
    ("attack:B", "2. Attack run", "Same agent, same task, a document with one paragraph added. Watch the last line of the output."),
    (None, "3. Pause", "Stop talking. Ask: what just happened, in your own words? Then reveal the hidden paragraph."),
    ("schema:B", "4a. Mitigation: output schema", "Same attack, with the output checked against a narrow schema. The output is rejected."),
    ("hardened:B", "4b. Mitigation: hardened prompt", "Same attack, with a prompt that says to treat documents as data. It helps."),
    ("hardened:C", "4b. ...but not completely", "A rephrased injection. The hardened prompt does not stop it. The schema still would (schema:C)."),
    ("extract:-", "5. Extraction", "Ask the agent to repeat its instructions. What in here should never have been written into a prompt?"),
]
TIMES = ["0:00", "0:12", "0:27", "0:40", "0:52", "1:05", "1:15"]

CSS = """body{font:18px/1.5 system-ui,sans-serif;max-width:60rem;margin:2rem auto;padding:0 1rem;background:#fff;color:#111}
@media(prefers-color-scheme:dark){body{background:#111;color:#eee}pre{background:#1d1d1d!important}}
h1{font-size:1.6rem}h2{margin-top:2rem;font-size:1.25rem}pre{background:#f3f3f3;padding:.8rem;white-space:pre-wrap;border-radius:6px;font-size:.9rem}
.v{font-weight:700;padding:.4rem .8rem;border-radius:6px;display:inline-block}.good{background:#0a6b2b;color:#fff}.bad{background:#a3121a;color:#fff}
.banner{border:3px solid #b36b00;padding:.5rem 1rem;font-weight:700}small{opacity:.8}"""


def _pre(text):
    return f"<pre>{html.escape(text or '')}</pre>"


def build_html(rec) -> str:
    s = rec["settings"]
    parts = ["<h1>Prompt injection demo: recorded run</h1>",
             f'<p class="banner">RECORDED RUN. Saved {html.escape(rec["recorded_at"])} with {html.escape(s["model"])}. Not a live model call.</p>',
             f"<p><small>Model {html.escape(s['model'])}, temperature {html.escape(str(s['temperature']))}, "
             f"max tokens {s['max_tokens']}, delivery {html.escape(s['delivery'])}.</small></p>"]
    for key, heading, say in SEQUENCE:
        parts.append(f"<h2>{html.escape(heading)}</h2><p>{html.escape(say)}</p>")
        if key is None:
            continue
        r = rec["results"][key]
        v = r["verdict"]
        parts.append(f'<p><span class="v {html.escape(v["tone"])}">{html.escape(v["label"])}</span> '
                     f'<small>{html.escape(v["detail"])}</small></p>')
        parts.append("<p>Raw model output:</p>" + _pre(r["output"]))
        if r["schema"] and not r["schema"]["ok"]:
            parts.append("<p>Delivered to the user: nothing (rejected).</p>")
        parts.append(f"<details><summary>System prompt and what the model received</summary>{_pre(r['system_prompt'])}"
                     f"{_pre(json.dumps(r['calls'], indent=2))}</details>")
    return ("<!doctype html><html lang='en'><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"
            f"<title>Prompt injection demo (recorded)</title><style>{CSS}</style><body>{''.join(parts)}</body></html>")


def build_script(rec) -> str:
    s = rec["settings"]
    lines = ["PROMPT INJECTION: 90-SECOND CAPTURE SCRIPT",
             f"Recorded run saved {rec['recorded_at']} with {s['model']}. Say so on camera: this is a recording, not a live call.", ""]
    for t, (key, heading, say) in zip(TIMES, SEQUENCE):
        lines.append(f"[{t}] {heading}")
        lines.append(f"  Say: {say}")
        if key:
            r = rec["results"][key]
            lines.append(f"  Screen verdict: {r['verdict']['label']}")
            first = (r["output"] or "").strip().splitlines()
            lines.append("  Output (first line): " + (first[0][:140] if first else "(empty)"))
        lines.append("")
    lines.append("[1:30] Move on to the system prompts slide.")
    return "\n".join(lines)


def main():
    settings = load_settings()
    rec = load_recording(settings.recording_path)
    OUT.mkdir(exist_ok=True)
    (OUT / "prompt-injection-demo.html").write_text(build_html(rec))
    (OUT / "capture-script.txt").write_text(build_script(rec))
    print(f"Wrote {OUT / 'prompt-injection-demo.html'} and {OUT / 'capture-script.txt'}")


if __name__ == "__main__":
    main()
