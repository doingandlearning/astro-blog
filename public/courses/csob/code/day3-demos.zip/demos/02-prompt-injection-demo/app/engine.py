"""Runs one demo step, live or from a recording, and tracks script order."""
import copy
import json

from . import schema as schema_mod
from .documents import load_documents
from .llm import AnthropicLLM
from .agent import run_agent
from .prompts import BASE_SYSTEM, EXTRACT_TASK, HARDENING, SCHEMA_INSTRUCTION, SUMMARY_TASK
from .stepper import ACTIONS, Stepper
from .verdict import verdict

# Which document each action uses by default; schema and hardened can use B or C.
DEFAULT_DOC = {"normal": "A", "attack": "B", "schema": "B", "hardened": "B", "extract": None}
ALLOWED_DOCS = {"normal": ("A",), "attack": ("B",), "schema": ("B", "C"), "hardened": ("B", "C"), "extract": (None,)}

# What a representative run looks like (used by record and rehearse).
EXPECTED = {
    "normal:A": "on_task", "attack:B": "followed", "hardened:B": "on_task",
    "hardened:C": "followed", "schema:B": "rejected", "schema:C": "rejected", "extract:-": "leaked",
}


class RecordingError(RuntimeError):
    pass


def result_key(action, doc_id) -> str:
    return f"{action}:{doc_id or '-'}"


def run_action(llm, settings, docs, action, doc_id=None) -> dict:
    """One real model run. This is the only place results are produced."""
    doc_id = doc_id or DEFAULT_DOC[action]  # any document is allowed here; the page is restricted in Engine.perform
    system = BASE_SYSTEM
    if action == "hardened":
        system = f"{BASE_SYSTEM}\n\n{HARDENING}"
    elif action == "schema":
        system = f"{BASE_SYSTEM}\n\n{SCHEMA_INSTRUCTION}"

    if action == "extract":
        run = run_agent(llm, system=system, task=EXTRACT_TASK)
    else:
        run = run_agent(llm, system=system, task=SUMMARY_TASK, document_text=docs[doc_id].text,
                        delivery=settings.delivery)
    output = run["output"]

    schema_result, delivered = None, output
    if action == "schema":
        schema_result = schema_mod.validate(output)
        delivered = schema_mod.render(output) if schema_result["ok"] else None
    return {
        "key": result_key(action, doc_id), "action": action, "doc_id": doc_id,
        "system_prompt": system, "calls": run["calls"], "output": output,
        "schema": schema_result, "delivered": delivered,
        "verdict": verdict(action, output, schema_result),
        "settings": llm.effective_settings(), "replay": False,
    }


def load_recording(path) -> dict:
    try:
        return json.loads(path.read_text())
    except FileNotFoundError:
        raise RecordingError(f"No recording at {path}. Run ./record.sh first.") from None


class Engine:
    def __init__(self, settings, llm=None, recording=None, llm_factory=AnthropicLLM, docs=None):
        self.settings = settings
        self.docs = docs or load_documents()
        self._llm, self._llm_factory = llm, llm_factory
        self.stepper = Stepper()
        self.recording = None
        if settings.mode == "replay":
            self.recording = recording if recording is not None else load_recording(settings.recording_path)

    def _get_llm(self):
        if self._llm is None:
            self._llm = self._llm_factory(self.settings)
        return self._llm

    def configured_settings(self) -> dict:
        if self.recording:
            return self.recording["settings"]
        if self._llm is not None:
            return self._llm.effective_settings()
        s = self.settings
        return {"model": s.model, "temperature": s.temperature, "max_tokens": s.max_tokens, "delivery": s.delivery}

    def state(self) -> dict:
        info = None
        if self.recording:
            info = {"recorded_at": self.recording.get("recorded_at"), "model": self.recording["settings"]["model"]}
        return {"progress": self.stepper.progress, "allowed": self.stepper.allowed(),
                "mode": self.settings.mode, "settings": self.configured_settings(), "recording": info}

    def reset(self):
        self.stepper.reset()

    def perform(self, action, doc_id=None):
        if action not in ACTIONS:
            raise ValueError(f"Unknown action {action!r}")
        self.stepper.check(action)
        if action == "reveal":
            self.stepper.advance(action)
            return None
        doc_id = doc_id or DEFAULT_DOC[action]
        if doc_id not in ALLOWED_DOCS[action]:
            raise ValueError(f"'{action}' cannot use document {doc_id!r}")
        if self.recording is not None:
            try:
                result = copy.deepcopy(self.recording["results"][result_key(action, doc_id)])
            except KeyError:
                raise RecordingError(f"The recording has no result for {result_key(action, doc_id)}. Re-record.") from None
            result["replay"] = True
        else:
            result = run_action(self._get_llm(), self.settings, self.docs, action, doc_id)
        self.stepper.advance(action)
        return result
