"""Output schema enforcement. This is the control: it does not try to understand the
model or the document, it only checks the output's shape and rejects anything else."""
import json
import re

MAX_SUMMARY = 240
MAX_BULLET = 140
BULLET_COUNT = 3

_SCHEME = re.compile(r"[a-z][a-z0-9+.-]*://", re.I)
_DOMAIN = re.compile(r"\b[a-z0-9][a-z0-9-]*(?:\.[a-z0-9-]+)*\.[a-z]{2,}\b", re.I)


def _has_link(s: str) -> bool:
    return bool(_SCHEME.search(s) or _DOMAIN.search(s) or "www." in s.lower())


def validate(raw: str) -> dict:
    """Return {"ok": bool, "reasons": [...]} for the model's raw output."""
    reasons = []
    try:
        data = json.loads(raw)
    except (ValueError, TypeError):
        return {"ok": False, "reasons": ["Not a bare JSON object: there is extra text around it, or it is not JSON at all"]}
    if not isinstance(data, dict):
        return {"ok": False, "reasons": ["Top level is not a JSON object"]}

    extra = sorted(set(data) - {"summary", "bullets"})
    if extra:
        reasons.append(f"Unexpected field(s): {', '.join(extra)}")
    summary, bullets = data.get("summary"), data.get("bullets")

    if not isinstance(summary, str) or not summary.strip():
        reasons.append("'summary' is missing or not text")
    elif len(summary) > MAX_SUMMARY:
        reasons.append(f"'summary' is {len(summary)} characters; the limit is {MAX_SUMMARY}")

    if not isinstance(bullets, list) or len(bullets) != BULLET_COUNT:
        reasons.append(f"'bullets' must be a list of exactly {BULLET_COUNT} items")
        bullets = bullets if isinstance(bullets, list) else []
    for n, b in enumerate(bullets, 1):
        if not isinstance(b, str) or not b.strip():
            reasons.append(f"Bullet {n} is empty or not text")
        elif len(b) > MAX_BULLET:
            reasons.append(f"Bullet {n} is {len(b)} characters; the limit is {MAX_BULLET}")

    strings = ([summary] if isinstance(summary, str) else []) + [b for b in bullets if isinstance(b, str)]
    if any(_has_link(s) for s in strings):
        reasons.append("Contains a link or web address")
    if any("\n" in s for s in strings):
        reasons.append("Contains a line break inside a field")
    return {"ok": not reasons, "reasons": reasons}


def render(raw: str) -> str:
    """Plain text the user would be shown for an output that passed validation."""
    data = json.loads(raw)
    return data["summary"] + "\n" + "\n".join(f"- {b}" for b in data["bullets"])
