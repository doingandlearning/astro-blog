"use strict";
const $ = (s) => document.querySelector(s);

let docs = {};
let state = null;
let last = null; // last run result
let attackDoc = "B";
let busy = false;
let errorText = "";
let paused = false; // true from "Reveal hidden text" until the next run

async function api(path, opts) {
  const r = await fetch(path, opts);
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.detail || r.statusText);
  return data;
}

// Render text into an element, wrapping the given [start, end) ranges in <mark>. Text only, never HTML.
function renderMarked(el, text, ranges) {
  el.replaceChildren();
  let pos = 0;
  for (const [s, e] of ranges) {
    if (s > pos) el.append(text.slice(pos, s));
    const m = document.createElement("mark");
    m.textContent = text.slice(s, e);
    el.append(m);
    pos = e;
  }
  el.append(text.slice(pos));
}

function findRanges(text, needles) {
  const out = [];
  for (const n of needles) {
    const i = text.indexOf(n);
    if (i >= 0) out.push([i, i + n.length]);
  }
  return out.sort((a, b) => a[0] - b[0]);
}

function formatCalls(calls) {
  const lines = [];
  calls.forEach((c, i) => {
    lines.push(`=== Request ${i + 1} of ${calls.length} ===`, "[system]", c.system, "");
    if (c.tools.length) lines.push(`[tools] ${c.tools.map((t) => t.name).join(", ")}`, "");
    for (const m of c.messages) {
      if (typeof m.content === "string") {
        lines.push(`[${m.role}]`, m.content, "");
        continue;
      }
      for (const b of m.content) {
        if (b.type === "text") lines.push(`[${m.role}]`, b.text, "");
        else if (b.type === "tool_use") lines.push(`[${m.role} calls tool] ${b.name}(${JSON.stringify(b.input)})`, "");
        else if (b.type === "tool_result") lines.push("[tool result: the document text, exactly as returned]", b.content, "");
      }
    }
  });
  return lines.join("\n");
}

function setVerdict(tone, label, detail) {
  const v = $("#verdict");
  v.className = `verdict ${tone}`;
  $("#verdict-label").textContent = label;
  $("#verdict-detail").textContent = detail || "";
}

function render() {
  const progress = state.progress;
  const revealed = progress >= 3;

  // Stepper: step n is done when progress >= n (step 4 counts once a mitigation has run), active when it is next.
  const stepOf = { 0: 1, 1: 2, 2: 3, 3: 4, 4: 5, 5: 5 }[progress];
  document.querySelectorAll("#stepper li").forEach((li) => {
    const n = Number(li.dataset.step);
    li.classList.toggle("done", progress >= n);
    li.classList.toggle("active", n === stepOf && progress < 5);
  });
  document.querySelectorAll("#stepper button[data-action]").forEach((b) => {
    b.disabled = busy || !state.allowed.includes(b.dataset.action);
  });
  $("#doc-B").classList.toggle("on", attackDoc === "B");
  $("#doc-C").classList.toggle("on", attackDoc === "C");

  // Banner and footer
  const banner = $("#banner");
  if (state.mode === "replay") {
    const r = state.recording || {};
    banner.hidden = false;
    banner.textContent = `RECORDED RUN: outputs saved ${r.recorded_at || ""} with ${r.model || "unknown model"}. Not a live model call.`;
  } else {
    banner.hidden = true;
  }
  const s = (last && !last.replay ? last.settings : state.settings) || {};
  const temp = s.temperature === null || s.temperature === undefined ? "provider default (model rejected temperature)" : s.temperature;
  $("#footer").textContent = `mode ${state.mode} | model ${s.model} | temperature ${temp} | max_tokens ${s.max_tokens} | document delivery ${s.delivery}`;

  // Panels
  const sys = $("#p-system");
  const sysText = last ? last.system_prompt : state.base_system;
  renderMarked(sys, sysText, last && last.action === "extract" ? findRanges(sysText, state.fake_details) : []);

  const docId = last && last.doc_id ? last.doc_id : last ? null : "A";
  const docEl = $("#p-doc");
  const note = $("#doc-note");
  if (docId && docs[docId]) {
    const d = docs[docId];
    $("#doc-title").textContent = `Document ${docId}: ${d.title}`;
    renderMarked(docEl, d.text, revealed ? d.spans : []);
    note.hidden = !(revealed && d.spans.length);
    note.textContent = d.note;
  } else {
    $("#doc-title").textContent = "Document";
    docEl.textContent = "No document in this step. The agent is only asked a question.";
    note.hidden = true;
  }

  $("#p-output").textContent = last ? last.output : "";
  const dp = $("#delivered-panel");
  dp.hidden = !(last && last.action === "schema");
  $("#p-delivered").textContent = last && last.delivered !== null && last.delivered !== undefined
    ? last.delivered : "Nothing. The output was rejected, so the user sees an error, not this.";

  // Verdict
  if (busy) setVerdict("neutral", "Running…", "Calling the model. This can take several seconds.");
  else if (errorText) setVerdict("bad", "Could not run this step", errorText);
  else if (paused) setVerdict("neutral", "Pause: what just happened, in your own words?", "The injected text is now highlighted in the document panel.");
  else if (last) {
    const v = last.verdict;
    setVerdict(v.tone, `${v.tone === "good" ? "✔" : "✖"} ${v.label}`, v.detail);
  } else if (progress === 0) setVerdict("neutral", 'Press "Run normal" to begin', "");

  // Received prompt drawer
  const showReceived = $("#show-prompt").checked && last;
  $("#received").hidden = !showReceived;
  if (showReceived) $("#p-received").textContent = formatCalls(last.calls);
}

async function run(action) {
  if (busy) return;
  busy = true;
  errorText = "";
  render();
  try {
    const body = { action };
    if (action === "schema" || action === "hardened") body.doc = attackDoc;
    const res = await api("/api/run", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    state = res.state;
    paused = action === "reveal";
    if (res.result) last = res.result;
  } catch (e) {
    errorText = e.message;
    try { state = await api("/api/state"); } catch (_) { /* keep the old state */ }
  } finally {
    busy = false;
    render();
  }
}

async function reset() {
  state = await api("/api/reset", { method: "POST" });
  last = null;
  errorText = "";
  paused = false;
  attackDoc = "B";
  render();
}

function setTheme(t) {
  document.documentElement.dataset.theme = t;
  try { localStorage.setItem("theme", t); } catch (_) { /* storage may be blocked */ }
}

async function init() {
  try {
    const t = localStorage.getItem("theme");
    if (t) document.documentElement.dataset.theme = t;
  } catch (_) { /* ignore */ }
  document.querySelectorAll("#stepper button[data-action]").forEach((b) => b.addEventListener("click", () => run(b.dataset.action)));
  $("#doc-B").addEventListener("click", () => { attackDoc = "B"; render(); });
  $("#doc-C").addEventListener("click", () => { attackDoc = "C"; render(); });
  $("#reset").addEventListener("click", reset);
  $("#show-prompt").addEventListener("change", render);
  $("#theme").addEventListener("click", () => {
    const dark = getComputedStyle(document.documentElement).getPropertyValue("--bg").trim() === "#0e1116";
    setTheme(dark ? "light" : "dark");
  });
  docs = await api("/api/documents");
  state = await api("/api/state");
  render();
}

init().catch((e) => { document.body.textContent = `Failed to load: ${e.message}`; });
