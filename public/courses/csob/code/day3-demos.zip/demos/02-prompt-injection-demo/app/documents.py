"""Load the demo documents. Injected spans are marked [[INJECT]]...[[/INJECT]] in the
source files; the markers are removed before the text reaches the model."""
import json
from dataclasses import dataclass
from pathlib import Path

from .config import ROOT

DOC_DIR = ROOT / "documents"
OPEN, CLOSE = "[[INJECT]]", "[[/INJECT]]"


@dataclass(frozen=True)
class Document:
    id: str
    title: str
    text: str
    spans: tuple  # ((start, end), ...) character offsets of injected text in `text`
    note: str


def parse_marked(raw: str):
    parts, spans, pos, length = [], [], 0, 0
    while True:
        i = raw.find(OPEN, pos)
        if i < 0:
            parts.append(raw[pos:])
            break
        j = raw.find(CLOSE, i)
        if j < 0:
            raise ValueError("unterminated [[INJECT]] marker")
        parts.append(raw[pos:i])
        length += i - pos
        inner = raw[i + len(OPEN):j]
        spans.append((length, length + len(inner)))
        parts.append(inner)
        length += len(inner)
        pos = j + len(CLOSE)
    return "".join(parts), tuple(spans)


def load_documents(directory: Path = DOC_DIR) -> dict:
    manifest = json.loads((directory / "manifest.json").read_text())
    docs = {}
    for entry in manifest:
        text, spans = parse_marked((directory / entry["file"]).read_text())
        docs[entry["id"]] = Document(entry["id"], entry["title"], text, spans, entry["note"])
    return docs
