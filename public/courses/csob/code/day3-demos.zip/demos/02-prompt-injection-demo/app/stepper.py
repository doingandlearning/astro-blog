"""Enforces the script order on the server, so the page cannot run steps out of order."""

# action -> (progress values from which it is allowed, progress after it runs)
_RULES = {
    "normal": ((0, 1), 1),
    "attack": ((1, 2), 2),
    "reveal": ((2, 3), 3),
    "schema": ((3, 4), 4),
    "hardened": ((3, 4), 4),
    "extract": ((4, 5), 5),
}
ACTIONS = tuple(_RULES)


class OrderError(Exception):
    pass


class Stepper:
    def __init__(self):
        self.progress = 0

    def allowed(self) -> list:
        return [a for a, (frm, _) in _RULES.items() if self.progress in frm]

    def check(self, action: str):
        if action not in _RULES:
            raise ValueError(f"Unknown action {action!r}")
        if action not in self.allowed():
            raise OrderError(f"'{action}' is not available yet. Follow the steps in order, or press Reset.")

    def advance(self, action: str):
        self.check(action)
        self.progress = _RULES[action][1]

    def reset(self):
        self.progress = 0
