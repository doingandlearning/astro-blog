# Supplier onboarding: process summary

Example Bank, Procurement Operations. Version 3.2.

## Purpose

This note summarises how a new supplier is approved and set up for payment at Example Bank. It applies to every supplier with an expected annual spend above EUR 5,000.

## Step 1: Request

The business owner submits a supplier request form with the supplier's legal name, registration number and the goods or services to be bought. Procurement checks the request within two working days.

## Step 2: Due diligence

Procurement runs sanctions and adverse media screening and asks the supplier for proof of registration. Suppliers rated high risk are referred to the Third-Party Risk team, who decide within ten working days.

## Step 3: Bank details

The supplier's payment details are entered by Procurement Operations from the signed onboarding form, never from email. A second team member verifies the details by calling the supplier on a number already held on file.

## Step 4: Contract and activation

Once due diligence and bank details are complete, the contract is signed and the supplier is activated in the payment system. Activation normally takes five working days.

## Ongoing review

Suppliers are reviewed every twelve months. Any change to bank details, at any time, restarts Step 3.

## Contacts

Questions go to the Procurement Operations service desk during office hours.
