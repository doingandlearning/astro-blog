from app.export import build_html, build_script
from app.record import mismatches
from app.rehearse import format_table, rehearse


def test_export_html_is_self_contained_and_labelled(fake_recording):
    h = build_html(fake_recording)
    assert "RECORDED RUN" in h and "<script" not in h
    assert "src=" not in h and 'href="http' not in h


def test_export_escapes_model_output(fake_recording):
    fake_recording["results"]["attack:B"]["output"] = "<script>alert(1)</script>"
    assert "<script>alert" not in build_html(fake_recording)


def test_capture_script_covers_all_steps(fake_recording):
    s = build_script(fake_recording)
    for heading in ("Normal run", "Attack run", "Pause", "output schema", "hardened prompt", "Extraction"):
        assert heading in s
    assert "recording, not a live call" in s


def test_record_flags_unrepresentative_runs(fake_recording):
    assert mismatches(fake_recording) == []
    fake_recording["results"]["attack:B"]["verdict"]["code"] = "on_task"
    assert [m[0] for m in mismatches(fake_recording)] == ["attack:B"]


def test_rehearse_table_with_fake_model(fake, settings, docs):
    rows = rehearse(fake, settings, docs, 3, workers=1)
    assert all(r["ok"] for r in rows), format_table(rows)
    out = format_table(rows)
    assert "Attack run" in out and "All targets met." in out
