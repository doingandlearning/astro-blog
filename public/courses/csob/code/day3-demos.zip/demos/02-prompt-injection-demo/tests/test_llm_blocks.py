"""Thinking blocks must survive the round trip. A model that thinks before a tool call returns a
thinking block; the next request has to send it back with its text and signature intact."""
import types

from app.llm import _block


def test_thinking_block_keeps_text_and_signature():
    b = types.SimpleNamespace(type="thinking", thinking="considering the document", signature="sig123")
    assert _block(b) == {"type": "thinking", "thinking": "considering the document", "signature": "sig123"}


def test_redacted_thinking_block_keeps_data():
    b = types.SimpleNamespace(type="redacted_thinking", data="opaque")
    assert _block(b) == {"type": "redacted_thinking", "data": "opaque"}


def test_text_and_tool_use_blocks_unchanged():
    assert _block(types.SimpleNamespace(type="text", text="hi")) == {"type": "text", "text": "hi"}
    t = types.SimpleNamespace(type="tool_use", id="t1", name="n", input={"a": 1})
    assert _block(t) == {"type": "tool_use", "id": "t1", "name": "n", "input": {"a": 1}}
