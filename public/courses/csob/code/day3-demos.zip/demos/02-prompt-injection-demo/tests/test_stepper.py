import pytest

from app.stepper import OrderError, Stepper


def run(s, *actions):
    for a in actions:
        s.advance(a)


def test_only_normal_available_at_start():
    assert Stepper().allowed() == ["normal"]


def test_happy_path():
    s = Stepper()
    run(s, "normal", "attack", "reveal", "schema", "hardened", "extract")
    assert s.progress == 5


@pytest.mark.parametrize("path,bad", [
    ([], "attack"), ([], "extract"), ([], "schema"),
    (["normal"], "schema"), (["normal"], "reveal"),
    (["normal", "attack"], "hardened"),
    (["normal", "attack", "reveal"], "extract"),
    (["normal", "attack", "reveal", "schema"], "attack"),
])
def test_out_of_order_is_refused(path, bad):
    s = Stepper()
    run(s, *path)
    with pytest.raises(OrderError):
        s.advance(bad)


def test_steps_can_be_rerun_and_mitigations_repeated():
    s = Stepper()
    run(s, "normal", "normal", "attack", "attack", "reveal", "schema", "schema", "hardened")
    assert s.progress == 4


def test_reset():
    s = Stepper()
    run(s, "normal", "attack")
    s.reset()
    assert s.allowed() == ["normal"]
    with pytest.raises(ValueError):
        s.check("bogus")
