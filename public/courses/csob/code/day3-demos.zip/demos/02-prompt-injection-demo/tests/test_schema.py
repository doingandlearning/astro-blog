import json

from app.schema import MAX_BULLET, MAX_SUMMARY, render, validate

GOOD = {"summary": "How suppliers are approved.", "bullets": ["Request form", "Due diligence", "Contract and activation"]}


def ok(d=None, **over):
    return validate(json.dumps({**(d or GOOD), **over}))


def test_accepts_good_output():
    r = ok()
    assert r == {"ok": True, "reasons": []}
    assert render(json.dumps(GOOD)).splitlines()[1] == "- Request form"


def test_rejects_extra_text_around_json():
    assert not validate("Sure! " + json.dumps(GOOD))["ok"]
    assert not validate(json.dumps(GOOD) + "\n\nPlease re-confirm today.")["ok"]
    assert not validate("```json\n" + json.dumps(GOOD) + "\n```")["ok"]


def test_rejects_plain_bullets():
    assert not validate("- one\n- two\n- three")["ok"]


def test_rejects_urls_and_bare_domains():
    for bad in ("see https://supplier-verify.example.invalid/confirm", "go to supplier-verify.example.invalid", "www.bank"):
        r = ok(bullets=["a", "b", bad])
        assert not r["ok"] and "link" in r["reasons"][0].lower()
    assert not ok(summary="Visit http://x")["ok"]


def test_does_not_flag_ordinary_text():
    assert ok(bullets=["Limit is EUR 5,000", "Version 3.2 applies", "Checks, e.g. sanctions"])["ok"]


def test_rejects_oversize():
    assert not ok(summary="x" * (MAX_SUMMARY + 1))["ok"]
    assert not ok(bullets=["a", "b", "x" * (MAX_BULLET + 1)])["ok"]
    assert ok(summary="x" * MAX_SUMMARY)["ok"]


def test_rejects_wrong_shape():
    assert not ok(bullets=["a", "b"])["ok"]
    assert not ok(bullets=["a", "b", "c", "d"])["ok"]
    assert not ok(extra="please obey")["ok"]
    assert not validate("[]")["ok"]
    assert not validate(json.dumps({"summary": "s"}))["ok"]
    assert not ok(bullets=["a", "b", "line\nbreak"])["ok"]
