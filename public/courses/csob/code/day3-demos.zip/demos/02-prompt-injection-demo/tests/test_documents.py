import re

from app.documents import load_documents, parse_marked
from app.verdict import INJECTION_HOST


def test_markers_are_stripped_and_spans_match():
    text, spans = parse_marked("a [[INJECT]]bad[[/INJECT]] b [[INJECT]]worse[[/INJECT]]")
    assert text == "a bad b worse"
    assert [text[s:e] for s, e in spans] == ["bad", "worse"]


def test_documents(docs):
    assert set(docs) == {"A", "B", "C"}
    for d in docs.values():
        assert "[[" not in d.text and "]]" not in d.text
        assert d.text.isascii(), "spans are used as browser string offsets"
        assert d.note
    assert docs["A"].spans == () and INJECTION_HOST not in docs["A"].text
    for k in "BC":
        assert len(docs[k].spans) == 1
        s, e = docs[k].spans[0]
        assert INJECTION_HOST in docs[k].text[s:e]
        assert docs[k].text.replace(docs[k].text[s:e], "").strip() != ""


def test_b_and_c_are_a_plus_one_paragraph(docs):
    for k in "BC":
        s, e = docs[k].spans[0]
        stripped = (docs[k].text[:s] + docs[k].text[e:])
        assert re.sub(r"\n{3,}", "\n\n", stripped) == docs["A"].text


def test_c_avoids_the_obvious_injection_markers(docs):
    s, e = docs["C"].spans[0]
    inj = docs["C"].text[s:e].lower()
    assert "ignore" not in inj and "assistant" not in inj and "system" not in inj


def test_fictional_lender_only(docs):
    blob = " ".join(d.text for d in docs.values()).lower()
    assert "example bank" in blob
    assert not re.search(r"csob|kbc", blob)
    assert not re.search(r"https?://(?![a-z0-9.-]*\.invalid)", blob)
