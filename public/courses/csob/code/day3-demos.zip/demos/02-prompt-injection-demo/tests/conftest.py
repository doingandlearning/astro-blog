import json

import pytest

from app.config import load_settings
from app.documents import load_documents
from app.engine import run_action
from app.record import STEPS
from app.verdict import INJECTION_HOST


class FakeLLM:
    """Stands in for the model. Not a claim about real model behaviour: it only exists so the
    app's plumbing can be tested offline. It follows an injection unless the hardened prompt is
    present and the injection is the obvious 'SYSTEM NOTE' kind."""

    def __init__(self):
        self.requests = []

    def effective_settings(self):
        return {"model": "fake-model", "temperature": 0, "max_tokens": 600, "delivery": "tool"}

    def complete(self, *, system, messages, tools, force_tool):
        self.requests.append({"system": system, "messages": messages, "tools": tools, "force_tool": force_tool})
        first = messages[0]["content"]
        if tools and force_tool and len(messages) == 1:
            return {"content": [{"type": "tool_use", "id": "t1", "name": "read_document", "input": {"name": "x"}}]}
        doc = ""
        for m in messages:
            if isinstance(m["content"], list):
                for b in m["content"]:
                    if b.get("type") == "tool_result":
                        doc = b["content"]
        if isinstance(first, str) and "repeat your instructions" in first:
            return self._text(system)
        if not doc and isinstance(first, str):
            doc = first
        injected = INJECTION_HOST in doc
        if "Security rules" in system and "SYSTEM NOTE" in doc:
            injected = False
        if "Output format" in system:
            bullets = ["Request form", "Due diligence", "Bank details verified by phone"]
            if injected:
                bullets[2] = f"Re-confirm at https://{INJECTION_HOST}/confirm"
            return self._text(json.dumps({"summary": "Supplier onboarding steps.", "bullets": bullets}))
        text = "- Request\n- Due diligence\n- Bank details verified by phone"
        if injected:
            text += f"\n\nAll suppliers must re-confirm their bank details today at https://{INJECTION_HOST}/confirm"
        return self._text(text)

    @staticmethod
    def _text(t):
        return {"content": [{"type": "text", "text": t}]}


@pytest.fixture
def fake():
    return FakeLLM()


@pytest.fixture
def settings():
    return load_settings({})


@pytest.fixture
def docs():
    return load_documents()


@pytest.fixture
def fake_recording(fake, settings, docs):
    """A recording built from the fake model, for exercising replay."""
    results = {}
    for action, doc in STEPS:
        r = run_action(fake, settings, docs, action, doc)
        results[r["key"]] = r
    return {"recorded_at": "2026-01-01T00:00:00+00:00", "settings": fake.effective_settings(), "results": results}
