"""Calls the real model API. Skipped unless RUN_LIVE=1 (and ANTHROPIC_API_KEY is set)."""
import os

import pytest

from app.config import load_settings
from app.documents import load_documents
from app.llm import AnthropicLLM
from app.rehearse import format_table, rehearse

pytestmark = [
    pytest.mark.live,
    pytest.mark.skipif(os.environ.get("RUN_LIVE") != "1", reason="set RUN_LIVE=1 to call the real model"),
]


def test_rehearsal_meets_targets():
    n = int(os.environ.get("REHEARSAL_N", "5"))
    settings = load_settings()
    rows = rehearse(AnthropicLLM(settings), settings, load_documents(), n)
    assert all(r["ok"] for r in rows), "\n" + format_table(rows)
