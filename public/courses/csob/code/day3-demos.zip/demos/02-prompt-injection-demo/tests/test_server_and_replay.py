import socket

import pytest
from fastapi.testclient import TestClient

from app import config
from app.config import load_settings
from app.engine import Engine, RecordingError
from app.server import create_app


def boom(*a, **k):
    raise AssertionError("network or model client was used")


def client(settings, **kw):
    return TestClient(create_app(settings, **kw))


def run(c, action, doc=None):
    return c.post("/api/run", json={"action": action, "doc": doc})


def full_script(c):
    for a, d in [("normal", None), ("attack", None), ("reveal", None), ("schema", "B"), ("schema", "C"),
                 ("hardened", "B"), ("hardened", "C"), ("extract", None)]:
        r = run(c, a, d)
        assert r.status_code == 200, (a, r.text)


def test_binds_to_loopback_ip_not_localhost():
    assert config.HOST == "127.0.0.1"


def test_live_flow_and_order_enforced(fake, settings):
    c = client(settings, llm=fake)
    assert run(c, "attack").status_code == 409
    assert run(c, "extract").status_code == 409
    full_script(c)
    r = c.post("/api/reset")
    assert r.json()["progress"] == 0 and r.json()["allowed"] == ["normal"]


def test_bad_requests(fake, settings):
    c = client(settings, llm=fake)
    assert run(c, "bogus").status_code == 422
    run(c, "normal"); run(c, "attack"); run(c, "reveal")
    assert run(c, "schema", "A").status_code == 422


def test_results_shape(fake, settings):
    c = client(settings, llm=fake)
    run(c, "normal")
    body = run(c, "attack").json()
    assert body["result"]["verdict"]["code"] == "followed" and body["result"]["replay"] is False
    assert body["state"]["progress"] == 2
    docs = c.get("/api/documents").json()
    assert docs["B"]["spans"] and not docs["A"]["spans"]
    assert c.get("/").status_code == 200


def test_replay_never_calls_network_or_model(monkeypatch, fake_recording):
    monkeypatch.setattr(socket.socket, "connect", boom)
    monkeypatch.setattr(socket, "create_connection", boom)
    s = load_settings({"DEMO_MODE": "replay"})
    c = client(s, recording=fake_recording, llm_factory=boom)
    full_script(c)
    assert run(c, "attack").status_code == 409  # order is enforced in replay too
    state = c.get("/api/state").json()
    assert state["mode"] == "replay" and state["recording"]["model"] == "fake-model"


def test_replay_results_are_marked_recorded(fake_recording):
    s = load_settings({"DEMO_MODE": "replay"})
    c = client(s, recording=fake_recording, llm_factory=boom)
    run(c, "normal")
    assert run(c, "attack").json()["result"]["replay"] is True


def test_replay_without_recording_fails_clearly(tmp_path):
    s = load_settings({"DEMO_MODE": "replay", "DEMO_RECORDING": str(tmp_path / "none.json")})
    with pytest.raises(RecordingError, match="record.sh"):
        Engine(s)


def test_replay_missing_entry(fake_recording):
    del fake_recording["results"]["attack:B"]
    s = load_settings({"DEMO_MODE": "replay"})
    c = client(s, recording=fake_recording, llm_factory=boom)
    run(c, "normal")
    assert run(c, "attack").status_code == 404


def test_settings_validation():
    with pytest.raises(ValueError):
        load_settings({"DEMO_MODE": "maybe"})
    with pytest.raises(ValueError):
        load_settings({"DEMO_DELIVERY": "carrier-pigeon"})
    assert load_settings({"DEMO_MODEL": "x"}).model == "x"
