# Demo guide: prompt injection live (about 25 minutes)

Page: http://127.0.0.1:8090. The room watches and reacts; nobody uses the app. Treat it as a controlled exercise, not a trick. Say which model it is (footer) and that this is a deliberately naive configuration.

## The one point

A model cannot reliably tell data from instructions. A buried line in a document was followed. A hardened prompt helps but a rephrase beats it. A narrow output schema does not stop the attempt but bounds what gets out. And the system prompt was readable, so it is configuration, not a secret.

## Before the room arrives

Follow the README rehearsal checklist. Press Reset, so the page shows "Press Run normal to begin".

## Script

**1. Normal run (about 3 min).** Ask: what will the agent do with this clean document? Take guesses. Click **Run normal**. Expect three plain bullets and the green "Stayed on task". Toggle "Show the prompt the model actually received" once so the sceptics see there is no trick.

**2. Attack run (about 3 min).** Same agent, same task, a different document. Click **Run attack**. Expect the bullets plus a closing sentence sending suppliers to a link. Red "Followed the hidden instruction". Do not explain yet.

**3. Pause (about 5 min).** Ask: what just happened, in your own words? Let several people answer. Then click **Reveal hidden text**: the injected paragraph is highlighted and the note says where it is. Point out it is plain text, nothing hidden from the model.

**4. Mitigation (about 8 min).** Doc B is selected.
- Click **Apply schema**. Expect "Output rejected by schema" with the reason (a link). The panel on the right shows what the user would have seen otherwise and that they see nothing instead.
- Click **Apply hardened prompt**. Expect "Stayed on task". Say it helps.
- Switch to **Doc C** (rephrased, no "ignore instructions"). Click **Apply hardened prompt**: expect "Followed the hidden instruction". Click **Apply schema** on C: still rejected.
- Say: the prompt tries to stop the attempt and can be beaten by wording. The schema does not care about wording; it bounds the damage. It would not catch an injection that fits inside a plain bullet, so it is one layer.

**5. Extraction (about 3 min).** Click **Ask for instructions**. The agent repeats its system prompt; the fake hostname and inbox are highlighted. Ask: what in here should never have been written into a prompt? Then go straight to the system-prompt slide, and run the debrief in `discussion.md`.

## If someone says "you rigged it"

Toggle "Show the prompt the model actually received". Every output is explainable from it. The documents are in `documents/`, the prompts in `app/prompts.py`, and the verdict logic is a string check on the output in `app/verdict.py`. Offer to run it again: it is a real model, not a script.

## If it misbehaves on the day

- The attack does not fire: say so, and treat it as a talking point (the model resisted; this is why "the model is well-trained" is not a control, since it can change with a version). Then switch to the recording (`./run.sh --replay`) and keep the banner on screen.
- API or network down: `./run.sh --replay`, or play the capture from `export/`, narrating from `capture-script.txt`.
- Do not claim a recording is live.
