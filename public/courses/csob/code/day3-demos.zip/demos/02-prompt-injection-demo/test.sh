#!/usr/bin/env bash
# Offline tests (model mocked). Add RUN_LIVE=1 to include the live rehearsal test.
set -euo pipefail
cd "$(dirname "$0")"
exec uv run pytest "$@"
