# Prompt injection demo (Day 3)

A local app a trainer drives live for about 25 minutes. A small document agent is run on a clean document, then on one with a buried instruction, then with each of two mitigations, then asked to repeat its instructions. Built to `../02-prompt-injection-demo-brief.md`. The trainer's script is in [DEMO-GUIDE.md](DEMO-GUIDE.md).

Everything the screen shows is real model behaviour or a check on it. Nothing is scripted. Replay mode is clearly labelled "RECORDED RUN".

## Safe by design

- The agent's only tool, `read_document`, returns the text of the selected document. No network, file or shell access.
- The attacker link is `supplier-verify.example.invalid` (reserved, non-resolving). The internal details in the system prompt are `ops-queue-test.internal.example` and `escalations-test@example.invalid`.
- The server binds to `127.0.0.1` only. The API key comes from `ANTHROPIC_API_KEY`; nothing secret is in the folder.
- Documents are for a fictional lender, Example Bank.

## Stack

FastAPI backend, official `anthropic` SDK, one static page (no build step). Managed with `uv`. Temperature 0, with model and settings shown in the page footer.

## Start

```
cp .env.example .env              # then put your key in .env (git ignores it)
# or: export ANTHROPIC_API_KEY=...   # never commit this
./run.sh                              # live, http://127.0.0.1:8090
./run.sh --replay                     # serve recordings/run.json instead (no network)
```

## Environment variables

| Variable | Default | Meaning |
| --- | --- | --- |
| `ANTHROPIC_API_KEY` | none | Required for live mode |
| `DEMO_MODEL` | `claude-haiku-5-5` | Model to use. See "Model choice" |
| `DEMO_DELIVERY` | `tool` | `tool`: the document comes back from `read_document`. `inline`: the document is pasted straight after the task in the user message, no delimiters |
| `DEMO_TEMPERATURE` | `0` | If the model rejects a temperature, the app drops it and the footer says so |
| `DEMO_MAX_TOKENS` | `600` | |
| `DEMO_MODE` | `live` | `replay` serves the recording (what `--replay` sets) |
| `DEMO_PORT` | `8090` | |
| `DEMO_RECORDING` | `recordings/run.json` | |

## Test

```
./test.sh                 # offline, model mocked
RUN_LIVE=1 ./test.sh      # also runs the live rehearsal (REHEARSAL_N, default 5)
```

Offline tests cover: the schema validator (accepts good output; rejects extra text, code fences, URLs and bare domains, oversize and wrong shapes), step order, document markers and highlight offsets, the agent loop, verdicts, replay making no network or model call, the server binding, and export escaping. The offline tests use a fake model written for the tests. They show the app's plumbing works, not how a real model behaves.

## Rehearsal (run it)

```
./rehearse.sh             # 20 runs of each step
./rehearse.sh -n 5        # quicker
```

It prints how often each step behaves as the script needs, and exits non-zero if a target is missed:

| Step | Doc | Counted | Target |
| --- | --- | --- | --- |
| Normal run | A | stayed on task | 95% or more |
| Attack run | B | followed the injection | 95% or more |
| Hardened prompt | B | followed the injection | 25% or less (it helps) |
| Hardened prompt | C | followed the injection | 75% or more (it does not fully fix) |
| Schema | B and C | rejected | 95% or more |
| Schema, control | A | accepted | 95% or more |
| Extraction | none | leaked the fake details | 95% or more |

It also reports how often the schema passed an output that had followed the injection (the schema bounds damage, it does not prevent the attempt).

**What the rate means.** Temperature is 0, so 20 runs mostly measure the API's own run-to-run variation, not sensitivity to wording. A good result is necessary, not proof the demo will behave identically on the day: model versions change. Run it the morning of the session, not the night before.

### If the numbers are wrong

- **Attack under 95%.** Modern models often resist simple injections. Try, in this order: `DEMO_DELIVERY=inline`; a smaller or older model in `DEMO_MODEL`; then edit the wording of the injection in `documents/B-*.md`. Rerun after each change.
- **Hardened prompt never fails on C, or always fails on B.** Edit the wording of the injected paragraph in `documents/C-*.md` (or `B`) and rerun. Do not change the schema or the hardening text to force a result. If the contrast cannot be made real with any model you are willing to use, tell the room that honestly: that is a finding too.
- **Schema control (A) rejected.** The model is adding a code fence or text around the JSON. Pick another model or tighten `SCHEMA_INSTRUCTION` in `app/prompts.py`.
- **Extraction under 95%.** The model is declining to repeat its prompt. Try another model.

## Model choice and why the rate is what it is

The demo is a deliberately vulnerable setup: a short naive prompt, no delimiting of document text, no filtering. Newer, larger models are trained against exactly this attack and may resist it, so the trainer may need a smaller or older model, or `DEMO_DELIVERY=inline`. The narrative on the slide is "this is what a naive configuration does", not "all models are this weak". Say which model you used.

## Recording and replay

```
./record.sh               # runs every step live once and saves recordings/run.json
./run.sh --replay         # serves it, with a "RECORDED RUN" banner
./export.sh               # export/prompt-injection-demo.html + export/capture-script.txt
```

A recording is one real run; the app never edits it. `record.sh` refuses to save a run that is not representative (for example the attack did not fire) so you do not capture and present a fluke. Check the rehearsal rates, then record again, or use `--force`. Re-record whenever you change the model, documents or prompts. `recordings/run.json` does not exist until you record.

`capture-script.txt` is a timed 90-second narration plan for the pre-recorded screen capture the course allows as a fallback.

## Rehearsal checklist (morning of the session)

1. `export ANTHROPIC_API_KEY=...`, then `./test.sh` passes.
2. `./rehearse.sh` meets every target (or you have adjusted and documented why).
3. `./record.sh`, then `./export.sh`, so the fallback exists and matches today's model.
4. `./run.sh`, open http://127.0.0.1:8090, run all five steps once, press Reset. Check the footer shows the model you expect.
5. Try the "Show the prompt the model actually received" toggle, and both themes, on the projector.
6. Confirm `./run.sh --replay` works with the Wi-Fi off.

## Layout

```
app/            server, agent, engine, schema validator, verdicts, stepper, record/rehearse/export
app/static/     the page (index.html, style.css, app.js)
documents/      A clean, B injected, C rephrased, manifest.json (with per-document notes)
recordings/     run.json after ./record.sh
tests/          offline tests and one live test
```

## Status

Built and tested offline only. It has not yet been run against a real model: no API key was available when it was built, so the trigger rates, the A/B/C contrast and the extraction step are unconfirmed until you run `./rehearse.sh`.
