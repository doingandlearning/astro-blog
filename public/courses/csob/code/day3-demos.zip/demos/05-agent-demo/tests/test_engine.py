import pytest

import engine
import tools


@pytest.mark.parametrize("arch", ["single", "pipeline", "orchestrator"])
def test_mock_runs_end_with_final_and_make_eight_tool_calls(arch):
    events = list(engine.run(arch, "mock"))
    assert events[-1]["kind"] == "final"
    assert sum(e["kind"] == "tool_call" for e in events) == 8


def test_orchestrator_delegates_in_order():
    events = list(engine.run("orchestrator", "mock"))
    targets = [e["text"].split()[1].rstrip(":") for e in events if e["kind"] == "delegate"]
    assert targets == ["investigator", "policy", "comms"]


def test_orchestrator_never_calls_data_tools_itself():
    events = list(engine.run("orchestrator", "mock"))
    assert not [e for e in events if e["kind"] == "tool_call" and e["agent"] == "orchestrator"]


def test_actions_are_proposed_never_executed():
    out = tools.propose_action("block_card", "x")
    assert out["status"] == "pending_human_approval"


def test_real_mode_without_key_reports_error(monkeypatch):
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    events = list(engine.run("single", "real"))
    assert [e["kind"] for e in events] == ["error"]


def test_flask_stream_serves_events():
    import app
    client = app.app.test_client()
    body = client.get("/run?arch=pipeline&mode=mock&pace=0").get_data(as_text=True)
    assert "event: done" in body and '"kind": "final"' in body
