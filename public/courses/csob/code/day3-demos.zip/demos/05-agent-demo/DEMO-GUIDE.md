# Demo guide: agent architectures live (about 15 minutes)

Page: http://127.0.0.1:8095. You drive; the room predicts on paper before each run. Say which mode you are in (Mock or Real) before you press Run, and keep that selection visible.

## The one point

Same task, three shapes. What changes is who decides the next step, how much context each agent sees, and where a control can sit. More agents is not automatically better: each hand-off is a place for facts to be lost and a place to put a control.

## Before the room arrives

1. Run `./run.sh`, open the page, and press Run once in Mock mode for each architecture. Check the trace reads well from the back of the room.
2. If you will use Real mode, run each architecture once and note the tool-call counts. Real runs vary.
3. Zoom the browser until the agent name and tool name are readable at the back.

## Set-up (about 2 minutes)

Read out the task: a customer says they did not make a EUR 1,249 card payment in Kuala Lumpur and wants it back. Tell the room the tools: transaction, customer, fraud signals, policy, propose action, draft message. Nothing real is executed; actions are only proposed.

## Script

**1. Single agent (about 3 min).** Before pressing Run, ask each pair to write on a sticky: how many tool calls, and who decides what happens next? Press **Run**. Count the calls together (8 in mock). Point out: one context, one loop, the model chooses the order. Ask: where would you put a control here? (Usually only at the tools.)

**2. Pipeline (about 4 min).** Predict first: what is different from the single agent? Select **Multi-agent pipeline** and press Run. Show the hand-off rows. Point out three things: the order is fixed by code, not by a model; the only thing the next agent knows is the hand-off note, so say what the comms agent never saw; and each hand-off is a natural place for a check. Ask the room: what is lost between investigator and policy?

**3. Orchestrator (about 4 min).** Predict: who touches the data now? (Nobody on the orchestrator's side.) Select **Orchestrator** and press Run. Read the delegate rows aloud: the orchestrator chooses who to call, passes facts forward in its own words, and in mock mode explains why comms must only propose. Stress the trade: flexibility in exchange for a decision you can no longer predict. In Real mode, run it twice; the order or the number of delegations may differ, which is the point.

**4. The approval point (about 2 min).** Scroll to the `propose_action` results on any run. Block card and provisional credit show `pending_human_approval`. Ask: who owns that approval? Link to the control ownership matrix on Day 4 and the Incident Wall.

## Comparing the three

Point at the corner counters after each run. All three make the same tool calls in mock mode; the difference is not the work, it is who decides, who sees what, and where you can attach a control. Ask the room to put one control on each architecture where they would place it.

## If someone says "it is scripted"

In Mock mode, the reasoning text is scripted and the tool calls are real. Say so up front. Switch to Real mode to show a model choosing.

## If it misbehaves on the day

- API key missing or network down: the page shows an error row. Switch to Mock and say you have done so.
- Real mode behaves differently from rehearsal: treat it as a talking point; the orchestrator's order is not guaranteed, and that is the lesson.
- Do not claim Mock output is a live model.
