# Agent architectures demo (Day 2, presenter-run)

One banking task, three architectures, one live trace. Nobody in the room uses the app. For the talk track, see `DEMO-GUIDE.md`.

## Set up

1. Install uv if you do not have it.
2. Run `uv sync` in this folder.
3. For real mode, copy `.env.example` to `.env` and add your `ANTHROPIC_API_KEY`. Mock mode needs no key and no network.

## Run

- `./run.sh` starts the page on http://127.0.0.1:8095.
- `./test.sh` runs the offline tests (mock mode only).

## What it shows

The task: a customer says they did not make a EUR 1,249 card payment in Kuala Lumpur and wants the money back.

- **Single agent:** one loop, all six tools, one context.
- **Pipeline:** investigator, then policy, then comms, always in that order. The only link between agents is the handoff note.
- **Orchestrator:** no data tools. Its only tool is `delegate`, and it chooses who runs and in what order.

Mock and real modes use the same tools and the same data. The difference is that mock mode scripts the agents' reasoning, so it is deterministic and offline-safe. Tool calls in mock mode are genuine.

`propose_action` never executes anything. Blocking the card and issuing credit return `pending_human_approval`.

## Files

- `app.py`: Flask server and the `/run` event stream.
- `engine.py`: the three architectures, in real and mock form.
- `tools.py`: invented bank data, policy, tools and their schemas.
- `templates/index.html`: the trace page.
- `tests/`: offline tests.

## Settings

- `ANTHROPIC_API_KEY`: needed for real mode only.
- `DEMO_MODEL`: defaults to `claude-haiku-5-5`.
