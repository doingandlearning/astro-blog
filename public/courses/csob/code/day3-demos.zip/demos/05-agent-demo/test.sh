#!/usr/bin/env bash
# Offline tests: mock mode only, no API key needed.
set -euo pipefail
cd "$(dirname "$0")"
exec uv run pytest "$@"
