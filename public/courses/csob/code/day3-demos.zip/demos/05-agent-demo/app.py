import json
import time

from flask import Flask, Response, render_template, request

import engine

app = Flask(__name__)


@app.get("/")
def index():
    return render_template("index.html", task=engine.TASK)


@app.get("/run")
def run():
    arch = request.args.get("arch", "single")
    mode = request.args.get("mode", "mock")
    pace = float(request.args.get("pace", "0.6"))

    def stream():
        for e in engine.run(arch, mode):
            yield f"data: {json.dumps(e)}\n\n"
            if mode == "mock":
                time.sleep(pace)  # slow enough to narrate over
        yield "event: done\ndata: {}\n\n"

    return Response(stream(), mimetype="text/event-stream")


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8095, debug=False, threaded=True)
