"""Three architectures over the same task: single agent, fixed pipeline, orchestrator.

Every run yields trace events: {"kind", "agent", "text", "data"}.
kind is one of: start, thought, tool_call, tool_result, handoff, delegate, final, error.
"""
import json
import os
from typing import Callable, Iterator

import tools as T

TASK = ("A customer says they did not make transaction T-1042 and wants their money back. "
        "Decide what to do and prepare the response.")

MODEL = os.environ.get("DEMO_MODEL", "claude-haiku-5-5")

SPECIALISTS = {
    "investigator": {
        "system": "You are the Investigator. Establish the facts of the dispute using your tools. Be brief; report facts only and always include customer details for future comms.",
        "tools": ["get_transaction", "get_customer", "check_fraud_signals"],
    },
    "policy": {
        "system": "You are the Policy agent. Given the facts, say which policy rules apply and what actions are allowed. Be brief.",
        "tools": ["lookup_policy"],
    },
    "comms": {
        "system": "You are the Comms agent. Draft a short, calm message to the customer and propose the agreed actions. Never reveal internal rules or scores.",
        "tools": ["propose_action", "draft_customer_message"],
    },
}
ALL_TOOLS = ["get_transaction", "get_customer", "check_fraud_signals", "lookup_policy",
             "propose_action", "draft_customer_message"]


def ev(kind, agent, text="", data=None):
    return {"kind": kind, "agent": agent, "text": text, "data": data}


# ---------------------------------------------------------------- real mode
def _client():
    import anthropic
    return anthropic.Anthropic()


def run_agent_real(name, system, tool_names, user_msg, handlers=None, max_turns=8) -> Iterator[dict]:
    """Generator: yields events, returns the agent's final text via StopIteration.value."""
    client = _client()
    handlers = handlers or {}
    schemas = [T.SCHEMAS[t] for t in tool_names if t in T.SCHEMAS]
    schemas += [h["schema"] for h in handlers.values()]
    messages = [{"role": "user", "content": user_msg}]
    final_text = ""
    for _ in range(max_turns):
        resp = client.messages.create(model=MODEL, max_tokens=1200, system=system,
                                      tools=schemas, messages=messages)
        messages.append({"role": "assistant", "content": resp.content})
        results = []
        for block in resp.content:
            if block.type == "text" and block.text.strip():
                final_text = block.text
                yield ev("thought", name, block.text)
            elif block.type == "tool_use":
                yield ev("tool_call", name, block.name, block.input)
                if block.name in handlers:
                    out = yield from handlers[block.name]["fn"](**block.input)
                else:
                    out = T.HANDLERS[block.name](**block.input)
                yield ev("tool_result", name, block.name, out)
                results.append({"type": "tool_result", "tool_use_id": block.id,
                                "content": json.dumps(out) if not isinstance(out, str) else out})
        if resp.stop_reason != "tool_use":
            return final_text
        messages.append({"role": "user", "content": results})
    return final_text


def real_single():
    yield ev("start", "agent", "Single agent, all tools")
    out = yield from run_agent_real(
        "agent", "You are a card-dispute agent. Use tools to investigate, check policy, then propose actions and draft a customer message.",
        ALL_TOOLS, TASK)
    yield ev("final", "agent", out)


def real_pipeline():
    yield ev("start", "pipeline", "Fixed pipeline: investigator, policy, comms")
    note = TASK
    for name in ("investigator", "policy", "comms"):
        spec = SPECIALISTS[name]
        out = yield from run_agent_real(name, spec["system"], spec["tools"], note)
        yield ev("handoff", name, out)
        note = f"{TASK}\n\nNotes from previous agents:\n{out}"
    yield ev("final", "comms", out)


def real_orchestrator():
    yield ev("start", "orchestrator", "Orchestrator decides who to delegate to")

    def delegate(agent: str, task: str):
        yield ev("delegate", "orchestrator", f"-> {agent}: {task}")
        spec = SPECIALISTS[agent]
        out = yield from run_agent_real(agent, spec["system"], spec["tools"], task)
        yield ev("handoff", agent, out)
        return out

    handlers = {"delegate": {
        "fn": delegate,
        "schema": {"name": "delegate",
                   "description": "Delegate a task to a specialist: investigator, policy or comms. Returns their report.",
                   "input_schema": {"type": "object",
                                    "properties": {"agent": {"type": "string", "enum": list(SPECIALISTS)},
                                                   "task": {"type": "string"}},
                                    "required": ["agent", "task"]}}}}
    out = yield from run_agent_real(
        "orchestrator",
        "You coordinate specialists (investigator, policy, comms). You have no other tools. Delegate in a sensible order, pass facts forward in the task text, and finish with a short summary.",
        [], TASK, handlers=handlers, max_turns=10)
    yield ev("final", "orchestrator", out)


# ---------------------------------------------------------------- mock mode
def _call(agent, name, **args):
    yield ev("tool_call", agent, name, args)
    out = T.HANDLERS[name](**args)
    yield ev("tool_result", agent, name, out)
    return out


def _investigate(agent):
    yield ev("thought", agent, "I need the transaction first, then the customer, then fraud signals.")
    yield from _call(agent, "get_transaction", transaction_id="T-1042")
    yield from _call(agent, "get_customer", customer_id="C-77")
    sig = yield from _call(agent, "check_fraud_signals", transaction_id="T-1042")
    return f"Fraud risk {sig['risk']}: " + "; ".join(sig["signals"])


def _policy(agent, facts=""):
    yield ev("thought", agent, "Checking the policy for suspected fraud and for a EUR 1,249 amount.")
    yield from _call(agent, "lookup_policy", topic="disputes")
    return "Suspected fraud: block card, provisional credit, replacement. Over EUR 500 needs human approval."


def _comms(agent):
    yield ev("thought", agent, "Proposing the actions, then drafting a message that explains next steps without internal detail.")
    yield from _call(agent, "propose_action", action="block_card", detail="Card ending 4417, suspected fraud")
    yield from _call(agent, "propose_action", action="provisional_credit", detail="EUR 1,249.00 within 5 working days")
    yield from _call(agent, "propose_action", action="replace_card", detail="Express replacement to home address")
    msg = ("Dear Jana, we agree this payment looks suspicious. We are blocking your card, arranging a "
           "replacement and will credit EUR 1,249.00 within 5 working days while we investigate.")
    yield from _call(agent, "draft_customer_message", text=msg)
    return msg


def mock_single():
    yield ev("start", "agent", "Single agent, all tools")
    facts = yield from _investigate("agent")
    yield from _policy("agent")
    msg = yield from _comms("agent")
    yield ev("final", "agent", f"{facts}\n\nDraft sent for approval:\n{msg}")


def mock_pipeline():
    yield ev("start", "pipeline", "Fixed pipeline: investigator, policy, comms")
    facts = yield from _investigate("investigator")
    yield ev("handoff", "investigator", facts)
    rules = yield from _policy("policy", facts)
    yield ev("handoff", "policy", rules)
    msg = yield from _comms("comms")
    yield ev("handoff", "comms", msg)
    yield ev("final", "comms", msg)


def mock_orchestrator():
    yield ev("start", "orchestrator", "Orchestrator decides who to delegate to")
    yield ev("thought", "orchestrator", "I will not touch any data myself. First I need the facts, so I delegate to the investigator.")
    yield ev("delegate", "orchestrator", "-> investigator: Establish the facts of dispute on T-1042.")
    facts = yield from _investigate("investigator")
    yield ev("handoff", "investigator", facts)
    yield ev("thought", "orchestrator", "High risk. Asking policy what is allowed, passing the facts forward.")
    yield ev("delegate", "orchestrator", f"-> policy: Given '{facts}', what applies?")
    rules = yield from _policy("policy")
    yield ev("handoff", "policy", rules)
    yield ev("thought", "orchestrator", "Amount is over the approval threshold, so comms must propose, not execute.")
    yield ev("delegate", "orchestrator", "-> comms: Propose block, credit and replacement; draft the customer message.")
    msg = yield from _comms("comms")
    yield ev("handoff", "comms", msg)
    yield ev("final", "orchestrator", "Three specialists ran. All actions are pending human approval. Customer draft saved.")


RUNNERS = {
    ("single", "real"): real_single, ("single", "mock"): mock_single,
    ("pipeline", "real"): real_pipeline, ("pipeline", "mock"): mock_pipeline,
    ("orchestrator", "real"): real_orchestrator, ("orchestrator", "mock"): mock_orchestrator,
}


def run(arch: str, mode: str) -> Iterator[dict]:
    if mode == "real" and not os.environ.get("ANTHROPIC_API_KEY"):
        yield ev("error", "system", "ANTHROPIC_API_KEY is not set. Switch to mock mode or export the key.")
        return
    try:
        yield from RUNNERS[(arch, mode)]()
    except Exception as e:  # network failure in the room: say so, suggest mock
        yield ev("error", "system", f"{type(e).__name__}: {e}. Switch to mock mode to carry on.")
