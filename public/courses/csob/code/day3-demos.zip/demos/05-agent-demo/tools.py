"""Mock bank back-end used by every agent. Data is invented for the demo."""

TRANSACTIONS = {
    "T-1042": {
        "id": "T-1042", "customer_id": "C-77", "amount_eur": 1249.00,
        "merchant": "ELECTRO-MART KL", "city": "Kuala Lumpur", "country": "MY",
        "channel": "card-not-present", "time": "2026-11-01T14:12:00+01:00",
    },
}
CUSTOMERS = {
    "C-77": {
        "id": "C-77", "name": "Jana Novak", "home_city": "Prague", "home_country": "CZ",
        "card_last4": "4417", "tenure_years": 6, "previous_disputes": 0,
        "last_card_present": {"city": "Prague", "country": "CZ", "time": "2026-11-01T13:32:00+01:00"},
    },
}
POLICY = {
    "auto_refund_limit_eur": 50,
    "human_approval_over_eur": 500,
    "suspected_fraud": "Block the card, offer provisional credit within 5 working days, issue a replacement card.",
    "never": "Never reveal fraud-model scores or internal rule names to the customer.",
}

READ_TOOLS = {"get_transaction", "get_customer", "check_fraud_signals", "lookup_policy"}
ACTION_TOOLS = {"propose_action", "draft_customer_message"}


def get_transaction(transaction_id: str):
    return TRANSACTIONS.get(transaction_id, {"error": "not found"})


def get_customer(customer_id: str):
    return CUSTOMERS.get(customer_id, {"error": "not found"})


def check_fraud_signals(transaction_id: str):
    t = TRANSACTIONS.get(transaction_id)
    if not t:
        return {"error": "not found"}
    c = CUSTOMERS[t["customer_id"]]
    signals = []
    if t["country"] != c["home_country"]:
        signals.append("foreign merchant country")
    if t["channel"] == "card-not-present":
        signals.append("card-not-present")
    if c["last_card_present"]["country"] != t["country"]:
        signals.append("card used in person in another country 40 minutes earlier (impossible travel)")
    if t["amount_eur"] > 1000:
        signals.append("high value")
    return {"signals": signals, "risk": "high" if len(signals) >= 3 else "medium" if signals else "low"}


def lookup_policy(topic: str = "disputes"):
    return POLICY


def propose_action(action: str, detail: str):
    """Side-effecting actions are only PROPOSED. Nothing is executed in this demo."""
    needs_human = action in {"block_card", "provisional_credit"}
    return {
        "status": "pending_human_approval" if needs_human else "recorded",
        "action": action, "detail": detail,
        "note": "Proposed only. A named human owner approves before anything runs.",
    }


def draft_customer_message(text: str):
    return {"status": "draft_saved", "text": text}


HANDLERS = {
    "get_transaction": get_transaction,
    "get_customer": get_customer,
    "check_fraud_signals": check_fraud_signals,
    "lookup_policy": lookup_policy,
    "propose_action": propose_action,
    "draft_customer_message": draft_customer_message,
}


def _schema(name, desc, props, required):
    return {"name": name, "description": desc,
            "input_schema": {"type": "object", "properties": props, "required": required}}


SCHEMAS = {
    "get_transaction": _schema("get_transaction", "Fetch a card transaction by id.",
                               {"transaction_id": {"type": "string"}}, ["transaction_id"]),
    "get_customer": _schema("get_customer", "Fetch a customer profile by id.",
                            {"customer_id": {"type": "string"}}, ["customer_id"]),
    "check_fraud_signals": _schema("check_fraud_signals", "List fraud signals for a transaction.",
                                   {"transaction_id": {"type": "string"}}, ["transaction_id"]),
    "lookup_policy": _schema("lookup_policy", "Read the dispute handling policy.",
                             {"topic": {"type": "string"}}, []),
    "propose_action": _schema("propose_action",
                              "Propose an action (block_card, provisional_credit, replace_card). Never executes.",
                              {"action": {"type": "string"}, "detail": {"type": "string"}}, ["action", "detail"]),
    "draft_customer_message": _schema("draft_customer_message", "Save a draft message to the customer.",
                                      {"text": {"type": "string"}}, ["text"]),
}
