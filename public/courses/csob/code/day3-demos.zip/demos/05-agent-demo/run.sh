#!/usr/bin/env bash
# Start the demo on http://127.0.0.1:8095. Choose Mock or Real in the page.
set -euo pipefail
cd "$(dirname "$0")"
# Load ANTHROPIC_API_KEY and DEMO_MODEL from .env if the file exists (never commit it)
if [[ -f .env ]]; then set -a; source .env; set +a; fi
exec uv run python app.py
