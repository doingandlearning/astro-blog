# Build brief: Hybrid search demo (Day 1)

Hand this whole file to a coding model. It is self-contained.

## What this is and why it exists

You are building a small local web app that a trainer will run live on a projector for about 15 minutes during a four-day course called "Enterprise Agentic Systems: Foundations", delivered to security analysts and architects at a bank. The audience is not made up of coders. They will watch, predict and discuss; nobody uses the app themselves.

The teaching point is one specific failure: pure semantic (vector) search often misses exact references such as a clause number or a product code, and returns text that is about the right topic but is the wrong clause. Hybrid search (keyword plus vector, fused) finds the right clause. The room should see this happen for real, on the same query, in two consecutive steps.

The trainer's script, which the app must support exactly:

1. The trainer asks the room to predict which search will find the exact clause reference. Nothing has run yet.
2. The trainer runs the vector-only search. It returns plausible but wrong-clause results.
3. The trainer runs the hybrid search on the same query. The correct clause appears at the top.
4. The trainer asks: whose job is it to catch the vector-only gap before go-live?

## Hard requirements

- It must run entirely offline on a laptop after setup. Venue networks cannot be trusted. All models and data are downloaded or generated beforehand and stored in the project.
- It must be honest. The vector-only failure has to occur because of how real retrieval behaves on the corpus, never because results are hard-coded, filtered or reordered to fail. If the real embedding model happens to find the right clause, change the corpus (see below), not the retrieval code. The app should show real scores.
- Bind to 127.0.0.1, not localhost.
- One command to start, one command to run the tests, and a short README with a rehearsal checklist.
- Python 3.11 or newer, pinned dependencies, no accounts, no API keys, no telemetry.

## Suggested stack (change it if you have a good reason, and say why)

- A Python backend (FastAPI is fine) and one static HTML page with plain JavaScript. No build step.
- Local embeddings from a small sentence-transformers model (all-MiniLM-L6-v2 or similar), downloaded once and loaded from disk. Pin the model name and version, because the demo result depends on it.
- Keyword search with BM25 (rank_bm25 or your own implementation).
- Fusion with reciprocal rank fusion, constant 60, over the top 20 of each list.
- In-memory index built at start-up from the corpus files. No database.

## The corpus

Create a synthetic corpus for a fictional lender, "Example Bank". Do not use any real bank's name, wording, products or policies, and do not use anything that looks like CSOB or KBC material. Five to eight documents, each a few pages of plain text or Markdown, split into clause-level chunks that each carry a clause reference.

- Topics: mortgage lending policy, early repayment and overpayment, arrears and forbearance, product terms for three or four mortgage products, complaints handling, data retention.
- Every chunk has a visible reference, for example "4.2.1", and some chunks carry a product code such as "MTG-STD-03", "MTG-FIX-05", "MTG-BTL-02".
- The target query is something like "What does policy clause 4.2.1 say about overpayments?" and a second one using a product code, such as "MTG-STD-03 early repayment charge".
- To make pure semantic search fail genuinely, write several near-neighbour clauses that discuss the same topic with very similar wording but different numbers and different rules (for example 4.2.1, 4.2.7, 4.1.2 and a clause in a different document, all about overpayments, differing in thresholds and conditions). The correct clause must be the one whose number matches. This is realistic: real policy sets are full of near-duplicates.
- Include two or three control queries where vector-only search works fine (a natural-language question with no reference), so the trainer can show it is not "broken", just blind to exact identifiers.

## The interface

A single page, readable from the back of a room.

- Large type (body text at least 20px equivalent), high contrast, a light and dark theme, no tiny detail.
- A search box and two large buttons: "Run vector-only" and "Run hybrid". The trainer decides when each runs. Results from the first run stay on screen when the second is run, side by side (left panel vector-only, right panel hybrid), so the contrast is visible together.
- A "Reset" button that clears both panels so the trainer can rerun.
- A row of preset query buttons for the target query, the product-code query and the control queries.
- Each result shows: rank, clause reference in a bold badge, document title, a short snippet, and the score. Highlight the exact query tokens (such as "4.2.1") inside the snippet.
- In the hybrid panel, show for each result its rank in the keyword list and in the vector list ("keyword #1, vector #7") so the trainer can explain why it surfaced. A one-line caption names the fusion method in plain English.
- Mark the result whose reference exactly matches the query reference, but only after both runs have happened, so the prediction step is not spoiled. A "reveal" toggle is fine.

## Optional extras, only if they stay simple

- A "who can see what" toggle for security trimming: each chunk is tagged with an access group, the user picks a role, and results the role cannot see are removed before ranking. This supports a later slide aimed at security officers. If it complicates the main demo, leave it out.
- A static export: one command that writes the side-by-side results for the preset queries as a single self-contained HTML file and PNG screenshots. This is the fallback if the live app cannot run on the day.

## Tests and acceptance

- An automated test confirms that for the target query the vector-only top three does not contain the clause whose reference matches, and the hybrid top result does. It must fail loudly if a model or corpus change breaks the demo.
- A second test confirms the control queries return sensible results from both modes.
- A test confirms the app starts with the network disabled (or at least that nothing makes an outbound request at run time).
- Manual acceptance: from a cold start, the trainer can run the full four-step script in under two minutes and every number on screen is explainable.

## Deliverables

The project folder; a README covering setup, one-command start, running the tests, regenerating the index, the rehearsal checklist (run it the morning of the session, not the night before), and how to produce the static fallback; and a short note on why the pinned model was chosen and what the vector-only result looks like on the target query.
