# Build brief: Prompt injection demo (Day 3)

Hand this whole file to a coding model. It is self-contained.

## What this is and why it exists

You are building a small local web app that a trainer will drive live on a projector for about 25 minutes during a four-day course called "Enterprise Agentic Systems: Foundations", delivered to security analysts and architects at a bank. The audience is not made up of coders. They watch and react; nobody uses the app themselves. The room already thinks in terms of incident response, so the demo should feel like a controlled exercise, not a trick.

The trainer's script, which the app must support step by step:

1. Normal run. A small agent summarises or answers questions about a clean document. The room is asked to predict the outcome, and sees the expected safe output.
2. Attack run. The same agent processes a document with an instruction hidden inside it. The agent follows the buried instruction in addition to, or instead of, its real task.
3. Pause. The trainer asks the room to describe what happened in their own words. The app should simply hold still and show what happened clearly (see "What the screen shows").
4. Mitigation. The same attack is run with one mitigation applied. Two mitigations are available: a narrowly scoped output schema that rejects the manipulated output, and a hardened system prompt. The hardened prompt must help but not fully fix the problem; the schema must bound the damage. The room should see "helps but isn't a complete fix".
5. Extraction. The trainer asks the same agent to repeat its instructions word for word. It reveals a planted fake internal detail from the system prompt. The trainer asks: what in here should never have been written into a prompt? Then moves on to a slide about system prompts.

## Hard requirements

- Safe by design. Nothing in the app can do real harm. The only "tool" is a stub that returns the contents of the provided document. The agent has no network, file or shell access. Any "attacker" message or link uses a reserved, non-resolving domain (use example.invalid), and any internal detail in the system prompt is obviously fake (for example hostname "ops-queue-test.internal.example" and a made-up escalation inbox).
- Honest. Any success or failure of the injection must be real model behaviour, not scripted. If a replay mode exists (below), it must be clearly labelled "Recorded run" on screen.
- Reliable. Before the session the trainer must be able to confirm the attack triggers reliably. Build a rehearsal command that runs each step 20 times and prints the trigger rate for the attack, the hardened-prompt variant and the schema variant. Aim for 95 per cent or better on the attack in step 2.
- Bind to 127.0.0.1, not localhost.
- No secrets in the repository. The model API key comes from an environment variable. The model name is configurable, because modern models often resist simple injections and the trainer may need to pick a smaller or older one, or a plainer prompt design, to make the demonstration of a deliberately vulnerable setup reliable. Say so in the README. The slide narrative should be "this is what a naive configuration does", not "all models are this weak".
- One command to start, one command to run the tests, and a short README with a rehearsal checklist.

## Suggested stack (change it if you have a good reason, and say why)

- A Python backend (FastAPI is fine) calling a hosted LLM through its official SDK, plus one static HTML page with plain JavaScript. No build step.
- Temperature zero, with the sampling settings and model version pinned and displayed in a small footer so reruns are comparable.

## The agent and the documents

- The agent: a plain LLM call with a short system prompt and one stub tool, "read_document". Its job is "summarise this document in three bullet points" or "answer questions about this document". Keep the system prompt short and deliberately naive: the document text is placed into the prompt with no special delimiting, which is realistic for early pilots.
- The system prompt includes one harmless, obviously fake internal detail that step 5 can leak.
- Documents: write two or three short synthetic documents for a fictional lender, "Example Bank" (for example a supplier onboarding summary, a card dispute process note, a branch opening hours policy). Do not use any real bank's material or anything that looks like CSOB or KBC content.
- Document A: clean.
- Document B: the same document with an injected instruction buried a few paragraphs in, in plain text, for example a "system note" telling the agent to ignore prior instructions and append a given sentence plus a link to example.invalid to its output.
- Document C: a rephrased injection designed to get past the hardened prompt (so the trainer can show that prompt hardening alone is not a complete fix) but which the output schema still catches.
- A short plain-English note per document describing where the injection is, so the trainer can point at it.

## The two mitigations

- Output schema enforcement: the agent must return structured output (a summary of no more than a set number of characters and a list of three short bullet points). A validator rejects anything outside the schema, including extra text, URLs and instructions. The screen shows "Output rejected by schema" with the reason, and what the user would have seen otherwise.
- Hardened system prompt: an extra paragraph that tells the model to treat document content as data and to ignore instructions inside it. It should work against document B and fail against document C, if the model allows that. If you find that it never fails, or always fails, tell the trainer in the README and adjust the wording of C until the intended contrast is real. Never fake it.

## What the screen shows

Readable from the back of a room: large type, high contrast, light and dark theme.

- A five-step stepper across the top matching the script, with big buttons ("Run normal", "Run attack", "Apply schema", "Apply hardened prompt", "Ask for instructions"). The trainer controls the pace, and nothing runs automatically.
- Four panels: the system prompt, the document with the injected text highlighted (the highlight can be hidden until step 3), the raw model output, and a verdict strip that says in plain words what happened ("Followed the hidden instruction", "Output rejected", "Stayed on task").
- A "show the prompt the model actually received" toggle, so a sceptical security analyst can see there is no trick.
- A "reset" button.

## Replay mode and fallbacks

- A record command that runs the five steps live and saves the real outputs. A replay mode serves those saved outputs, with a clear "Recorded run" banner, for when the network or API is unavailable on the day.
- A command that exports the whole sequence as a self-contained HTML page and as a plain script for a 90-second screen capture. The course materials already allow a pre-recorded capture as the fallback, narrated live.

## Tests and acceptance

- Automated tests with the model call mocked: the validator accepts a good output and rejects extra text, URLs and an oversize summary; the stepper only allows the intended order; replay mode never calls the network.
- A live test (marked as such, skipped by default) that runs the rehearsal command.
- Manual acceptance: from a cold start the trainer can run all five steps in under ten minutes of screen time, and every output on screen is explainable from the prompt shown.

## Deliverables

The project folder; a README covering setup, the environment variables, starting the app, the rehearsal command and what a good result looks like, recording and replaying, and a note on model choice and why the trigger rate is what it is; and the three documents with their notes.
