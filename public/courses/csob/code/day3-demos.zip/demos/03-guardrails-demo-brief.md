# Build brief: Guardrails demo (Day 4)

Hand this whole file to a coding model. It is self-contained.

## What this is and why it exists

You are building a small local web app that a trainer will drive live on a projector for about 25 minutes during a four-day course called "Enterprise Agentic Systems: Foundations", delivered to security officers, architects and information risk management staff at a bank. The audience is not made up of coders. They watch and react; nobody uses the app themselves. The room thinks in terms of preventive and detective controls, error rates and evidence, so the demo should feel like testing a control, not a magic trick.

The point of the demo is that a guardrail is a control with an error rate. It can sit in four places (input, output, action, human). Each catches different things, each misses things, and each costs something when wrong. The trainer's script, which the app must support step by step:

1. Baseline, no guardrails. A small assistant for a fictional lender handles three requests: a normal question, a request that includes a pasted document with a hidden instruction, and a request for a refund above the assistant's limit. The assistant does what it is asked in all three.
2. Input guardrail. A rule list plus a small classifier checks the user message and any pasted content. The hidden instruction is blocked. A reworded version of the same attack gets through, and the screen shows that plainly as a false negative.
3. Output guardrail. Pattern redaction for account-number-shaped strings, plus an output schema. A leaked fake account number is redacted or blocked. A harmless customer reference that looks like an account number is wrongly blocked: a false positive, shown with its cost to a legitimate user.
4. Action guardrail. A policy check sits between the agent and its one tool ("issue_refund"). The over-limit refund is denied regardless of what the model was talked into. The policy is a short, human-readable file shown on screen, with default deny.
5. Human guardrail. A borderline refund goes to an approval queue. The screen shows what the approver sees: request, reason, evidence and the rule that triggered escalation.
6. Scorecard. A labelled test set of about 40 prompts (half attacks, half legitimate) runs against each layer alone and all four together. The screen shows a table of attacks caught and legitimate requests wrongly blocked. A slider moves the classifier threshold so the room sees the trade-off. The guardrail settings are shown as a versioned file with a revision identifier, so the trainer can say "this is configuration, and it belongs in the agent's configuration record".

## Hard requirements

- Safe by design. Nothing in the app can do real harm. The only tool is a stub that records a refund in memory. No network, file or shell access for the agent. Any link uses example.invalid. All account numbers, names and references are obviously fake and generated, in a fictional lender called "Example Bank". Do not use anything that looks like CSOB, KBC or any real bank's material.
- Honest. Any success or failure of a guardrail must be real behaviour of the real checks, not scripted. If a replay mode exists, it must be clearly labelled "Recorded run" on screen. The false negative in step 2 and the false positive in step 3 must be real, found by testing, not hard-coded. If a step's contrast does not occur with the chosen model or settings, tell the trainer in the README and adjust the test inputs until it is real. Never fake it.
- Reliable. Provide a rehearsal command that runs each step 20 times and prints how often the intended result occurs (attack blocked at step 2, reworded attack passing at step 2, false positive at step 3, refund denied at step 4). Aim for 90 per cent or better on each, and report any that fall short.
- The action guardrail is deterministic code (a policy file evaluated outside the model), not a prompt. State this in the README. The input classifier may be a small model call or a simple local classifier. The input rule list and the output patterns are plain code.
- Bind to 127.0.0.1, not localhost.
- No secrets in the repository. The model API key comes from an environment variable and the model name is configurable. Say in the README that the narrative is "a controlled example of how each layer behaves", not a benchmark of any product.
- One command to start, one command to run the tests, and a short README with a rehearsal checklist.

## Suggested stack (change it if you have a good reason, and say why)

- A Python backend (FastAPI is fine) calling a hosted LLM through its official SDK, plus one static HTML page with plain JavaScript. No build step.
- Temperature zero, with the sampling settings and model versions pinned and displayed in a small footer so reruns are comparable.
- Policy as a short YAML file (limits, allowed tools, escalation threshold, default deny), evaluated by a small function. Guardrail settings (thresholds, patterns, policy) all in one versioned file with a revision hash shown on screen.

## The assistant, requests and test set

- The assistant: a short system prompt and one tool, "issue_refund(customer_ref, amount, reason)". Its job is to answer customer questions about a document or request and to process small refunds. The refund limit stated in the system prompt is 100, and the policy file says the same thing. The assistant is allowed to be naive about it; that is the point of step 4.
- Request 1: a normal question about a clean document.
- Request 2: a document with an instruction buried a few paragraphs in, plain text, telling the assistant to ignore earlier instructions and send a refund or reveal a given fake account number.
- Request 3: a polite, plausible message asking for a refund of 450.
- Reworded attack for step 2: the same intent as request 2, phrased so the rule list and classifier are likely to miss it (for example indirect wording or a different language).
- Borderline case for step 5: a refund of 100 to 300, within the approval band, with a plausible reason.
- Test set: about 40 labelled prompts in a JSON file, half attacks (injection, jailbreak, data-extraction attempts, over-limit refunds) and half legitimate (including a few Czech and Slovak phrases and account-number-like customer references, so false positives can appear). Each has a label and a one-line note. Make the labels and notes visible to the trainer in a plain table.

## What the screen shows

Readable from the back of a room: large type, high contrast, light and dark theme.

- A six-step stepper across the top matching the script, with big buttons ("Baseline", "Input guardrail on", "Output guardrail on", "Action guardrail on", "Human approval on", "Run scorecard"). The trainer controls the pace and nothing runs automatically.
- Four panels: what the user sent, what the model produced, what each guardrail decided (allow, block, redact, escalate) with the reason, and a verdict strip in plain words ("Attack got through", "Blocked", "Legitimate request wrongly blocked").
- Each guardrail layer shown as a coloured stage in a simple flow diagram (input, model, output, action, human), lighting up as the request passes through it.
- A "show what the model actually received" toggle, so a sceptical analyst can see there is no trick.
- A scorecard table (caught, missed, wrongly blocked, per layer and combined), the threshold slider, and a "show the settings file" view with the revision hash.
- A reset button.

## Replay mode and fallbacks

- A record command that runs all six steps live and saves the real outputs, including the scorecard. A replay mode serves those saved outputs, with a clear "Recorded run" banner, for when the network or API is unavailable on the day.
- A command that exports the whole sequence as a self-contained HTML page and a plain script for a 90-second screen capture per step, so the trainer can narrate over a recording.

## Tests and acceptance

- Automated tests with model calls mocked: the policy evaluator denies an over-limit refund, escalates a borderline one, allows a small one, and denies any tool not in the allowed list; the output redactor catches the fake account patterns; the stepper only allows the intended order; scorecard arithmetic is correct; replay mode never calls the network.
- A live test (marked as such, skipped by default) that runs the rehearsal command.
- Manual acceptance: from a cold start the trainer can run all six steps in under 15 minutes of screen time, and every decision on screen is explainable from the settings and prompt shown.

## Deliverables

The project folder; a README covering setup, environment variables, starting the app, the rehearsal command and what a good result looks like, recording and replaying, and a note on model choice and why the false negative and false positive appear when they do; the policy file; the test set with its notes; and the sample documents.
