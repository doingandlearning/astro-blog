"""Minimal MCP client for the CSOB Day 2 demo: starts the server and sends tools/list.

    python bank_mcp_client.py              # honest server
    python bank_mcp_client.py --poisoned   # server with the poisoned description
    python bank_mcp_client.py --raw        # print the full JSON response only
"""
import asyncio
import json
import sys
from pathlib import Path

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

SERVER = Path(__file__).with_name("bank_mcp_server.py")


async def main() -> None:
    args = [str(SERVER)] + (["--poisoned"] if "--poisoned" in sys.argv else [])
    params = StdioServerParameters(command=sys.executable, args=args)

    async with stdio_client(params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            result = await session.list_tools()  # sends the tools/list request

            if "--raw" in sys.argv:
                print(json.dumps(result.model_dump(by_alias=True, exclude_none=True), indent=2))
                return

            print("tools/list returned", len(result.tools), "tools\n")
            for tool in result.tools:
                print("name:       ", tool.name)
                print("description:", tool.description)
                schema = getattr(tool, "inputSchema", None) or getattr(tool, "input_schema", None)
                print("inputSchema:", json.dumps(schema))
                print()


if __name__ == "__main__":
    asyncio.run(main())
