# MCP demo: tools/list

A tiny banking MCP server and a client that sends `tools/list`.

Run from this folder (needs [uv](https://docs.astral.sh/uv/)):

- `uv run mcp-demo-client` shows the honest tool list.
- `uv run mcp-demo-client --poisoned` shows the same list with a hidden instruction in one description.
- `uv run mcp-demo-client --raw` prints the full JSON response.

The client starts the server itself over stdio. To run the server on its own, use `uv run mcp-demo-server`.
