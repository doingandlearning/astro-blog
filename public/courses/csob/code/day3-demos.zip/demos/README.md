# Demo briefs

Three live demos in the course need small apps. Each brief is self-contained, so you can hand one file to a model on its own.

- `01-hybrid-search-demo-brief.md`: Day 1, hybrid search live (about 15 minutes). Runs fully offline.
- `02-prompt-injection-demo-brief.md`: Day 3, prompt injection live (about 25 minutes). Needs a model API unless you use the recorded replay.
- `03-guardrails-demo-brief.md`: Day 4, guardrails live (about 25 minutes), added after the CSOB call. Four guardrail layers, a labelled test set and a scorecard. Needs a model API unless you use the recorded replay.

Nothing else in the course needs an app. The worksheets are PDFs and the exercises are paper-based. Each demo has a documented fallback in `activities-and-labs.md` (a static screenshot for Day 1, a pre-recorded capture for Days 3 and 4).
