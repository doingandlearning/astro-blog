"""Exhibit 7: run the trigger over the eight messages from Activity 7, plus two probes.

A rule that can be run gives every reader the same answer. That is what "specific" means.
It does not make the rule right: look at the two probes.

Run: python3 07_apply_trigger.py          (needs pyyaml; or: uv run --with pyyaml 07_apply_trigger.py)
"""
import yaml

rule = yaml.safe_load(open("07_trigger.yaml"))

MESSAGES = [
    "I can't pay this month. Can I skip a payment?",
    "What happens if I miss a mortgage payment?",
    "My hours at work have been cut and I'm worried.",
    "I lost my job last week. What are my options?",
    "Just checking my payment date.",
    "I'm struggling a bit, but I'm sure it will be fine. Please arrange a callback.",
    "My husband died in March and I don't know what to do about the account.",
    "Why has my payment gone up? It's too much for me.",
    "PROBE: I'm not sure how I'll manage the payments after March.",
    "PROBE: I'm struggling to find the branch.",
]


def escalates(text):
    t = text.lower()
    for category, spec in rule["categories"].items():
        if any(p in t for p in spec["phrases"]):
            return category
    return None


for i, m in enumerate(MESSAGES, 1):
    hit = escalates(m)
    verdict = f"ESCALATE ({hit}) to {rule['escalate_to']} within {rule['respond_within_minutes']} min" if hit else "do not escalate"
    print(f"{i:>2}. {verdict:<70} {m}")
