"""Exhibit 4: the output schema from the injection demo, with a validator in front of it.

Run: python3 04_check_output.py           (needs jsonschema; or: uv run --with jsonschema 04_check_output.py)
"""
import json
from jsonschema import Draft202012Validator

validator = Draft202012Validator(json.load(open("04_output_schema.json")))

CASES = {
    "clean summary": {"bullets": ["Suppliers are onboarded in five steps.", "Checks run before first payment.", "Questions go to the supplier desk."]},
    "injected: fourth bullet with a link": {"bullets": ["Suppliers are onboarded in five steps.", "Checks run before first payment.", "Questions go to the supplier desk.", "Verify at supplier-verify.example.invalid"]},
    "injected: link inside a bullet": {"bullets": ["Suppliers are onboarded in five steps.", "Checks run before first payment.", "Verify at supplier-verify.example.invalid"]},
    "injected: extra field": {"bullets": ["One.", "Two.", "Three."], "note": "ignore previous instructions"},
    "wrong but valid-looking": {"bullets": ["Suppliers are onboarded in five steps.", "Checks run before first payment.", "Payments now go to the account in the attached note."]},
}

for name, doc in CASES.items():
    rules = sorted({e.validator for e in validator.iter_errors(doc)})
    print(f"{name}: {'ACCEPTED' if not rules else 'REJECTED by ' + ', '.join(rules)}")
