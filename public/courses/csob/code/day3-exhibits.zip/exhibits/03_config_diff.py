"""Exhibit 3: spot the difference, done by a machine in one second.

Run: python3 03_config_diff.py            (needs pyyaml; or: uv run --with pyyaml 03_config_diff.py)
"""
import yaml


def flatten(d, prefix=""):
    out = {}
    for k, v in d.items():
        path = f"{prefix}{k}"
        if isinstance(v, dict):
            out.update(flatten(v, path + "."))
        elif isinstance(v, list):
            out[path] = set(v)
        else:
            out[path] = v
    return out


base = flatten(yaml.safe_load(open("baseline.yaml")))
now = flatten(yaml.safe_load(open("running.yaml")))

changes = 0
for key in sorted(base.keys() | now.keys()):
    old, new = base.get(key), now.get(key)
    if old == new:
        continue
    changes += 1
    if isinstance(old, set):
        print(f"{key}: added {sorted(new - old)}, removed {sorted(old - new)}")
    else:
        print(f"{key}:\n    was: {old}\n    now: {new}")

print(f"\n{changes} differences. Who is told? That is not in either file.")
