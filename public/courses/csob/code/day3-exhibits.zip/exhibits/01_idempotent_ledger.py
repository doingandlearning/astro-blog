"""Exhibit 1: the retry ledger as code. The same six cards as Activity 3.

Real-world shape: payment APIs such as Stripe's accept an Idempotency-Key header on
POST requests and replay the stored result when the same key arrives again.

    curl https://api.stripe.com/v1/customers -H "Idempotency-Key: KG5LxwFBepaKHyUD" ...

Run: python3 01_idempotent_ledger.py
"""


def decide(key, payee, amount, ledger):
    if key is None:
        return "refuse: no key means no idempotency"
    if key not in ledger:
        for other, (state, p, a) in ledger.items():
            if (p, a) == (payee, amount) and state == "completed":
                return f"stop and ask: same payee and amount as {other}, new key"
        return "do it: write the key as started"
    state, p, a = ledger[key]
    if (p, a) != (payee, amount):
        return "stop and ask: the log disagrees with the request"
    if state == "completed":
        return "skip: it already happened, return the stored result"
    return "ask the payment system for the status of this key; unknown means stop and ask"


CASES = [
    ("Card 1", "K-101", "supplier A", 5000, {}),
    ("Card 2", "K-101", "supplier A", 5000, {"K-101": ("started", "supplier A", 5000)}),
    ("Card 3", "K-101", "supplier A", 5000, {"K-101": ("completed", "supplier A", 5000)}),
    ("Card 4", "K-207", "supplier A", 5000, {"K-101": ("completed", "supplier A", 5000)}),
    ("Card 5", None, "supplier A", 5000, {"K-101": ("completed", "supplier A", 5000)}),
    ("Card 6", "K-310", "supplier B", 2000, {"K-310": ("completed", "supplier B", 20000)}),
]

for name, key, payee, amount, ledger in CASES:
    print(f"{name}: {decide(key, payee, amount, ledger)}")
