"""Exhibit 8: stamp every trace with the configuration revision, so an incident can be tied
to what was actually running. Uses OpenTelemetry. The gen_ai.* attribute names are still
marked "Development" by the project, so treat them as likely to change.

Run: uv run --with opentelemetry-sdk 08_trace_stamp.py
"""
import hashlib
import json
from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import ConsoleSpanExporter, SimpleSpanProcessor

provider = TracerProvider()
provider.add_span_processor(SimpleSpanProcessor(ConsoleSpanExporter()))
tracer = trace.get_tracer("mortgage-assistant", tracer_provider=provider)

CONFIG = {"model": "provider-model-x@2026-03-01", "platform_prompt_hash": "a41f", "tools": ["kb.search", "prefs.update", "callback.create"]}
CONFIG_HASH = hashlib.sha256(json.dumps(CONFIG, sort_keys=True).encode()).hexdigest()[:12]

with tracer.start_as_current_span("invoke_agent mortgage-assistant") as span:
    span.set_attribute("gen_ai.operation.name", "invoke_agent")
    span.set_attribute("gen_ai.agent.name", "mortgage-assistant")
    span.set_attribute("app.agent.config_revision", "2026-04-02")   # custom attribute
    span.set_attribute("app.agent.config_hash", CONFIG_HASH)         # custom attribute
