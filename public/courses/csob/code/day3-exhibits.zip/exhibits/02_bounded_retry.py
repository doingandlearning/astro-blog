"""Exhibit 2: the overnight agent from Activity 4, naive and bounded.

The connection to System B drops at 00:50 and stays down. No sleeping here:
the clock is simulated so the whole night runs in a blink.

Run: python3 02_bounded_retry.py
"""

TOTAL, COMPARED, FLAGGED = 18400, 11040, 12
RETRY_EVERY = 30  # seconds
OUTAGE = 6 * 3600  # six hours


def naive():
    retries = OUTAGE // RETRY_EVERY  # every failure logged, nobody told
    return retries, f"Run completed. {FLAGGED} discrepancies flagged for review."


def bounded(limit_seconds=600):
    retries = min(OUTAGE, limit_seconds) // RETRY_EVERY
    pct = round(100 * COMPARED / TOTAL)
    page = "PAGE on-call analyst: System B unreachable for 10 minutes"
    msg = (
        f"Run INCOMPLETE. {TOTAL - COMPARED} of {TOTAL} transactions "
        f"({100 - pct}%) were not compared because System B was unreachable "
        f"from 00:50. {FLAGGED} discrepancies found in the {pct}% that were "
        f"compared. Re-run needed."
    )
    return retries, page, msg


r, msg = naive()
print(f"NAIVE   : {r} retries. Message: {msg}")
r, page, msg = bounded()
print(f"BOUNDED : {r} retries, then stop.\n          {page}\n          Message: {msg}")
