"""Exhibit 5: what a gateway filter call looks like. REFERENCE ONLY: needs credentials, not run here.

Two real services, same idea: send the text to a detector before the model (or tool) sees it,
and act on the verdict in your own code.
  - Amazon Bedrock Guardrails: ApplyGuardrail works on any text, including models outside Bedrock.
  - Azure AI Content Safety Prompt Shields: checks user prompts and documents for injection.
A filter is probabilistic. It is one layer, not the control.
"""
import boto3
import requests


def bedrock_check(text, guardrail_id, version, source="INPUT"):
    client = boto3.client("bedrock-runtime", region_name="eu-central-1")
    resp = client.apply_guardrail(
        guardrailIdentifier=guardrail_id,
        guardrailVersion=version,
        source=source,  # "INPUT" for what the user sent, "OUTPUT" for what the model produced
        content=[{"text": {"text": text}}],
    )
    return resp["action"] != "GUARDRAIL_INTERVENED"  # True means allowed


def prompt_shields_check(user_prompt, documents, endpoint, key):
    resp = requests.post(
        f"{endpoint}/contentsafety/text:shieldPrompt?api-version=2024-09-01",
        headers={"Ocp-Apim-Subscription-Key": key, "Content-Type": "application/json"},
        json={"userPrompt": user_prompt, "documents": documents},  # documents: retrieved text, emails, tool output
        timeout=10,
    ).json()
    hit = resp["userPromptAnalysis"]["attackDetected"] or any(
        d["attackDetected"] for d in resp["documentsAnalysis"]
    )
    return not hit  # True means no attack detected
