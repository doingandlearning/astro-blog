# Exhibit 6: the tabletop agent's sandbox as a policy file. Default deny.
# Open Policy Agent (Rego v1 syntax). NOT RUN while preparing this pack: check it with
#   opa eval -d 06_tool_policy.rego -i input.json "data.csob.agent.tools.allow"
package csob.agent.tools

import rego.v1

# Anything not listed below is denied.
default allow := false

allowed_fields := {"preferred_channel", "preferred_time"}

changed_fields := {f | some f, _ in input.args.changes}

# Product knowledge base: search only.
allow if input.tool == "product_kb.search"

# Contact preferences: the signed-in customer's own record only.
allow if {
	input.tool == "contact_prefs.read"
	input.args.customer_id == input.session.customer_id
}

# ...and only two fields may be changed.
allow if {
	input.tool == "contact_prefs.update"
	input.args.customer_id == input.session.customer_id
	count(changed_fields - allowed_fields) == 0
}

# Callbacks: create one, for the signed-in customer. No cancel, no edit, no other customers.
allow if {
	input.tool == "callback.create"
	input.args.customer_id == input.session.customer_id
}
