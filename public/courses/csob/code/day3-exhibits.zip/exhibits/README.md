# Day 3 exhibits: show the code, config and tools

Small, real files for the presenter to open on the projector from an editor. Nobody in the room is asked to read or write code; the point is that the ideas from the paper activities exist as a few lines of something they recognise. Keep code and slides separate: put the editor on screen, do the exhibit, go back to the deck.

Each exhibit follows the same drill: **ask first (a card or a sticky), then run or open it, then say one sentence.** Nothing here adds time to the day: every exhibit sits inside a slot that already exists or inside the spare minutes.

Run them from this folder. Most need nothing installed. Three need a package: `uv run --with pyyaml 03_config_diff.py`, `uv run --with jsonschema 04_check_output.py`, `uv run --with opentelemetry-sdk 08_trace_stamp.py`.

## The four to do if you do nothing else

| # | Exhibit | Where in the day | Time | Ask first | The one sentence |
| --- | --- | --- | --- | --- | --- |
| 2 | `02_bounded_retry.py` | 11:30, in place of slide 10 | 3 min | "How many retries did the agent make, and how many should it have made?" (720 against 20) | The difference between the two is three lines of code and a decision about who gets paged |
| 3 | `03_config_diff.py` with `baseline.yaml` and `running.yaml` | 12:06, before slide 14 | 2 min | "How many differences will the machine find?" (cards up: 6, 8, 10) | It takes a machine under a second. The hard part is the last line: nobody owns the baseline or the alert |
| 6 | `06_tool_policy.rego` | 15:30, end of the tabletop sandbox step (write for 10 minutes, show for 2) | 2 min | "Does your scope sheet say what happens to anything not listed?" | Your sandbox sheet is this file. Anything not listed is denied |
| 7 | `07_trigger.yaml` and `07_apply_trigger.py` | 15:05, inside slide 24 | 2 min | "Which of the ten messages will this trigger escalate?" (E and N cards up) | A rule that can be run gives everyone the same answer. That is what "specific" means. The probes show it can still be wrong |

## The rest, in the order of value

| # | Exhibit | Where in the day | Time | The one sentence |
| --- | --- | --- | --- | --- |
| 1 | `01_idempotent_ledger.py` | 10:40, with the close of the ledger activity | 2 min | Your six cards as 30 lines. Real payment APIs take an idempotency key in a header and replay the stored result |
| 4 | `04_output_schema.json` and `04_check_output.py` | 14:08, with slide 21 | 2 min | The schema rejects the link, the fourth bullet and the extra field. It accepts a bullet that is wrong. Bounds the damage; does not stop the attempt |
| 5 | `05_guardrail_calls.py` (reference, not run) | 14:08, with slide 21 | 1 min | This is what a gateway filter call looks like in Bedrock and in Azure. The verdict is advisory until your code enforces it |
| 9 | The Rule of Two (below) | Tabletop Event 1 reveal, 15:40 | 2 min | Count to three: untrusted input, private data, the power to act. The tabletop agent has all three, so a human has to approve |
| 8 | `08_trace_stamp.py` | 12:10, with slide 15 | 1 min | Twelve lines stamp every trace with the configuration revision, so an incident can be tied to what was running |

## Exhibit 9: the Rule of Two, applied to the tabletop agent

No code. Draw three circles on the flip chart: **A** it processes untrusted input, **B** it can reach sensitive systems or private data, **C** it can change state or communicate outside. Put the tabletop agent in it: customer messages (A), contact preferences and account context (B), callback booking and the confirmation email (C). It sits in all three. Event 1 is exactly that: a customer message that asks the agent to send an account number to an outside address. Meta's guidance (31 October 2025) is that an agent session should have at most two, and that if all three are needed a human approves. Ask: which circle would you remove for the callback agent, and which of your sandbox lines already does?

## What is tested and what is not

| File | Status |
| --- | --- |
| 01, 02, 03, 04, 07 | Run while preparing this pack. Output matches the paper activities (six ledger decisions; 720 against 20 retries; eight differences; the schema accepts the clean and the "wrong but valid-looking" summaries and rejects the others; the trigger escalates 8 of the 10 messages, misses probe 9 and wrongly escalates probe 10) |
| 08 | Run with `opentelemetry-sdk` and a console exporter. The `gen_ai.*` names are still "Development" in the OpenTelemetry project, so they may change |
| 05 | Compiles. Not run: it needs AWS and Azure credentials. API shapes checked against AWS and Microsoft material; check the Prompt Shields response field names against the current API version before relying on them |
| 06 | **Not run.** The tool to run it (`opa`) could not be fetched in the environment used to prepare this. Read it carefully, and if you have `opa` on your machine run `opa eval` once before you show it |

## Things to say carefully

- These are illustrations of a pattern, not CSOB's design and not a recommendation of any product.
- Name products as examples of a category. Confirm with CSOB that they are comfortable with named vendors in the materials (still an open item from the scoping notes).
- The regulatory lines in `where-this-lives.md` (DORA) should be confirmed with CSOB compliance before you state them as fact.
- If anyone asks whether the trigger exhibit means "do it with keywords": no. It shows what testable means and where that approach fails.

## Also in this folder

`where-this-lives.md` is a one-page handout: the real tools and standards for each idea today, with a question to ask for each.
